(function () {
  var TWEAKS_KEY = 'aha-tweaks-v1';
  var STYLE_ID = 'aha-tweaks-injected';
  var DEFAULTS = {
    '--bg': '#F6F9F7',
    '--surface': '#FFFFFF',
    '--fg': '#1E293B',
    '--muted': '#5C5C5C',
    '--border': '#E5E7EB',
    '--accent': '#1A6B4C',
    '--shell': '#08090D',
    '--dark-bg': '#0F1923',
    '--accent-light': '#2ECC71',
    '--green-light': '#E8F5E9',
    '--t-display': '72px',
    '--t-display-lg': '110px',
    '--t-h1': '54px',
    '--t-h2': '42px',
    '--t-h3': '32px',
    '--t-body': '22px',
    '--t-body-lg': '26px',
    '--t-small': '19px',
    '--t-caption': '20px',
    '--t-stat': '64px',
    '--t-bar': '26px',
    '--l-padding': '80px',
    '--l-padding-x': '100px',
    '--l-radius': '12px',
    '--l-gap': '24px',
    '--d-muted': '0.65',
    '--d-hint': '0.55',
  };

  function load() {
    try {
      var raw = localStorage.getItem(TWEAKS_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      var merged = {};
      for (var k in DEFAULTS) merged[k] = DEFAULTS[k];
      for (var k in parsed) if (parsed.hasOwnProperty(k)) merged[k] = parsed[k];
      return merged;
    } catch (_) { return null; }
  }

  function apply(tweaks) {
    if (!tweaks) return;
    var css = ':root {\n';
    for (var k in tweaks) {
      if (tweaks.hasOwnProperty(k) && k.indexOf('--') === 0) {
        css += '  ' + k + ': ' + tweaks[k] + ';\n';
      }
    }
    css += '}\n';

    var padY = tweaks['--l-padding'] || '80px';
    var padX = tweaks['--l-padding-x'] || '100px';
    var radius = tweaks['--l-radius'] || '12px';
    var gap = tweaks['--l-gap'] || '24px';
    var dMuted = tweaks['--d-muted'] || '0.65';
    var dHint = tweaks['--d-hint'] || '0.55';

    css += '.s-body { padding: ' + padY + ' ' + padX + '; }\n';
    css += '.s-cover { padding: ' + padY + ' 120px; }\n';
    css += '.s-dark .muted { color: rgba(255,255,255,' + dMuted + '); }\n';
    css += '.deck-hint { color: rgba(255,255,255,' + dHint + '); }\n';
    css += '.card, .card-dark, .phase { border-radius: ' + radius + '; }\n';
    css += '.s-grid-2, .s-grid-3, .s-grid-4 { gap: ' + gap + '; }\n';
    css += '.body { font-size: ' + tweaks['--t-body'] + '; }\n';
    css += '.body-lg { font-size: ' + tweaks['--t-body-lg'] + '; }\n';
    css += '.h1 { font-size: ' + tweaks['--t-h1'] + '; }\n';
    css += '.h2 { font-size: ' + tweaks['--t-h2'] + '; }\n';
    css += '.h3 { font-size: ' + tweaks['--t-h3'] + '; }\n';
    css += '.display { font-size: ' + tweaks['--t-display'] + '; }\n';
    css += '.display-lg { font-size: ' + tweaks['--t-display-lg'] + '; }\n';
    css += '.small { font-size: ' + tweaks['--t-small'] + '; }\n';
    css += '.caption { font-size: ' + tweaks['--t-caption'] + '; }\n';
    css += '.stat-number { font-size: ' + tweaks['--t-stat'] + '; }\n';
    css += '.bar .bar-val { font-size: ' + tweaks['--t-bar'] + '; }\n';

    var style = document.getElementById(STYLE_ID);
    if (!style) {
      style = document.createElement('style');
      style.id = STYLE_ID;
      document.head.appendChild(style);
    }
    style.textContent = css;
  }

  var tweaks = load();
  if (tweaks) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () { apply(tweaks); });
    } else {
      apply(tweaks);
    }
  }

  window.addEventListener('storage', function (e) {
    if (e.key === TWEAKS_KEY) {
      var t = load();
      if (t) apply(t);
    }
  });
})();
