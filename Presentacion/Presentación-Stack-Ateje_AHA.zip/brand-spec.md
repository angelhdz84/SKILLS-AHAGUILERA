# Brand Spec — AHA Apps (Ateje Stack)

Extracted from 5 product screenshots (DashBoard, Servicios, Clientes, Agenda, IA-Jutia).

## Color Tokens

| Token | Hex | OKLch | Role |
|-------|-----|-------|------|
| `--bg` | `#F6F9F7` | `oklch(98% 0.004 160)` | Canvas/page background |
| `--surface` | `#FFFFFF` | `oklch(100% 0 0)` | Card/surface backgrounds |
| `--fg` | `#1E293B` | `oklch(22% 0.02 250)` | Body text, headings |
| `--muted` | `#8B8B8B` | `oklch(56% 0.01 160)` | Secondary text, captions |
| `--border` | `#E5E7EB` | `oklch(92% 0.005 200)` | Hairlines, dividers |
| `--accent` | `#1A6B4C` | `oklch(39% 0.10 165)` | Primary brand accent (green) |
| `--shell` | `#08090D` | — | Deck shell (outside canvas) |

## Font Stacks

- **Display**: `'Space Grotesk', -apple-system, BlinkMacSystemFont, 'SF Pro Display', system-ui, sans-serif`
- **Body**: `-apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', system-ui, sans-serif`
- **Mono**: `'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace`

## Posture Rules

1. **Clean, spacious** — generous padding (48–80px), never cram contents
2. **Green accent used sparingly** — max 2 visible uses per slide (eyebrow + primary CTA, or stat highlight + title accent)
3. **Hairline borders** — `var(--border)` at 1px, no heavy outlines
4. **No decorative gradients** — flat surfaces, type-driven hierarchy
5. **Screenshots as visual assets** — embed the real PNG screenshots throughout the deck to ground every claim in product reality
