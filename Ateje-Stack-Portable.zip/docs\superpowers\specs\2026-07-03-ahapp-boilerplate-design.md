# AHApp Boilerplate — Design Spec

## Goal

Crear los artefactos faltantes para que las AHApps se desarrollen más rápido, sin errores recurrentes, con UI/UX uniforme y fáciles de modificar:

1. `modules/_template/` — plantilla de módulo completa (referenciada pero vacía)
2. `core/file-store.js` — archivo faltante (referenciado pero inexistente)
3. `apps/AHA-Base/template.md` — spec para generar una app vacía base vía pipeline

## 1. `modules/_template/`

Tres archivos:

### `module.js`
Controlador Alpine.js completo demostrando 12 patrones del stack AHA:

| Patrón | Mecanismo |
|--------|-----------|
| CRUD completo | `abrirForm()` modal → `guardar()` create/update + `eliminar()` con confirm |
| Validación | `validarForm()` con `errors{}` reactivo |
| Estados visuales | `skel` / empty-state / tabla / error-state |
| Búsqueda | `buscar()` sobre Dexie con filtro |
| Paginación | `page` / `pageSize` / `totalPages` + navegación |
| Exportación PDF/CSV | jsPDF + SheetJS desde botones toolbar |
| Confirmaciones | `UI.confirm()` pre-delete |
| Manejo de errores | `try/catch` + `UI.toast()` en cada operación |
| Timestamps automáticos | `created_at`, `updated_at` en create/update |
| Badges de estado | Clase condicional para activo/inactivo |
| Atajo Cmd+K | `id`, `titulo` para search-palette |
| Ciclo de vida | `init()` → `render(params)` → `destroy()` |

Tabla Dexie demo: `_template: '++id, nombre, estado, created_at, updated_at'`

### `module.html`
Template HTML con estados: skeleton (carga), empty-state, tabla con datos, error.

Estructura:
```html
<!-- Skeleton: .sk-* classes -->
<div x-show="loading" class="space-y-4">...</div>

<!-- Error state -->
<div x-show="!loading && error" class="alert alert-error">...</div>

<!-- Empty state -->
<div x-show="!loading && !error && items.length === 0" class="...">...</div>

<!-- Tabla con datos -->
<div x-show="!loading && items.length > 0">
  <div class="toolbar">[Add] [Search] [PDF] [CSV]</div>
  <table>...</table>
  <div class="pagination">...</div>
</div>

<!-- Modal form -->
<form @submit.prevent="guardar">...</form>
```

### `SKILL.md`
Instrucciones de uso:
1. Copiar `modules/_template/` → `modules/mi-modulo/`
2. Cambiar `id`, `titulo`, `icono`
3. Cambiar nombre de tabla Dexie y esquema
4. Adaptar campos del formulario
5. Registrar en `project.config.js`
6. Verificar en `app.js`

## 2. `core/file-store.js`

Utilidad de almacenamiento de archivos unificada:

```js
window.fileStore = {
  async save(file, table?)       → id | throws
  async get(id)                  → Blob | null
  async getURL(id)               → Object URL string | null
  revokeURL(url)                  → void
  async delete(id)                → void
  async getAvatar()               → Blob (default avatar fallback)
  async saveAvatar(blob)          → id
}
```

Dos modos según perfil:
- **Lite**: Dexie `_file_blobs` table + Object URLs (revoke manual)
- **Full** (Professional/Business): filesystem disco + path en `_files` table

Sin dependencias externas más allá de `db` (Dexie).

## 3. `apps/AHA-Base/template.md`

App template para catálogo de 15 apps:

| Campo | Valor |
|-------|-------|
| Nombre | AHA Base |
| Target | Desarrolladores, punto de partida |
| Módulos | `_template` (demo CRUD) |
| Tablas | `_template: '++id, nombre, estado, created_at, updated_at'` |
| Librerías extra | Ninguna |
| Precio | Gratis (base) |
| Perfiles | Lite / Professional / Business |

## Impacto

- `modules/_template/` → elimina errores de estructura en **cada módulo nuevo**
- `file-store.js` → elimina error recurrente (referencia rota)
- `AHA-Base` → starter oficial sin dependencia de pipeline completo

## No incluido (excluido deliberadamente)

- Vertical Kit Starter (muy complejo, estrategia comercial no técnica)
- Proyecto pre-generado estático (drift con pipeline)
