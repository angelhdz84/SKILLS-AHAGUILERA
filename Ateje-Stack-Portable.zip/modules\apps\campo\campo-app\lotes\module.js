const ModuloCampoLotes = {
  id: 'campo-lotes',
  titulo: 'Lotes',
  icono: 'bi bi-grid-3x3-gap',

  items: [],
  item: null,
  formData: {},
  errors: {},
  searchQuery: '',
  loading: true,
  error: null,
  saving: false,
  page: 1,
  pageSize: 25,
  totalPages: 1,

  async init() {
    await this.cargarDatos();
  },

  render(params = {}) {
    return `
      <div x-data="campoLotesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-emerald-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-grid-3x3-gap text-emerald-600"></i> Lotes
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Agregar
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="buscar" placeholder="Buscar lote..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-shadow" />
          </div>
          <button class="inline-flex items-center gap-1.5 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors" @click="exportarPDF()" x-show="items.length">
            <i class="bi bi-file-earmark-pdf"></i> PDF
          </button>
        </div>

        <template x-if="error">
          <div class="p-4 mb-4 bg-red-50 border border-red-200 rounded-lg">
            <div class="flex items-center gap-2 text-red-700 text-sm">
              <i class="bi bi-exclamation-triangle"></i>
              <span x-text="error"></span>
            </div>
          </div>
        </template>

        <template x-if="!loading && !error && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-grid-3x3-gap text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-4">No hay lotes registrados a\u00fan</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors shadow-sm" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Agregar primer lote
            </button>
          </div>
        </template>

        <template x-if="!loading && items.length > 0">
          <div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              <template x-for="item in items" :key="item.id">
                <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow">
                  <div class="flex items-start justify-between mb-3">
                    <div class="flex items-center gap-2">
                      <div class="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                        <i class="bi bi-grid-3x3-gap text-emerald-600 text-lg"></i>
                      </div>
                      <div>
                        <p class="text-sm font-semibold text-gray-900" x-text="item.nombre"></p>
                        <p class="text-xs text-gray-500" x-text="item.hectareas + ' ha'"></p>
                      </div>
                    </div>
                    <div class="flex gap-1">
                      <button class="p-1.5 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors" @click="abrirForm(item)" title="Editar">
                        <i class="bi bi-pencil text-sm"></i>
                      </button>
                      <button class="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" @click="eliminar(item)" title="Eliminar">
                        <i class="bi bi-trash text-sm"></i>
                      </button>
                    </div>
                  </div>
                  <div class="flex items-center justify-between text-xs">
                    <span class="text-gray-500">Cultivo actual:</span>
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                          :class="item.cultivoActual ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-500'"
                          x-text="item.cultivoActual || 'Sin cultivar'"></span>
                  </div>
                </div>
              </template>
            </div>

            <div class="flex justify-between items-center mt-4" x-show="totalPages > 1">
              <span class="text-sm text-gray-500">
                P\u00e1gina <span class="font-medium text-gray-700" x-text="page"></span> de <span class="font-medium text-gray-700" x-text="totalPages"></span>
              </span>
              <div class="flex gap-2">
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === 1" @click="page--;">
                  <i class="bi bi-chevron-left"></i>
                </button>
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === totalPages" @click="page++;">
                  <i class="bi bi-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="i in 6" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <div class="flex items-center gap-2 mb-3">
                  <div class="w-10 h-10 rounded-lg bg-gray-200 animate-pulse"></div>
                  <div class="flex-1 space-y-1.5">
                    <div class="h-3 w-24 bg-gray-200 rounded animate-pulse"></div>
                    <div class="h-2.5 w-16 bg-gray-200 rounded animate-pulse"></div>
                  </div>
                </div>
                <div class="h-2.5 w-full bg-gray-200 rounded animate-pulse"></div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.item = null;
    this.searchQuery = '';
    this.loading = true;
    this.error = null;
    this.page = 1;
  },

  formatearFecha(fecha) {
    if (!fecha) return '';
    try {
      return new Date(fecha).toLocaleDateString('es-MX', {
        year: 'numeric', month: 'short', day: 'numeric'
      });
    } catch { return fecha; }
  },

  get paginated() {
    const start = (this.page - 1) * this.pageSize;
    return this.items.slice(start, start + this.pageSize);
  },

  _cifrarSensibles(obj) {
    for (const campo of (APP_CONFIG.cifrado.camposSensibles || [])) {
      if (obj[campo] && typeof obj[campo] === 'string' && !obj[campo].startsWith('U2FsdGVkX1')) {
        obj[campo] = cryptoHelpers.encrypt(obj[campo]);
      }
    }
    return obj;
  },

  _descifrarSensibles(obj) {
    if (!APP_CONFIG.cifrado.camposSensibles) return obj;
    for (const campo of APP_CONFIG.cifrado.camposSensibles) {
      if (obj[campo]) obj[campo] = cryptoHelpers.decrypt(obj[campo]);
    }
    return obj;
  },

  async cargarDatos() {
    try {
      this.loading = true;
      this.error = null;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.lotes.orderBy('createdAt').reverse().toArray();
      if (filtro) {
        datos = datos.filter(i =>
          (i.nombre || '').toLowerCase().includes(filtro) ||
          (i.cultivoActual || '').toLowerCase().includes(filtro)
        );
      }
      this.items = datos;
      this.totalPages = Math.max(1, Math.ceil(this.items.length / this.pageSize));
      if (this.page > this.totalPages) this.page = this.totalPages;
    } catch (e) {
      console.error('Error cargando lotes:', e);
      this.error = 'Error al cargar lotes';
      UI.toast('Error al cargar lotes', 'error');
    } finally {
      this.loading = false;
    }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const descifrado = item ? this._descifrarSensibles({ ...item }) : {};
    const html = `
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Nombre del lote <span class="text-red-500">*</span></label>
          <input type="text" x-model="form.nombre"
                 class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                 :class="errors.nombre ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-emerald-500 focus:border-emerald-500'"
                 :class="errors.nombre ? 'focus:ring-2' : 'focus:ring-2'" />
          <template x-if="errors.nombre">
            <p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Hect\u00e1reas <span class="text-red-500">*</span></label>
          <input type="number" step="0.01" min="0" x-model="form.hectareas"
                 class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                 :class="errors.hectareas ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-emerald-500 focus:border-emerald-500'"
                 :class="errors.hectareas ? 'focus:ring-2' : 'focus:ring-2'" />
          <template x-if="errors.hectareas">
            <p class="mt-1 text-sm text-red-500" x-text="errors.hectareas"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Cultivo actual</label>
          <input type="text" x-model="form.cultivoActual" placeholder="Ej: Ma\u00edz, Frijol, Sorgo"
                 class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-shadow" />
        </div>
      </div>`;
    await UI.modalForm(
      editando ? 'Editar Lote' : 'Nuevo Lote',
      html,
      async (data) => {
        if (editando) await this.actualizar(descifrado.id, data);
        else await this.guardar(data);
        await this.cargarDatos();
      },
      descifrado
    );
  },

  validarForm(datos) {
    this.errors = {};
    if (!datos.nombre || !datos.nombre.trim()) {
      this.errors.nombre = 'El nombre del lote es obligatorio';
    }
    if (!datos.hectareas || parseFloat(datos.hectareas) <= 0) {
      this.errors.hectareas = 'Ingrese una superficie v\u00e1lida';
    }
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const registro = this._cifrarSensibles({
        id: uuid(),
        nombre: datos.nombre.trim(),
        hectareas: parseFloat(datos.hectareas) || 0,
        cultivoActual: datos.cultivoActual?.trim() || '',
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      await db.lotes.put(registro);
      UI.toast('Lote guardado correctamente', 'success');
    } catch (e) {
      console.error('Error al guardar lote:', e);
      UI.toast('Error al guardar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const existente = await db.lotes.get(id);
      if (!existente) {
        UI.toast('Lote no encontrado', 'error');
        return;
      }
      const actualizado = this._cifrarSensibles({
        ...existente,
        nombre: datos.nombre.trim(),
        hectareas: parseFloat(datos.hectareas) || 0,
        cultivoActual: datos.cultivoActual?.trim() || '',
        updatedAt: new Date().toISOString()
      });
      await db.lotes.put(actualizado);
      UI.toast('Lote actualizado correctamente', 'success');
    } catch (e) {
      console.error('Error al actualizar lote:', e);
      UI.toast('Error al actualizar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar el lote ' + (item.nombre || '') + '?');
    if (!ok) return;
    try {
      await db.lotes.delete(item.id);
      UI.toast('Lote eliminado correctamente', 'success');
      await this.cargarDatos();
    } catch (e) {
      console.error('Error al eliminar lote:', e);
      UI.toast(e.message, 'error');
    }
  },

  async buscar() {
    this.page = 1;
    await this.cargarDatos();
  },

  async limpiarBusqueda() {
    this.searchQuery = '';
    this.page = 1;
    await this.cargarDatos();
  },

  async exportarPDF() {
    if (!this.items.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const { jsPDF } = window.jspdf || {};
      if (!jsPDF) {
        UI.toast('jsPDF no disponible', 'error');
        return;
      }
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text('Lotes - Registro', 14, 20);
      doc.setFontSize(10);
      let y = 30;
      doc.text('Nombre', 14, y);
      doc.text('Hect\u00e1reas', 80, y);
      doc.text('Cultivo', 130, y);
      y += 6;
      doc.setDrawColor(200);
      doc.line(14, y, 196, y);
      y += 4;
      for (const item of this.items) {
        if (y > 280) { doc.addPage(); y = 20; }
        doc.text(item.nombre || '', 14, y);
        doc.text(String(item.hectareas || '0'), 80, y);
        doc.text(item.cultivoActual || 'Sin cultivar', 130, y);
        y += 6;
      }
      doc.save('lotes-registro.pdf');
      UI.toast('PDF exportado', 'success');
    } catch (e) {
      console.error('Error exportando PDF:', e);
      UI.toast('Error al exportar PDF', 'error');
    }
  },

  async exportarCSV() {
    if (!this.items.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const XLSX = window.XLSX;
      if (XLSX) {
        const ws = XLSX.utils.json_to_sheet(this.items.map(i => ({
          Nombre: i.nombre || '',
          Hect\u00e1reas: i.hectareas || 0,
          'Cultivo Actual': i.cultivoActual || ''
        })));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Lotes');
        XLSX.writeFile(wb, 'lotes-registro.xlsx');
        UI.toast('Excel exportado', 'success');
      } else {
        const cabeceras = ['Nombre', 'Hect\u00e1reas', 'Cultivo Actual'];
        const filas = this.items.map(i => [
          i.nombre || '',
          String(i.hectareas || '0'),
          i.cultivoActual || ''
        ]);
        let csv = cabeceras.join(',') + '\n';
        for (const fila of filas) {
          csv += fila.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',') + '\n';
        }
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'lotes-registro.csv';
        a.click();
        URL.revokeObjectURL(url);
        UI.toast('CSV exportado', 'success');
      }
    } catch (e) {
      console.error('Error exportando:', e);
      UI.toast('Error al exportar', 'error');
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['campo-lotes'] = ModuloCampoLotes;

document.addEventListener('alpine:init', () => {
  Alpine.data('campoLotesData', () => ModuloCampoLotes);
});
