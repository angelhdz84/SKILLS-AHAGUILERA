# Specs de Aplicaciones

Este directorio contiene las especificaciones técnicas (`[app].md`) que el pipeline Ateje consume para generar apps.

## Cómo empezar

Elige una app del catálogo y copia su template a este directorio:

```bash
# Desde la raíz del repo:
cp apps/AHA-Inventario/template.md specs/mi-app.md
# O desde cualquier directorio:
cp apps/AHA-Nombre/template.md specs/[nombre].md
```

Luego ejecuta el pipeline en OpenCode:

```bash
/new
```

Esto activará: setup-init → spec-engine → code-generator → validation-engine → deployment-jigue.

## Apps disponibles

| App | Template | Vertical |
|-----|----------|----------|
| AHA Inventario | `apps/AHA-Inventario/template.md` | Retail / Comercio |
| AHA Comanda | `apps/AHA-Comanda/template.md` | Gastronomía |
| AHA CRM | `apps/AHA-CRM/template.md` | Oficina / Freelancers |
| AHA Checklist | `apps/AHA-Checklist/template.md` | Mantenimiento / Inspecciones |
| AHA Asistencia | `apps/AHA-Asistencia/template.md` | RRHH |
| AHA Citas | `apps/AHA-Citas/template.md` | Belleza / Salud |
| AHA Gastos | `apps/AHA-Gastos/template.md` | Control de gastos |
| AHA Contactos | `apps/AHA-Contactos/template.md` | CRM manual |
| AHA Campo | `apps/AHA-Campo/template.md` | Agro |
| AHA POS | `apps/AHA-POS/template.md` | Punto de venta |
| AHA Rx | `apps/AHA-Rx/template.md` | Salud |
| AHA Flota | `apps/AHA-Flota/template.md` | Logística |
| AHA Obra | `apps/AHA-Obra/template.md` | Construcción |
| AHA PreFactura | `apps/AHA-PreFactura/template.md` | Prefacturación |
| AHA Base | `apps/AHA-Base/template.md` | Proyecto base (desarrolladores) |

## Notas

- El directorio `specs/` es **output temporal** — no se versiona en el repo
- Los templates en `apps/` son la fuente de verdad
- `schemas-standard.md` contiene el esquema Dexie de referencia (no es una spec de app)
