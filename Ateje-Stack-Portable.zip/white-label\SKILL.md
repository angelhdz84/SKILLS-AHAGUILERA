---
name: white-label
description: Self-service branding para el perfil Business. Panel visual en Ajustes para personalizar colores, logo, fuentes y CSS en vivo, sin recompilar.
---

# White-Label — Personalización de Marca Self-Service

## Descripción

Sistema de branding en tiempo de ejecución para el perfil **Business** (Enterprise). Permite que el cliente final personalice la apariencia de la app sin necesidad de recompilar ni acceso al código fuente.

Habilitado exclusivamente por licencia `.aha` con `canWhiteLabel: true`.

## Contratos

| Receptor | Artefacto | Propósito |
|----------|-----------|-----------|
| code-generator | `core/brand-loader.js`, `core/feature-flags.js`, `components/data/branding-panel.html` | Carga, aplica y persiste la configuración de marca |
| deployment-jigue | `templates/package-business.ps1`, `templates/enterprise-checklist.md` | Genera `brand.config.json` por defecto en el empaquetado Business |
| validation-engine | — | Verifica coherencia de marca (brand audit) |

## Componentes

### `core/brand-loader.js`
- Carga `brand.config.json` al iniciar (Neutralino filesystem → fetch → localStorage)
- Convierte colores hex → OKLCH para DaisyUI (mapeo correcto: `--p`, `--s`, `--a`, `--n`, `--b1`..`--b3`, etc.)
- Expone Alpine store `$store.brand` con métodos:
  - `setColor()`, `setFont()`, `setAppName()`, `setLogo()`, `setCustomCss()`
  - `savePreview()`, `exportConfig()`, `saveToDisk()`, `importConfig()`, `resetConfig()`
- Soporta Neutralino filesystem (lectura/escritura directa desde disco)
- Fallback web: `localStorage` para preview, `download` para export

### `core/feature-flags.js`
- Controla visibilidad del panel según el plan de licencia
- `canWhiteLabel: true` solo en perfil Business
- Expone `$store.ff` con `enabled()` y `require()`

### `components/data/branding-panel.html`
- 7 tabs: General, Colores, Logo, Fuentes, CSS, Preview, Exportar
- Color pickers con paletas predefinidas
- Drag-drop logo → base64 (SVG/PNG)
- Preview en vivo con mini-shell (navbar, cards, botones, métricas)
- Exportación e importación cross-app de `brand.config.json`
- Guardado persistente en Neutralino (disco) o localStorage (web)

### `deployment-jigue/templates/package-business.ps1`
- Paso 4/7: genera `brand.config.json` con colores desde parámetros CLI
- Incluye el archivo en el ZIP de entrega Business

## Flujo de Datos

```
brand.config.json ← brand-loader.js ← UI (branding-panel.html)
     ↑                   ↓
  Neutralino FS      Alpine store
  o fetch()          $store.brand
  o localStorage
```

## Portabilidad Cross-App

Cualquier AHA app Business puede:
1. Configurar su marca en el panel (Ajustes → Personalizar Marca)
2. Exportar → descarga `brand.config.json`
3. Copiar a otra app (misma PC, PC diferente, celular)
4. Abrir panel → Importar → seleccionar archivo
5. La app adopta la misma marca exacta

Los logos viajan incrustados como base64 en el JSON.

## Dependencias

- Alpine.js (Alpine.store)
- Neutralino.filesystem (opcional, solo para guardado persistente en escritorio)
- No requiere `import`/`export` ES6

## Archivos

- `code-generator/templates/core/brand-loader.js` — Carga, aplicación y persistencia
- `code-generator/templates/core/feature-flags.js` — Feature gating por plan
- `code-generator/templates/components/data/branding-panel.html` — UI de configuración
- `deployment-jigue/templates/package-business.ps1` — Generación de brand.config.json default
- `deployment-jigue/templates/enterprise-checklist.md` — Checklist incluye sección white-label
