const ModuloContactosGrupos = {
  id: 'ctc-grupos',
  titulo: 'Recordatorios',
  icono: 'bi bi-alarm',

  tab: 'recordatorios',
  recordatorios: [],
  contactos: [],
  filtro: 'hoy',
  loading: true,
  hoy: '',

  async init() {
    this.hoy = new Date().toISOString().slice(0, 10);
    await Promise.all([this.cargarRecordatorios(), this.cargarContactos()]);
  },

  render() {
    return `
      <div x-data="ctcGruposData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-orange-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-alarm text-orange-600"></i> Recordatorios
          </h2>
        </div>

        <div class="flex gap-1 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="filtro === 'hoy' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'" @click="filtro = 'hoy'; filtrar()"><i class="bi bi-sun"></i> Hoy</button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="filtro === 'semana' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'" @click="filtro = 'semana'; filtrar()"><i class="bi bi-calendar-week"></i> Semana</button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="filtro === 'todos' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'" @click="filtro = 'todos'; filtrar()"><i class="bi bi-list"></i> Todos</button>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-orange-600 text-white text-sm font-medium rounded-lg hover:bg-orange-700 transition-colors shadow-sm" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Recordatorio</button>
          <button class="inline-flex items-center gap-1.5 px-4 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors" @click="exportarCSV()"><i class="bi bi-download"></i> Exportar CSV</button>
        </div>

        <template x-if="loading">
          <div class="space-y-3"><template x-for="i in 5" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-4 w-48 bg-gray-200 rounded animate-pulse"></div></div></template></div>
        </template>

        <template x-if="!loading && recordatorios.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-alarm text-6xl mb-4"></i><p class="text-lg text-gray-500" x-text="filtro === 'hoy' ? 'Sin recordatorios para hoy' : 'Sin recordatorios'"></p></div>
        </template>

        <template x-if="recordatorios.length > 0">
          <div class="space-y-3">
            <template x-for="r in recordatorios" :key="r.id">
              <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between hover:shadow-md transition-shadow"
                   :class="r.completado ? 'opacity-60' : (r.fecha === hoy ? 'border-l-4 border-l-orange-500' : '')">
                <div class="flex items-center gap-3 min-w-0">
                  <button @click="toggleCompletado(r)" class="shrink-0 text-xl transition-colors" :class="r.completado ? 'text-green-500' : 'text-gray-300 hover:text-green-500'">
                    <i :class="r.completado ? 'bi bi-check-circle-fill' : 'bi bi-circle'"></i>
                  </button>
                  <div class="min-w-0">
                    <p class="text-sm font-medium text-gray-900 truncate" x-text="r.nota"></p>
                    <p class="text-xs text-gray-400" x-text="nombreContacto(r.contactoId) + ' \u00b7 ' + (r.fecha || '')"></p>
                  </div>
                </div>
                <button class="text-gray-300 hover:text-red-500 transition-colors p-1 shrink-0" @click="eliminar(r)"><i class="bi bi-trash"></i></button>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() { this.recordatorios = []; this.contactos = []; this.loading = true; },
  nombreContacto(id) { const c = this.contactos.find(x => x.id === id); return c ? c.nombre : '\u2014'; },

  async cargarRecordatorios() {
    try {
      this.loading = true;
      this.recordatorios = await db.recordatorios.orderBy('fecha').toArray();
    } catch (e) { console.error(e); }
    finally { this.loading = false; }
  },

  async cargarContactos() {
    try { this.contactos = await db.contactos.toArray(); }
    catch (e) { console.error(e); }
  },

  filtrar() {
    Promise.resolve().then(async () => {
      try {
        this.loading = true;
        let datos = await db.recordatorios.orderBy('fecha').toArray();
        if (this.filtro === 'hoy') datos = datos.filter(r => r.fecha === this.hoy);
        else if (this.filtro === 'semana') {
          const finSemana = new Date();
          finSemana.setDate(finSemana.getDate() + 7);
          const fin = finSemana.toISOString().slice(0, 10);
          datos = datos.filter(r => r.fecha >= this.hoy && r.fecha <= fin);
        }
        this.recordatorios = datos;
      } catch (e) { console.error(e); }
      finally { this.loading = false; }
    });
  },

  async toggleCompletado(item) {
    try {
      const e = await db.recordatorios.get(item.id);
      if (!e) return;
      await db.recordatorios.put({ ...e, completado: !e.completado, updatedAt: new Date().toISOString() });
      await this.cargarRecordatorios();
    } catch (e) { UI.toast('Error', 'error'); }
  },

  async abrirForm() {
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Contacto</label><select x-model="form.contactoId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow bg-white"><option value="">Seleccionar...</option><template x-for="c in contactos" :key="c.id"><option :value="c.id" x-text="c.nombre"></option></template></select></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Fecha</label><input type="date" x-model="form.fecha" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Nota</label><textarea x-model="form.nota" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow"></textarea></div></div>';
    await UI.modalForm('Nuevo Recordatorio', html, async (data) => {
      if (!data.nota?.trim()) { UI.toast('Nota requerida', 'error'); return; }
      await db.recordatorios.put({ id: window.uuid(), contactoId: data.contactoId || '', fecha: data.fecha || this.hoy, nota: data.nota.trim(), completado: false, createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      UI.toast('Recordatorio creado', 'success');
      await this.cargarRecordatorios();
    }, { contactoId: '', fecha: this.hoy, nota: '' });
  },

  async eliminar(item) {
    if (!await UI.confirm('Eliminar recordatorio?')) return;
    try { await db.recordatorios.delete(item.id); UI.toast('Eliminado', 'success'); await this.cargarRecordatorios(); }
    catch (e) { UI.toast(e.message, 'error'); }
  },

  async exportarCSV() {
    try {
      const contactos = await db.contactos.toArray();
      const historial = await db.historial.orderBy('fecha').reverse().toArray();
      let csv = '\uFEFFNombre,Telefono,Email,Empresa,Etiqueta,Ultima Interaccion,Fecha\n';
      for (const c of contactos) {
        const ult = historial.find(h => h.contactoId === c.id);
        csv += (c.nombre || '') + ',' + (c.telefono || '') + ',' + (c.email || '') + ',' + (c.empresa || '') + ',' + (c.etiqueta || 'prospecto') + ',' + (ult?.descripcion || '') + ',' + (ult?.fecha || '') + '\n';
      }
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'contactos_' + new Date().toISOString().slice(0, 10) + '.csv';
      link.click();
      URL.revokeObjectURL(link.href);
      UI.toast('CSV exportado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['ctc-grupos'] = ModuloContactosGrupos;

document.addEventListener('alpine:init', () => {
  Alpine.data('ctcGruposData', () => ModuloContactosGrupos);
});
