# AHA Checklist — Spec Técnica

## Identidad
- **App:** AHA Checklist
- **Perfil:** Lite
- **Target:** Supervisores mantenimiento, seguridad, limpieza, construcción
- **Tagline:** Inspecciones y checklists técnicos offline
- **Color primario:** #eab308 (yellow-500 / amber)
- **Descripción:** Plantillas de inspección, asignación a equipos, captura resultados.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  plantillas: 'id, nombre, *categoriaId, *items, *createdBy, createdAt, updatedAt',
  categorias_plantillas: 'id, nombre, createdAt, updatedAt',
  ubicaciones: 'id, nombre, *area, *createdBy, createdAt, updatedAt',
  equipos: 'id, nombre, *codigo, *ubicacionId, frecuencia, *createdBy, createdAt, updatedAt',
  inspecciones: 'id, *plantillaId, *ubicacionId, *equipoId, *resultados, *fotos, *firma, resultado, *createdBy, createdAt, updatedAt',
  programacion: 'id, *ubicacionId, *equipoId, *plantillaId, frecuencia, *proximaFecha, *ultimaFecha, *createdBy, createdAt, updatedAt',
  _sync_log, _ia_chats, _ia_messages
});
```

## Entry point
`core/main.js`

## Módulos (4)

### plantillas
- CRUD: nombre, categoría, items con tipo (sí/no, numérico, texto, foto, firma)
- Reordenar items
- Categorías: seguridad, limpieza, maquinaria

### inspecciones
- Seleccionar plantilla → crear inspección
- Asignar ubicación/equipo
- Resultado: aprobado/rechazado/observado
- Fecha próxima inspección

### ubicaciones
- CRUD ubicaciones (edificio, área, piso) y equipos (nombre, código, ubicación, frecuencia)
- Historial por equipo

### reportes
- Dashboard: % cumplimiento, inspecciones hoy, equipos con fallas
- Export CSV

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema amber (primary: #eab308)
- ES5 estricto
