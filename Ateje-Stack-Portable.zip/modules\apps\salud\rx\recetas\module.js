const ModuloRxRecetas = {
  id: 'rx-recetas',
  titulo: 'Recetas',
  icono: 'bi bi-file-text',

  items: [],
  loading: true,
  searchQuery: '',

  async init() {
    await this.cargar();
  },

  render() {
    return `
      <div x-data="rxRecetasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-emerald-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-file-text text-emerald-600"></i> Recetas
          </h2>
        </div>
        <div class="flex flex-wrap items-center gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Receta
          </button>
          <div class="relative flex-1 max-w-xs ml-auto">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input type="search" x-model="searchQuery" @input.debounce="buscar" placeholder="Buscar..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
          </div>
        </div>
        <template x-if="loading">
          <div class="space-y-3"><template x-for="i in 5" :key="i"><div class="h-16 bg-gray-100 rounded-lg animate-pulse"></div></template></div>
        </template>
        <template x-if="!loading && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-file-text text-6xl mb-4"></i>
            <p class="text-lg text-gray-500">Sin recetas</p>
            <button class="mt-4 px-4 py-2 bg-emerald-600 text-white text-sm rounded-lg" @click="abrirForm()">Crear primera</button>
          </div>
        </template>
        <template x-if="!loading && items.length > 0">
          <div class="space-y-4">
            <template x-for="item in items" :key="item.id">
              <div class="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                <div class="p-4 sm:p-5">
                  <div class="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <h3 class="font-semibold text-gray-900" x-text="item.pacienteNombre || 'Paciente'"></h3>
                      <p class="text-xs text-gray-400 mt-0.5" x-text="item.createdAt ? new Date(item.createdAt).toLocaleString() : ''"></p>
                    </div>
                    <div class="flex items-center gap-1 shrink-0">
                      <button class="text-gray-400 hover:text-blue-600 p-1.5 rounded-lg hover:bg-blue-50" @click="verDetalle(item)" title="Ver detalle"><i class="bi bi-eye"></i></button>
                      <button class="text-gray-400 hover:text-emerald-600 p-1.5 rounded-lg hover:bg-emerald-50" @click="abrirForm(item)" title="Editar"><i class="bi bi-pencil"></i></button>
                      <button class="text-gray-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-red-50" @click="eliminar(item)" title="Eliminar"><i class="bi bi-trash"></i></button>
                    </div>
                  </div>
                  <div class="flex flex-wrap gap-2 mb-2">
                    <span class="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 text-emerald-700 text-xs rounded-full">
                      <i class="bi bi-capsule"></i>
                      <span x-text="item.medicamentosCount || 0"></span> medicamentos
                    </span>
                    <span x-show="item.proximaCita" class="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-blue-700 text-xs rounded-full">
                      <i class="bi bi-calendar-event"></i>
                      <span x-text="new Date(item.proximaCita).toLocaleDateString()"></span>
                    </span>
                  </div>
                  <p x-show="item.diagnostico" class="text-sm text-gray-600 line-clamp-2" x-text="item.diagnostico"></p>
                </div>
              </div>
            </template>
          </div>
        </template>
      </div>`;
  },

  destroy() { this.items = []; this.loading = true; this.searchQuery = ''; },

  async cargar() {
    try {
      this.loading = true;
      const recetas = await db.recetas.orderBy('createdAt').reverse().toArray();
      const pacientes = await db.pacientes.toArray();
      const mapaPacientes = {};
      pacientes.forEach(p => { mapaPacientes[p.id] = p; });
      this.items = [];
      for (const r of recetas) {
        const items = await db.recetas_items.where('recetaId').equals(r.id).toArray();
        this.items.push({
          ...r,
          pacienteNombre: mapaPacientes[r.pacienteId]?.nombre || '—',
          medicamentos: items,
          medicamentosCount: items.length
        });
      }
    } catch (e) {
      console.error(e);
      UI.toast('Error al cargar recetas', 'error');
    } finally {
      this.loading = false;
    }
  },

  async buscar(q) {
    this.searchQuery = q;
    await this.cargar();
    if (q && q.length >= 2) {
      const term = q.toLowerCase();
      this.items = this.items.filter(r =>
        (r.pacienteNombre && r.pacienteNombre.toLowerCase().includes(term)) ||
        (r.diagnostico && r.diagnostico.toLowerCase().includes(term))
      );
    }
  },

  async abrirForm(item) {
    const editando = !!item;
    const pacientes = await db.pacientes.orderBy('nombre').toArray();
    const opcionesPacientes = pacientes.map(p => `<option value="${p.id}">${p.nombre}</option>`).join('');
    const medicamentos = await db.medicamentos.orderBy('nombre').toArray();

    let lineItemsHtml = '';
    if (editando && item.medicamentos) {
      item.medicamentos.forEach((m, i) => {
        const opts = medicamentos.map(md => `<option value="${md.id}" ${md.id === m.medicamentoId ? 'selected' : ''}>${md.nombre}${md.presentacion ? ' — ' + md.presentacion : ''}</option>`).join('');
        lineItemsHtml += `<div class="flex gap-2 items-start">
          <select x-model="form.medicamentos[${i}].medicamentoId" class="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500">
            <option value="">Seleccionar...</option>${opts}
          </select>
          <input type="text" x-model="form.medicamentos[${i}].dosis" class="w-24 px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Dosis" />
          <input type="text" x-model="form.medicamentos[${i}].indicacion" class="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Indicación" />
          <button class="text-red-400 hover:text-red-600 px-1 py-2" @click="form.medicamentos.splice(${i}, 1)" title="Quitar"><i class="bi bi-x-lg"></i></button>
        </div>`;
      });
    }

    const html = '<div class="space-y-4">' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Paciente *</label><select x-model="form.pacienteId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500"><option value="">Seleccionar paciente...</option>' + opcionesPacientes + '</select></div>' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Diagnóstico</label><textarea x-model="form.diagnostico" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500" rows="2"></textarea></div>' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Indicaciones generales</label><textarea x-model="form.indicaciones" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500" rows="2" placeholder="Tomar con alimentos, evitar sol, etc."></textarea></div>' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Próxima cita</label><input type="date" x-model="form.proximaCita" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500" /></div>' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-2">Medicamentos recetados</label>' +
      '<div class="space-y-2" id="medicamentos-container">' +
      (lineItemsHtml || '<div class="text-xs text-gray-400 py-2">Agrega medicamentos a la receta</div>') +
      '</div>' +
      '<button class="mt-2 inline-flex items-center gap-1 text-sm text-emerald-600 hover:text-emerald-700 font-medium" @click="form.medicamentos.push({medicamentoId: \"\", dosis: \"\", indicacion: \"\"})"><i class="bi bi-plus-circle"></i> Agregar medicamento</button></div>' +
      '</div>';

    const initialData = editando ? {
      pacienteId: item.pacienteId,
      diagnostico: item.diagnostico || '',
      indicaciones: item.indicaciones || '',
      proximaCita: item.proximaCita || '',
      medicamentos: item.medicamentos && item.medicamentos.length > 0
        ? item.medicamentos.map(m => ({ medicamentoId: m.medicamentoId || '', dosis: m.dosis || '', indicacion: m.indicacion || '' }))
        : [{ medicamentoId: '', dosis: '', indicacion: '' }]
    } : {
      pacienteId: '',
      diagnostico: '',
      indicaciones: '',
      proximaCita: '',
      medicamentos: [{ medicamentoId: '', dosis: '', indicacion: '' }]
    };

    await UI.modalForm(editando ? 'Editar Receta' : 'Nueva Receta', html, async (data) => {
      if (!data.pacienteId) { UI.toast('Debe seleccionar un paciente', 'error'); return; }
      const medsValidos = (data.medicamentos || []).filter(m => m.medicamentoId);
      if (medsValidos.length === 0) { UI.toast('Debe agregar al menos un medicamento', 'error'); return; }
      if (editando) {
        const existente = await db.recetas.get(item.id);
        if (!existente) return;
        await db.recetas.put({ ...existente, pacienteId: data.pacienteId, diagnostico: data.diagnostico, indicaciones: data.indicaciones, proximaCita: data.proximaCita, updatedAt: new Date().toISOString() });
        await db.recetas_items.where('recetaId').equals(item.id).delete();
      } else {
        const recetaId = window.uuid();
        await db.recetas.put({ id: recetaId, pacienteId: data.pacienteId, diagnostico: data.diagnostico, indicaciones: data.indicaciones, proximaCita: data.proximaCita, createdBy: 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      }
      const recetaId = editando ? item.id : (await db.recetas.orderBy('createdAt').last()).id;
      for (const m of medsValidos) {
        await db.recetas_items.put({ id: window.uuid(), recetaId, medicamentoId: m.medicamentoId, dosis: m.dosis || '', indicacion: m.indicacion || '', createdAt: new Date().toISOString() });
      }
      UI.toast(editando ? 'Receta actualizada' : 'Receta creada', 'success');
      await this.cargar();
    }, initialData);
  },

  async verDetalle(item) {
    const paciente = await db.pacientes.get(item.pacienteId);
    const meds = await db.recetas_items.where('recetaId').equals(item.id).toArray();
    const todosMeds = await db.medicamentos.toArray();
    const mapaMeds = {};
    todosMeds.forEach(m => { mapaMeds[m.id] = m; });

    let medsHtml = '';
    meds.forEach(m => {
      const med = mapaMeds[m.medicamentoId];
      medsHtml += '<div class="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-lg">' +
        '<div><span class="font-medium text-gray-800">' + (med?.nombre || '—') + '</span>' +
        (med?.presentacion ? '<span class="text-xs text-gray-400 ml-2">' + med.presentacion + '</span>' : '') +
        '</div>' +
        '<div class="text-right"><span class="text-sm font-medium text-emerald-700">' + (m.dosis || '—') + '</span>' +
        (m.indicacion ? '<p class="text-xs text-gray-500">' + m.indicacion + '</p>' : '') +
        '</div></div>';
    });

    const html = '<div class="space-y-4">' +
      '<div class="grid grid-cols-2 gap-4"><div><span class="text-xs text-gray-400 uppercase tracking-wider">Paciente</span><p class="font-semibold text-gray-900">' + (paciente?.nombre || '—') + '</p></div>' +
      '<div><span class="text-xs text-gray-400 uppercase tracking-wider">Fecha</span><p class="font-semibold text-gray-900">' + (item.createdAt ? new Date(item.createdAt).toLocaleDateString() : '—') + '</p></div></div>' +
      (item.diagnostico ? '<div><span class="text-xs text-gray-400 uppercase tracking-wider">Diagnóstico</span><p class="text-gray-700">' + item.diagnostico + '</p></div>' : '') +
      (item.indicaciones ? '<div><span class="text-xs text-gray-400 uppercase tracking-wider">Indicaciones</span><p class="text-gray-700">' + item.indicaciones + '</p></div>' : '') +
      (item.proximaCita ? '<div><span class="text-xs text-gray-400 uppercase tracking-wider">Próxima cita</span><p class="font-medium text-blue-700">' + new Date(item.proximaCita).toLocaleDateString() + '</p></div>' : '') +
      '<div><span class="text-xs text-gray-400 uppercase tracking-wider mb-2 block">Medicamentos</span><div class="space-y-2">' + medsHtml + '</div></div>' +
      '</div>';

    await UI.modalForm('Detalle de Receta', html, async () => {});
  },

  async eliminar(item) {
    const ok = await UI.confirm('¿Eliminar esta receta?');
    if (!ok) return;
    try {
      await db.recetas_items.where('recetaId').equals(item.id).delete();
      await db.recetas.delete(item.id);
      UI.toast('Receta eliminada', 'success');
      await this.cargar();
    } catch (e) {
      UI.toast(e.message, 'error');
    }
  }
};
window.MODULES = window.MODULES || {};
window.MODULES[ModuloRxRecetas.id] = ModuloRxRecetas;
document.addEventListener('alpine:init', () => { Alpine.data('rxRecetasData', () => ModuloRxRecetas); });
