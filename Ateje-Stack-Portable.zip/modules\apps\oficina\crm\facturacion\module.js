const ModuloCRMFacturacion = {
  id: 'crm-facturacion',
  titulo: 'Facturaci\u00f3n',
  icono: 'bi bi-receipt',

  tab: 'facturas',
  facturas: [],
  contactos: [],
  deals: [],
  loading: true,

  kpis: { ingresosMes: 0, pendientes: 0, pagadas: 0, tasaConversion: 0 },

  async init() {
    const [facts, clis, dls] = await Promise.all([
      db.facturas?.orderBy('createdAt').reverse().toArray() || [],
      db.contactos?.orderBy('nombre').toArray() || [],
      db.deals?.toArray() || []
    ]);
    this.facturas = facts;
    this.contactos = clis;
    this.deals = dls;
    this.calcularKPI();
    this.loading = false;
  },

  render() {
    return `
      <div x-data="crmFacturacionData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-blue-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-receipt text-blue-600"></i> Facturaci\u00f3n
          </h2>
        </div>

        <div class="flex gap-1 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'facturas' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'facturas'"><i class="bi bi-list"></i> Facturas</button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'reportes' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'reportes'"><i class="bi bi-graph-up"></i> Reportes</button>
        </div>

        <template x-if="loading">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6"><template x-for="i in 4" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-3 w-16 bg-gray-200 rounded animate-pulse mb-2"></div><div class="h-7 w-24 bg-gray-200 rounded animate-pulse"></div></div></template></div>
        </template>

        <template x-if="!loading && tab === 'facturas'">
          <div>
            <div class="flex flex-wrap gap-2 mb-4">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Factura</button>
            </div>
            <template x-if="facturas.length === 0">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-receipt text-6xl mb-4"></i><p class="text-lg text-gray-500">Sin facturas</p></div>
            </template>
            <template x-if="facturas.length > 0">
              <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div class="overflow-x-auto">
                  <table class="w-full text-sm">
                    <thead class="bg-gray-50 border-b border-gray-200">
                      <tr><th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase">Folio</th><th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase">Cliente</th><th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase">Deal</th><th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase">Total</th><th class="text-center px-4 py-3 font-semibold text-gray-600 text-xs uppercase">Estado</th></tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                      <template x-for="f in facturas" :key="f.id">
                        <tr class="hover:bg-gray-50 transition-colors">
                          <td class="px-4 py-3 font-mono text-xs font-bold text-blue-600" x-text="f.folio || f.id.slice(0, 6)"></td>
                          <td class="px-4 py-3" x-text="nombreContacto(f.contactoId) || '\u2014'"></td>
                          <td class="px-4 py-3 text-gray-500 text-xs" x-text="nombreDeal(f.dealId)"></td>
                          <td class="px-4 py-3 text-right font-mono font-bold" x-text="'$' + Number(f.total || 0).toLocaleString('es-MX')"></td>
                          <td class="px-4 py-3 text-center">
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                                  :class="f.estado === 'pagada' ? 'bg-green-100 text-green-700' : f.estado === 'vencida' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'"
                                  x-text="f.estado || 'pendiente'"></span>
                          </td>
                        </tr>
                      </template>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>
          </div>
        </template>

        <template x-if="!loading && tab === 'reportes'">
          <div>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Ingresos del mes</p><p class="text-2xl font-bold text-blue-600" x-text="formatearMoneda(kpis.ingresosMes)"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Pendientes</p><p class="text-2xl font-bold text-amber-600" x-text="kpis.pendientes"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Pagadas</p><p class="text-2xl font-bold text-green-600" x-text="kpis.pagadas"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Tasa conversi\u00f3n</p><p class="text-2xl font-bold text-gray-900" x-text="kpis.tasaConversion + '%'"></p></div>
            </div>
            <div class="flex gap-2 mb-4">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm" @click="exportarCSV"><i class="bi bi-download"></i> Exportar CSV</button>
            </div>
            <div class="bg-white rounded-xl border border-gray-200 p-4">
              <h3 class="font-semibold text-gray-900 mb-3 text-sm">Deals por etapa</h3>
              <div class="space-y-2">
                <template x-for="e in ['prospecto','contactado','propuesta','negociacion','cerrado']" :key="e">
                  <div class="flex items-center gap-3">
                    <span class="text-sm capitalize w-28 text-gray-600" x-text="e"></span>
                    <div class="flex-1 bg-gray-100 rounded-full h-3">
                      <div class="h-3 rounded-full transition-all duration-500"
                           :style="'width:' + (deals.length > 0 ? (deals.filter(d => d.etapa === e).length / deals.length * 100) : 0) + '%'"
                           :class="e === 'cerrado' ? 'bg-green-500' : e === 'negociacion' ? 'bg-red-500' : e === 'propuesta' ? 'bg-amber-500' : e === 'contactado' ? 'bg-purple-500' : 'bg-blue-500'"></div>
                    </div>
                    <span class="text-sm font-mono text-gray-500 w-8 text-right" x-text="deals.filter(d => d.etapa === e).length"></span>
                  </div>
                </template>
              </div>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.facturas = []; this.contactos = []; this.deals = []; this.loading = true;
    this.kpis = { ingresosMes: 0, pendientes: 0, pagadas: 0, tasaConversion: 0 };
  },

  formatearMoneda(v) { if (v == null || isNaN(v)) return '$0.00'; return '$' + Number(v).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); },
  nombreContacto(id) { const c = this.contactos.find(x => x.id === id); return c ? c.nombre : ''; },
  nombreDeal(id) { const d = this.deals.find(x => x.id === id); return d ? d.nombre : ''; },

  calcularKPI() {
    const mes = new Date().toISOString().slice(0, 7);
    const delMes = this.facturas.filter(f => (f.createdAt || '').startsWith(mes));
    const ingresosMes = delMes.filter(f => f.estado === 'pagada').reduce((s, f) => s + Number(f.total || 0), 0);
    const pagadas = delMes.filter(f => f.estado === 'pagada').length;
    const pendientes = delMes.filter(f => f.estado === 'pendiente' || f.estado === 'vencida').length;
    const cerrados = this.deals.filter(d => d.etapa === 'cerrado').length;
    const totalDeals = this.deals.length || 1;
    this.kpis = { ingresosMes, pendientes, pagadas, tasaConversion: Math.round(cerrados / totalDeals * 100) };
  },

  async abrirForm() {
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Deal</label><select x-model="form.dealId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow bg-white"><option value="">Seleccionar...</option>' + (this.deals || []).map(d => '<option value="' + d.id + '">' + d.nombre + '</option>').join('') + '</select></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Total</label><input type="number" step="0.01" x-model="form.total" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Estado</label><select x-model="form.estado" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow bg-white"><option value="pendiente">Pendiente</option><option value="pagada">Pagada</option></select></div></div>';
    await UI.modalForm('Nueva Factura', html, async (data) => {
      const todas = await db.facturas.toArray();
      let nums = todas.map(f => parseInt((f.folio || 'F-0').replace(/^F-/, ''))).filter(n => !isNaN(n));
      let sig = nums.length > 0 ? Math.max(...nums) + 1 : 1;
      const deal = this.deals.find(d => d.id === data.dealId);
      await db.facturas.put({ id: window.uuid(), folio: 'F-' + String(sig).padStart(3, '0'), dealId: data.dealId || '', contactoId: deal?.contactoId || '', total: parseFloat(data.total) || 0, estado: data.estado || 'pendiente', createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      UI.toast('Factura creada', 'success');
      const [facts] = await Promise.all([db.facturas.orderBy('createdAt').reverse().toArray()]);
      this.facturas = facts;
      this.calcularKPI();
    }, { dealId: '', total: 0, estado: 'pendiente' });
  },

  async exportarCSV() {
    try {
      let csv = '\uFEFFFolio,Cliente,Deal,Total,Estado,Fecha\n';
      for (const f of this.facturas) csv += (f.folio || '') + ',' + (this.nombreContacto(f.contactoId)) + ',' + (this.nombreDeal(f.dealId)) + ',' + (f.total || 0) + ',' + (f.estado || 'pendiente') + ',' + (f.createdAt || '').slice(0, 10) + '\n';
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'facturacion_' + new Date().toISOString().slice(0, 10) + '.csv';
      link.click();
      URL.revokeObjectURL(link.href);
      UI.toast('CSV exportado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['crm-facturacion'] = ModuloCRMFacturacion;

document.addEventListener('alpine:init', () => {
  Alpine.data('crmFacturacionData', () => ModuloCRMFacturacion);
});
