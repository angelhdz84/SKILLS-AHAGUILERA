# AHA Rx — Spec Técnica

## Identidad
- **App:** AHA Rx
- **Perfil:** Lite
- **Target:** Médicos generales, consultorios particulares, farmacias
- **Tagline:** Recetas médicas offline para consultorios
- **Color primario:** #059669 (emerald-600)
- **Descripción:** Registro de pacientes, medicamentos, recetas PDF e historial clínico.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  pacientes: 'id, nombre, *telefono, direccion, *fechaNacimiento, alergias, createdAt, updatedAt',
  medicamentos: 'id, nombre, *presentacion, *laboratorio, createdAt, updatedAt',
  recetas: 'id, *pacienteId, *diagnostico, indicaciones, *proximaCita, *createdBy, createdAt, updatedAt',
  recetas_items: 'id, *recetaId, *medicamentoId, dosis, frecuencia, duracion',
  _sync_log, _ia_chats, _ia_messages
});
```

## Entry point
`core/main.js`

## Módulos (5)

### pacientes
- CRUD: nombre, teléfono, dirección, fecha nacimiento, alergias
- Historial de recetas por paciente
- Búsqueda instantánea

### medicamentos
- CRUD: nombre genérico, presentación, laboratorio
- Catálogo precargado con medicamentos básicos
- Autocompletado

### recetas
- Seleccionar paciente + agregar medicamentos (dosis, frecuencia, duración)
- Diagnóstico, indicaciones, próxima cita
- Generación PDF con formato médico
- Firma digital del médico (texto)

### historial
- Recetas previas cronológicas por paciente
- Búsqueda por diagnóstico, medicamento o fecha
- Reimprimir PDF

### estadisticas
- Dashboard: total pacientes, recetas hoy
- Diagnósticos más frecuentes (Chart.js)
- Export CSV

## Estructura
```
aha-rx/ — index.html, manifest.json, sw.js, project.config.js, .gitignore, README.md
core/ (13 archivos)
modules/ (5: pacientes, medicamentos, recetas, historial, estadisticas)
assets/js/libs/ (alpine, dexie, crypto-js, pako, chart.js, jspdf)
assets/css/ (daisyui, tailwind.play, bootstrap-icons, animate.min)
data/defaults/ (avatar.svg, placeholder.svg)
```

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema emerald (primary: #059669)
- Chart.js + jsPDF
- ES5 estricto
