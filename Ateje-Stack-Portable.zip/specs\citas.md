# AHA Citas — Spec Técnica

## Identidad
- **App:** AHA Citas
- **Perfil:** Lite
- **Target:** Barberías, salones de belleza, consultorios, spas, talleres
- **Tagline:** Gestión de citas y agenda offline
- **Color primario:** #d946ef (fuchsia-500)
- **Descripción:** Agenda digital para negocios de servicios. Calendario, clientes, profesionales, ingresos.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  clientes: 'id, nombre, *telefono, email, *frecuente, *createdBy, createdAt, updatedAt',
  profesionales: 'id, nombre, *horario, *diasDescanso, *serviciosOfrece, *createdBy, createdAt, updatedAt',
  servicios: 'id, nombre, *categoriaId, duracion, precio, *createdBy, createdAt, updatedAt',
  categorias_servicios: 'id, nombre, createdAt, updatedAt',
  citas: 'id, *clienteId, *profesionalId, *servicioId, *fecha, *horaInicio, *horaFin, *estado, *motivoCancelacion, *createdBy, createdAt, updatedAt',
  pagos: 'id, *citaId, *monto, *formaPago, *createdBy, createdAt',
  _sync_log, _ia_chats, _ia_messages
});
```

Estados de cita: pendiente, confirmada, completada, cancelada
Formas de pago: efectivo, tarjeta, transferencia, otro

## Entry point
`core/main.js`

## Módulos (5)

### agenda
- Calendario vista día (lista cronológica) y semana (grid)
- Bloque de tiempo por cita (duración desde servicio)
- Botón "Nueva cita" → wizard: cliente → servicio → profesional → hora
- Cancelar cita con motivo
- Validación: no agendar donde ya hay cita (mismo profesional + horario)

### clientes
- CRUD: nombre, teléfono, email, notas
- Historial de visitas (citas completadas del cliente)
- Cliente frecuente badge (después de 3 visitas)

### servicios
- CRUD: nombre, categoría, duración (minutos), precio
- Categorías predefinidas: corte, tinte, manicure, pedicure, tratamiento, barbería, masaje, facial, depilación, otro

### profesionales
- CRUD: nombre, horario laboral (ej: "9:00-18:00"), días de descanso
- Agenda por profesional (filtro en calendario)

### ingresos
- Corte del día: total, por profesional, por forma de pago
- Registro de pago al cerrar cita
- Export PDF y CSV

## Estructura
```
aha-citas/
├── index.html, manifest.json, sw.js, project.config.js, .gitignore, README.md
├── core/ (15 archivos: main, app, db, crypto, theme, ui, env, network, sync, seed, search-palette, file-store, license)
├── modules/
│   ├── agenda/module.html + module.js
│   ├── clientes/module.html + module.js
│   ├── servicios/module.html + module.js
│   ├── profesionales/module.html + module.js
│   └── ingresos/module.html + module.js
├── assets/
└── data/
```

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema fuchsia (primary: #d946ef)
- Chart.js para gráficos (dashboard ingresos)
- ES5 estricto
