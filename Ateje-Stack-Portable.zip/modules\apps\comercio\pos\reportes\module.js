const ModuloPOSReportes = {
  id: 'pos-reportes',
  titulo: 'Reportes',
  icono: 'bi bi-bar-chart-line',

  ventasPeriodo: [],
  cargando: true,
  fechaDesde: '',
  fechaHasta: '',
  periodo: '7d',
  chartsInicializados: false,
  chartVentas: null,
  chartMetodos: null,
  kpis: { ventasHoy: 0, ventasSemana: 0, ventasMes: 0, ticketPromedio: 0 },

  async init() {
    this.presetPeriodo();
    await this.cargarReportes();
    this.$nextTick(() => this.inicializarCharts());
  },

  render(params = {}) {
    return `
      <div x-data="posReportesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-indigo-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-bar-chart-line text-indigo-600"></i> Reportes
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Ventas hoy</p>
            <p class="text-2xl font-bold text-gray-900" x-text="formatearMoneda(kpis.ventasHoy)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Esta semana</p>
            <p class="text-2xl font-bold text-gray-900" x-text="formatearMoneda(kpis.ventasSemana)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Este mes</p>
            <p class="text-2xl font-bold text-indigo-600" x-text="formatearMoneda(kpis.ventasMes)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Ticket prom.</p>
            <p class="text-2xl font-bold text-gray-900" x-text="formatearMoneda(kpis.ticketPromedio)"></p>
          </div>
        </div>

        <div class="flex flex-wrap items-center gap-3 mb-6">
          <div>
            <label class="block text-xs font-medium text-gray-500 mb-1">Desde</label>
            <input type="date" x-model="fechaDesde" @change="cargarReportes"
                   class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" />
          </div>
          <div>
            <label class="block text-xs font-medium text-gray-500 mb-1">Hasta</label>
            <input type="date" x-model="fechaHasta" @change="cargarReportes"
                   class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" />
          </div>
          <div class="self-end flex gap-2">
            <button class="px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    :class="periodo === '7d' ? 'bg-indigo-50 border-indigo-300 text-indigo-700' : 'text-gray-600'"
                    @click="periodo = '7d'; presetPeriodo()">7 d\u00edas</button>
            <button class="px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    :class="periodo === '30d' ? 'bg-indigo-50 border-indigo-300 text-indigo-700' : 'text-gray-600'"
                    @click="periodo = '30d'; presetPeriodo()">30 d\u00edas</button>
            <button class="px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    :class="periodo === 'mes' ? 'bg-indigo-50 border-indigo-300 text-indigo-700' : 'text-gray-600'"
                    @click="periodo = 'mes'; presetPeriodo()">Este mes</button>
          </div>
          <button class="self-end inline-flex items-center gap-1.5 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors" @click="exportarCSV()">
            <i class="bi bi-download"></i> Exportar
          </button>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <h3 class="text-sm font-semibold text-gray-700 mb-4">Ventas por d\u00eda</h3>
            <canvas id="chart-ventas-diarias" class="w-full h-64"></canvas>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <h3 class="text-sm font-semibold text-gray-700 mb-4">M\u00e9todos de pago</h3>
            <canvas id="chart-metodos-pago" class="w-full h-64"></canvas>
          </div>
        </div>

        <div class="bg-white rounded-xl border border-gray-200 p-4">
          <h3 class="text-sm font-semibold text-gray-700 mb-4">Ventas del per\u00edodo</h3>
          <div class="overflow-x-auto">
            <table class="w-full text-sm">
              <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Folio</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Total</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">M\u00e9todo</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Art\u00edculos</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Fecha</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-100">
                <template x-for="(v, idx) in ventasPeriodo" :key="v.id">
                  <tr class="hover:bg-gray-50 transition-colors" :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'">
                    <td class="px-4 py-3 font-medium text-gray-900" x-text="'#' + (v.folio || '')"></td>
                    <td class="px-4 py-3 text-right text-gray-900" x-text="formatearMoneda(v.total)"></td>
                    <td class="px-4 py-3 text-gray-600 capitalize" x-text="v.metodoPago || '-'"></td>
                    <td class="px-4 py-3 text-right text-gray-900" x-text="(v.items || []).length"></td>
                    <td class="px-4 py-3 text-gray-500" x-text="formatearFecha(v.createdAt)"></td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
          <div x-show="ventasPeriodo.length === 0" class="text-center py-8 text-gray-400">
            <p class="text-sm">No hay ventas en este per\u00edodo</p>
          </div>
        </div>

        <template x-if="cargando">
          <div class="space-y-4">
            <div class="grid grid-cols-4 gap-4">
              <template x-for="i in 4" :key="i">
                <div class="h-24 bg-gray-200 rounded-xl animate-pulse"></div>
              </template>
            </div>
            <div class="grid grid-cols-2 gap-6">
              <div class="h-72 bg-gray-200 rounded-xl animate-pulse"></div>
              <div class="h-72 bg-gray-200 rounded-xl animate-pulse"></div>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.ventasPeriodo = [];
    this.cargando = true;
    if (this.chartVentas) { this.chartVentas.destroy(); this.chartVentas = null; }
    if (this.chartMetodos) { this.chartMetodos.destroy(); this.chartMetodos = null; }
    this.chartsInicializados = false;
  },

  formatearFecha(fecha) {
    if (!fecha) return '';
    try {
      return new Date(fecha).toLocaleDateString('es-MX', {
        year: 'numeric', month: 'short', day: 'numeric'
      });
    } catch { return fecha; }
  },

  formatearMoneda(valor) {
    if (valor == null || isNaN(valor)) return '$0.00';
    return '$' + Number(valor).toLocaleString('es-MX', {
      minimumFractionDigits: 2, maximumFractionDigits: 2
    });
  },

  presetPeriodo() {
    const hoy = new Date();
    if (this.periodo === '7d') {
      const inicio = new Date(hoy);
      inicio.setDate(inicio.getDate() - 6);
      this.fechaDesde = inicio.toISOString().split('T')[0];
      this.fechaHasta = hoy.toISOString().split('T')[0];
    } else if (this.periodo === '30d') {
      const inicio = new Date(hoy);
      inicio.setDate(inicio.getDate() - 29);
      this.fechaDesde = inicio.toISOString().split('T')[0];
      this.fechaHasta = hoy.toISOString().split('T')[0];
    } else if (this.periodo === 'mes') {
      const inicio = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
      this.fechaDesde = inicio.toISOString().split('T')[0];
      this.fechaHasta = hoy.toISOString().split('T')[0];
    }
  },

  async cargarReportes() {
    try {
      this.cargando = true;
      const desde = this.fechaDesde ? new Date(this.fechaDesde) : new Date(0);
      const hasta = this.fechaHasta ? new Date(this.fechaHasta + 'T23:59:59.999Z') : new Date();
      const todas = await db.ventas.orderBy('createdAt').toArray();
      this.ventasPeriodo = todas.filter(v => {
        const d = new Date(v.createdAt);
        return d >= desde && d <= hasta;
      });
      this.calcularKPIs(todas);
      this.$nextTick(() => this.actualizarCharts());
    } catch (e) {
      console.error('Error cargando reportes:', e);
      UI.toast('Error al cargar reportes', 'error');
    } finally {
      this.cargando = false;
    }
  },

  calcularKPIs(todas) {
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    const inicioSemana = new Date(hoy);
    inicioSemana.setDate(inicioSemana.getDate() - inicioSemana.getDay());
    const inicioMes = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
    let ventasHoy = 0, ventasSemana = 0, ventasMes = 0, count = 0;
    for (const v of todas) {
      const d = new Date(v.createdAt);
      const t = v.total || 0;
      if (d >= hoy) { ventasHoy += t; count++; }
      if (d >= inicioSemana) ventasSemana += t;
      if (d >= inicioMes) ventasMes += t;
    }
    this.kpis = {
      ventasHoy,
      ventasSemana,
      ventasMes,
      ticketPromedio: count > 0 ? this.ventasPeriodo.reduce((s, v) => s + (v.total || 0), 0) / Math.max(1, this.ventasPeriodo.length) : 0
    };
  },

  inicializarCharts() {
    if (!window.Chart || this.chartsInicializados) return;
    const canvas1 = document.getElementById('chart-ventas-diarias');
    const canvas2 = document.getElementById('chart-metodos-pago');
    if (!canvas1 || !canvas2) return;

    const colores = {
      indigo: 'rgba(79, 70, 229, 0.8)',
      indigoClaro: 'rgba(79, 70, 229, 0.1)',
      verde: 'rgba(16, 185, 129, 0.8)',
      azul: 'rgba(59, 130, 246, 0.8)',
      amber: 'rgba(245, 158, 11, 0.8)',
      rosa: 'rgba(236, 72, 153, 0.8)'
    };

    this.chartVentas = new Chart(canvas1, {
      type: 'bar',
      data: { labels: [], datasets: [{ label: 'Ventas', data: [], backgroundColor: colores.indigo, borderRadius: 6 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true, ticks: { callback: v => '$' + v.toLocaleString() } },
          x: { grid: { display: false } }
        }
      }
    });

    this.chartMetodos = new Chart(canvas2, {
      type: 'doughnut',
      data: { labels: [], datasets: [{ data: [], backgroundColor: [colores.indigo, colores.verde, colores.azul, colores.amber, colores.rosa], borderWidth: 0 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { padding: 16, usePointStyle: true } } }
      }
    });

    this.chartsInicializados = true;
    this.actualizarCharts();
  },

  actualizarCharts() {
    if (!this.chartsInicializados || !this.chartVentas || !this.chartMetodos) {
      this.inicializarCharts();
      return;
    }

    const ventasPorDia = {};
    const metodosPago = {};
    for (const v of this.ventasPeriodo) {
      const dia = v.createdAt ? v.createdAt.split('T')[0] : 'desconocido';
      ventasPorDia[dia] = (ventasPorDia[dia] || 0) + (v.total || 0);
      const metodo = v.metodoPago || 'otro';
      metodosPago[metodo] = (metodosPago[metodo] || 0) + (v.total || 0);
    }

    const dias = Object.keys(ventasPorDia).sort();
    this.chartVentas.data.labels = dias.map(d => {
      const partes = d.split('-');
      return partes[2] + '/' + partes[1];
    });
    this.chartVentas.data.datasets[0].data = dias.map(d => ventasPorDia[d]);
    this.chartVentas.update();

    const metodos = Object.keys(metodosPago);
    this.chartMetodos.data.labels = metodos.map(m => {
      const labels = { efectivo: 'Efectivo', tarjeta: 'Tarjeta', transferencia: 'Transferencia', mixto: 'Mixto' };
      return labels[m] || m;
    });
    this.chartMetodos.data.datasets[0].data = metodos.map(m => metodosPago[m]);
    this.chartMetodos.update();
  },

  async exportarCSV() {
    if (!this.ventasPeriodo.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const XLSX = window.XLSX;
      if (XLSX) {
        const ws = XLSX.utils.json_to_sheet(this.ventasPeriodo.map(v => ({
          Folio: v.folio || '',
          Total: v.total || 0,
          'Metodo pago': v.metodoPago || '',
          Articulos: (v.items || []).length,
          Fecha: this.formatearFecha(v.createdAt)
        })));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Ventas');
        XLSX.writeFile(wb, 'reporte-ventas.xlsx');
        UI.toast('Excel exportado', 'success');
      } else {
        const cabeceras = ['Folio', 'Total', 'Metodo pago', 'Articulos', 'Fecha'];
        const filas = this.ventasPeriodo.map(v => [
          v.folio || '', v.total || 0, v.metodoPago || '',
          (v.items || []).length, this.formatearFecha(v.createdAt)
        ]);
        let csv = cabeceras.join(',') + '\n';
        for (const fila of filas) {
          csv += fila.map(x => '"' + String(x).replace(/"/g, '""') + '"').join(',') + '\n';
        }
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'reporte-ventas.csv';
        a.click();
        URL.revokeObjectURL(url);
        UI.toast('CSV exportado', 'success');
      }
    } catch (e) {
      console.error('Error exportando:', e);
      UI.toast('Error al exportar', 'error');
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['pos-reportes'] = ModuloPOSReportes;

document.addEventListener('alpine:init', () => {
  Alpine.data('posReportesData', () => ModuloPOSReportes);
});
