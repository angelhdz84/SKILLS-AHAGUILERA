const ModuloComandaMenu = {
  id: 'com-menu', titulo: 'Men\u00fa', icono: 'bi bi-book',
  items: [], categorias: [], loading: true, tab: 'platillos',

  async init() {
    await Promise.all([this.cargarPlatillos(), this.cargarCategorias()]);
    if (this.categorias.length === 0) await this.sembrarCategorias();
  },

  render() {
    return `
      <div x-data="comMenuData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-red-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2"><i class="bi bi-book text-red-600"></i> Men\u00fa</h2>
        </div>
        <div class="flex gap-1 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'platillos' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'" @click="tab = 'platillos'"><i class="bi bi-egg-fried"></i> Platillos</button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'categorias' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'" @click="tab = 'categorias'"><i class="bi bi-tags"></i> Categor\u00edas</button>
        </div>
        <template x-if="tab === 'platillos'">
          <div>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 shadow-sm mb-4" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Platillo</button>
            <template x-if="!loading && items.length === 0"><div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-egg-fried text-6xl mb-4"></i><p class="text-lg text-gray-500">Men\u00fa vac\u00edo</p></div></template>
            <template x-if="items.length > 0">
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <template x-for="p in items" :key="p.id">
                  <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow cursor-pointer" @click="abrirForm(p)">
                    <div class="flex items-start justify-between mb-2">
                      <h3 class="font-semibold text-gray-900 text-sm" x-text="p.nombre"></h3>
                      <span class="text-sm font-bold text-red-600">$<span x-text="Number(p.precio).toLocaleString('es-MX')"></span></span>
                    </div>
                    <div class="flex items-center gap-2">
                      <span class="text-xs text-gray-400" x-text="nomCategoria(p.categoriaId)"></span>
                      <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                            :class="p.disponible !== false ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'"
                            x-text="p.disponible !== false ? 'Disponible' : 'Agotado'"></span>
                    </div>
                  </div>
                </template>
              </div>
            </template>
            <template x-if="loading"><div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"><template x-for="i in 6" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-4 w-32 bg-gray-200 rounded animate-pulse mb-2"></div><div class="h-3 w-16 bg-gray-200 rounded animate-pulse"></div></div></template></div></template>
          </div>
        </template>
        <template x-if="tab === 'categorias'">
          <div>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 shadow-sm mb-4" @click="abrirFormCategoria()"><i class="bi bi-plus-lg"></i> Categor\u00eda</button>
            <template x-if="categorias.length === 0"><p class="text-gray-400 text-sm py-8 text-center">Sin categor\u00edas</p></template>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <template x-for="c in categorias" :key="c.id">
                <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between">
                  <div class="flex items-center gap-3"><div class="w-4 h-4 rounded-full" :style="'background:' + (c.color || '#dc2626')"></div><span class="font-medium text-gray-900" x-text="c.nombre"></span></div>
                  <button class="text-gray-300 hover:text-red-500 p-1" @click="eliminarCategoria(c)"><i class="bi bi-trash"></i></button>
                </div>
              </template>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() { this.items = []; this.categorias = []; this.loading = true; },
  nomCategoria(id) { const c = this.categorias.find(x => x.id === id); return c ? c.nombre : '\u2014'; },

  async cargarPlatillos() {
    try { this.loading = true; this.items = await db.platillos.orderBy('nombre').toArray(); }
    catch (e) { console.error(e); } finally { this.loading = false; }
  },
  async cargarCategorias() {
    try { this.categorias = await db.categorias.orderBy('orden').toArray(); } catch (e) { console.error(e); }
  },
  async sembrarCategorias() {
    const cats = [{nombre:'Bebidas',color:'#3b82f6'},{nombre:'Entradas',color:'#10b981'},{nombre:'Plato fuerte',color:'#dc2626'},{nombre:'Postres',color:'#f59e0b'},{nombre:'Guarniciones',color:'#8b5cf6'}];
    try { for (const c of cats) await db.categorias.put({ id: window.uuid(), nombre: c.nombre, color: c.color, orden: cats.indexOf(c), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }); await this.cargarCategorias(); } catch (e) { console.error(e); }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre</label><input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500" /></div><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Precio</label><input type="number" step="0.01" min="0" x-model="form.precio" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Categor\u00eda</label><select x-model="form.categoriaId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500 bg-white"><option value="">Sin categor\u00eda</option>' + (this.categorias || []).map(c => '<option value="' + c.id + '">' + c.nombre + '</option>').join('') + '</select></div></div></div>';
    await UI.modalForm(editando ? 'Editar Platillo' : 'Nuevo Platillo', html, async (data) => {
      if (!data.nombre?.trim()) { UI.toast('Nombre requerido', 'error'); return; }
      if (editando) { const e = await db.platillos.get(item.id); if (!e) return; await db.platillos.put({ ...e, nombre: data.nombre.trim(), precio: parseFloat(data.precio) || 0, categoriaId: data.categoriaId || '', updatedAt: new Date().toISOString() }); }
      else { await db.platillos.put({ id: window.uuid(), nombre: data.nombre.trim(), categoriaId: data.categoriaId || '', precio: parseFloat(data.precio) || 0, disponible: true, createdBy: 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }); }
      UI.toast(editando ? 'Actualizado' : 'Creado', 'success'); await this.cargarPlatillos();
    }, item || { nombre: '', precio: 0, categoriaId: '' });
  },

  async abrirFormCategoria() {
    const html = '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre</label><input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500" /><label class="block text-sm font-medium text-gray-700 mt-3 mb-1">Color</label><input type="color" x-model="form.color" class="w-full h-9 px-1 border border-gray-300 rounded-lg cursor-pointer" /></div>';
    await UI.modalForm('Nueva Categor\u00eda', html, async (data) => {
      if (!data.nombre?.trim()) { UI.toast('Nombre requerido', 'error'); return; }
      await db.categorias.put({ id: window.uuid(), nombre: data.nombre.trim(), color: data.color || '#dc2626', orden: this.categorias.length, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      UI.toast('Categor\u00eda creada', 'success'); await this.cargarCategorias();
    }, { nombre: '', color: '#dc2626' });
  },

  async eliminarCategoria(item) {
    if (!await UI.confirm('Eliminar ' + item.nombre + '?')) return;
    try { await db.categorias.delete(item.id); UI.toast('Eliminada', 'success'); await this.cargarCategorias(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['com-menu'] = ModuloComandaMenu;
document.addEventListener('alpine:init', () => { Alpine.data('comMenuData', () => ModuloComandaMenu); });
