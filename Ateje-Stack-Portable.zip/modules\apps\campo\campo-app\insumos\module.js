const ModuloCampoInsumos = {
  id: 'campo-insumos',
  titulo: 'Insumos',
  icono: 'bi bi-box-seam',

  items: [],
  item: null,
  formData: {},
  errors: {},
  searchQuery: '',
  loading: true,
  error: null,
  saving: false,
  page: 1,
  pageSize: 25,
  totalPages: 1,

  async init() {
    await this.cargarDatos();
  },

  render(params = {}) {
    return `
      <div x-data="campoInsumosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-amber-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-box-seam text-amber-600"></i> Insumos
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Agregar
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="buscar" placeholder="Buscar insumo..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition-shadow" />
          </div>
          <button class="inline-flex items-center gap-1.5 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors" @click="exportarPDF()" x-show="items.length">
            <i class="bi bi-file-earmark-pdf"></i> PDF
          </button>
        </div>

        <template x-if="error">
          <div class="p-4 mb-4 bg-red-50 border border-red-200 rounded-lg">
            <div class="flex items-center gap-2 text-red-700 text-sm">
              <i class="bi bi-exclamation-triangle"></i>
              <span x-text="error"></span>
            </div>
          </div>
        </template>

        <template x-if="!loading && !error && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-box-seam text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-4">No hay insumos registrados a\u00fan</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition-colors shadow-sm" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Agregar primer insumo
            </button>
          </div>
        </template>

        <template x-if="!loading && items.length > 0">
          <div>
            <div class="overflow-x-auto rounded-lg border border-gray-200">
              <table class="w-full text-sm">
                <thead>
                  <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Nombre</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Tipo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Stock</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Unidad</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Estado</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600">Acciones</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <tr x-for="(item, idx) in paginated" :key="item.id"
                      class="hover:bg-gray-50 transition-colors"
                      :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'">
                    <td class="px-4 py-3 text-gray-900 font-medium" x-text="item.nombre"></td>
                    <td class="px-4 py-3">
                      <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800" x-text="item.tipo || '—'"></span>
                    </td>
                    <td class="px-4 py-3">
                      <span class="font-semibold" :class="Number(item.stockActual) <= Number(item.stockMinimo) ? 'text-red-600' : 'text-gray-900'" x-text="item.stockActual || 0"></span>
                    </td>
                    <td class="px-4 py-3 text-gray-500" x-text="item.unidad || 'pza'"></td>
                    <td class="px-4 py-3">
                      <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                            :class="Number(item.stockActual) <= Number(item.stockMinimo) ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'"
                            x-text="Number(item.stockActual) <= Number(item.stockMinimo) ? 'Stock bajo' : 'Suficiente'"></span>
                    </td>
                    <td class="px-4 py-3 text-right">
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors" @click="abrirForm(item)" title="Editar">
                        <i class="bi bi-pencil"></i>
                      </button>
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" @click="eliminar(item)" title="Eliminar">
                        <i class="bi bi-trash"></i>
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div class="flex justify-between items-center mt-4" x-show="totalPages > 1">
              <span class="text-sm text-gray-500">
                P\u00e1gina <span class="font-medium text-gray-700" x-text="page"></span> de <span class="font-medium text-gray-700" x-text="totalPages"></span>
              </span>
              <div class="flex gap-2">
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === 1" @click="page--;">
                  <i class="bi bi-chevron-left"></i>
                </button>
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === totalPages" @click="page++;">
                  <i class="bi bi-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.item = null;
    this.searchQuery = '';
    this.loading = true;
    this.error = null;
    this.page = 1;
  },

  formatearFecha(fecha) {
    if (!fecha) return '';
    try {
      return new Date(fecha).toLocaleDateString('es-MX', {
        year: 'numeric', month: 'short', day: 'numeric'
      });
    } catch { return fecha; }
  },

  get paginated() {
    const start = (this.page - 1) * this.pageSize;
    return this.items.slice(start, start + this.pageSize);
  },

  _cifrarSensibles(obj) {
    for (const campo of (APP_CONFIG.cifrado.camposSensibles || [])) {
      if (obj[campo] && typeof obj[campo] === 'string' && !obj[campo].startsWith('U2FsdGVkX1')) {
        obj[campo] = cryptoHelpers.encrypt(obj[campo]);
      }
    }
    return obj;
  },

  _descifrarSensibles(obj) {
    if (!APP_CONFIG.cifrado.camposSensibles) return obj;
    for (const campo of APP_CONFIG.cifrado.camposSensibles) {
      if (obj[campo]) obj[campo] = cryptoHelpers.decrypt(obj[campo]);
    }
    return obj;
  },

  async cargarDatos() {
    try {
      this.loading = true;
      this.error = null;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.insumos.orderBy('createdAt').reverse().toArray();
      if (filtro) {
        datos = datos.filter(i =>
          (i.nombre || '').toLowerCase().includes(filtro) ||
          (i.tipo || '').toLowerCase().includes(filtro)
        );
      }
      this.items = datos;
      this.totalPages = Math.max(1, Math.ceil(this.items.length / this.pageSize));
      if (this.page > this.totalPages) this.page = this.totalPages;
    } catch (e) {
      console.error('Error cargando insumos:', e);
      this.error = 'Error al cargar insumos';
      UI.toast('Error al cargar insumos', 'error');
    } finally {
      this.loading = false;
    }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const descifrado = item ? this._descifrarSensibles({ ...item }) : {};
    const tipos = ['Semilla', 'Fertilizante', 'Herbicida', 'Plaguicida', 'Vacuna', 'Herramienta', 'Combustible', 'Otro'];
    const tipoOpts = tipos.map(t =>
      `<option value="${t}" ${descifrado.tipo === t ? 'selected' : ''}>${t}</option>`
    ).join('');
    const html = `
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>
          <input type="text" x-model="form.nombre"
                 class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                 :class="errors.nombre ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-amber-500 focus:border-amber-500'"
                 :class="errors.nombre ? 'focus:ring-2' : 'focus:ring-2'" />
          <template x-if="errors.nombre">
            <p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Tipo <span class="text-red-500">*</span></label>
          <select x-model="form.tipo"
                  class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                  :class="errors.tipo ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-amber-500 focus:border-amber-500'"
                  :class="errors.tipo ? 'focus:ring-2' : 'focus:ring-2'">
            <option value="">Seleccionar tipo...</option>
            ${tipoOpts}
          </select>
          <template x-if="errors.tipo">
            <p class="mt-1 text-sm text-red-500" x-text="errors.tipo"></p>
          </template>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Stock actual <span class="text-red-500">*</span></label>
            <input type="number" step="0.01" min="0" x-model="form.stockActual"
                   class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                   :class="errors.stockActual ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-amber-500 focus:border-amber-500'"
                   :class="errors.stockActual ? 'focus:ring-2' : 'focus:ring-2'" />
            <template x-if="errors.stockActual">
              <p class="mt-1 text-sm text-red-500" x-text="errors.stockActual"></p>
            </template>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Stock m\u00ednimo</label>
            <input type="number" step="0.01" min="0" x-model="form.stockMinimo"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-shadow" />
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Unidad <span class="text-red-500">*</span></label>
          <select x-model="form.unidad"
                  class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                  :class="errors.unidad ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-amber-500 focus:border-amber-500'"
                  :class="errors.unidad ? 'focus:ring-2' : 'focus:ring-2'">
            <option value="">Seleccionar unidad...</option>
            <option value="kg" ${descifrado.unidad === 'kg' ? 'selected' : ''}>Kilogramos (kg)</option>
            <option value="lt" ${descifrado.unidad === 'lt' ? 'selected' : ''}>Litros (lt)</option>
            <option value="pza" ${descifrado.unidad === 'pza' ? 'selected' : ''}>Piezas (pza)</option>
            <option value="saco" ${descifrado.unidad === 'saco' ? 'selected' : ''}>Sacos</option>
            <option value="dosis" ${descifrado.unidad === 'dosis' ? 'selected' : ''}>Dosis</option>
          </select>
          <template x-if="errors.unidad">
            <p class="mt-1 text-sm text-red-500" x-text="errors.unidad"></p>
          </template>
        </div>
      </div>`;
    await UI.modalForm(
      editando ? 'Editar Insumo' : 'Nuevo Insumo',
      html,
      async (data) => {
        if (editando) await this.actualizar(descifrado.id, data);
        else await this.guardar(data);
        await this.cargarDatos();
      },
      descifrado
    );
  },

  validarForm(datos) {
    this.errors = {};
    if (!datos.nombre || !datos.nombre.trim()) {
      this.errors.nombre = 'El nombre es obligatorio';
    }
    if (!datos.tipo) {
      this.errors.tipo = 'Seleccione un tipo';
    }
    if (datos.stockActual === '' || datos.stockActual === undefined || datos.stockActual === null) {
      this.errors.stockActual = 'Ingrese el stock actual';
    }
    if (!datos.unidad) {
      this.errors.unidad = 'Seleccione una unidad';
    }
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const registro = this._cifrarSensibles({
        id: uuid(),
        nombre: datos.nombre.trim(),
        tipo: datos.tipo,
        stockActual: parseFloat(datos.stockActual) || 0,
        stockMinimo: parseFloat(datos.stockMinimo) || 0,
        unidad: datos.unidad,
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      await db.insumos.put(registro);
      UI.toast('Insumo guardado correctamente', 'success');
    } catch (e) {
      console.error('Error al guardar insumo:', e);
      UI.toast('Error al guardar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const existente = await db.insumos.get(id);
      if (!existente) {
        UI.toast('Insumo no encontrado', 'error');
        return;
      }
      const actualizado = this._cifrarSensibles({
        ...existente,
        nombre: datos.nombre.trim(),
        tipo: datos.tipo,
        stockActual: parseFloat(datos.stockActual) || 0,
        stockMinimo: parseFloat(datos.stockMinimo) || 0,
        unidad: datos.unidad,
        updatedAt: new Date().toISOString()
      });
      await db.insumos.put(actualizado);
      UI.toast('Insumo actualizado correctamente', 'success');
    } catch (e) {
      console.error('Error al actualizar insumo:', e);
      UI.toast('Error al actualizar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar el insumo ' + (item.nombre || '') + '?');
    if (!ok) return;
    try {
      await db.insumos.delete(item.id);
      UI.toast('Insumo eliminado correctamente', 'success');
      await this.cargarDatos();
    } catch (e) {
      console.error('Error al eliminar insumo:', e);
      UI.toast(e.message, 'error');
    }
  },

  async buscar() {
    this.page = 1;
    await this.cargarDatos();
  },

  async limpiarBusqueda() {
    this.searchQuery = '';
    this.page = 1;
    await this.cargarDatos();
  },

  async exportarPDF() {
    if (!this.items.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const { jsPDF } = window.jspdf || {};
      if (!jsPDF) {
        UI.toast('jsPDF no disponible', 'error');
        return;
      }
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text('Insumos - Registro', 14, 20);
      doc.setFontSize(10);
      let y = 30;
      doc.text('Nombre', 14, y);
      doc.text('Tipo', 70, y);
      doc.text('Stock', 120, y);
      doc.text('Unidad', 155, y);
      y += 6;
      doc.setDrawColor(200);
      doc.line(14, y, 196, y);
      y += 4;
      for (const item of this.items) {
        if (y > 280) { doc.addPage(); y = 20; }
        doc.text(item.nombre || '', 14, y);
        doc.text(item.tipo || '—', 70, y);
        doc.text(String(item.stockActual || '0'), 120, y);
        doc.text(item.unidad || 'pza', 155, y);
        y += 6;
      }
      doc.save('insumos-registro.pdf');
      UI.toast('PDF exportado', 'success');
    } catch (e) {
      console.error('Error exportando PDF:', e);
      UI.toast('Error al exportar PDF', 'error');
    }
  },

  async exportarCSV() {
    if (!this.items.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const XLSX = window.XLSX;
      if (XLSX) {
        const ws = XLSX.utils.json_to_sheet(this.items.map(i => ({
          Nombre: i.nombre || '',
          Tipo: i.tipo || '',
          Stock: i.stockActual || 0,
          'Stock M\u00ednimo': i.stockMinimo || 0,
          Unidad: i.unidad || 'pza'
        })));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Insumos');
        XLSX.writeFile(wb, 'insumos-registro.xlsx');
        UI.toast('Excel exportado', 'success');
      } else {
        const cabeceras = ['Nombre', 'Tipo', 'Stock', 'Stock M\u00ednimo', 'Unidad'];
        const filas = this.items.map(i => [
          i.nombre || '',
          i.tipo || '',
          String(i.stockActual || '0'),
          String(i.stockMinimo || '0'),
          i.unidad || 'pza'
        ]);
        let csv = cabeceras.join(',') + '\n';
        for (const fila of filas) {
          csv += fila.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',') + '\n';
        }
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'insumos-registro.csv';
        a.click();
        URL.revokeObjectURL(url);
        UI.toast('CSV exportado', 'success');
      }
    } catch (e) {
      console.error('Error exportando:', e);
      UI.toast('Error al exportar', 'error');
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['campo-insumos'] = ModuloCampoInsumos;

document.addEventListener('alpine:init', () => {
  Alpine.data('campoInsumosData', () => ModuloCampoInsumos);
});
