# Catálogo de Módulos Ateje

15 apps · 15 plantillas Taildashboards · diseño consistente profesional moderno

---

## Shared (todas las apps)

Módulos que se usan en absolutamente TODAS las apps. Se crean una sola vez.

| Módulo | Carpeta | Inspirado en | Perfiles |
|--------|---------|-------------|:--------:|
| Dashboard | [`shared/_dashboard/`](shared/_dashboard/) | TailStats | Lite, Pro, Bus |
| Settings | [`shared/_settings/`](shared/_settings/) | TailAdmin | Lite, Pro, Bus |
| Profile | [`shared/_profile/`](shared/_profile/) | TailChat | Lite, Pro, Bus |
| About | [`shared/_about/`](shared/_about/) | TailAdmin | Lite, Pro, Bus |

## Transversales (opcionales)

Módulos que pueden agregarse a cualquier app. Feature-gated por licencia.

| Módulo | Carpeta | Inspirado en | Perfiles |
|--------|---------|-------------|:--------:|
| IA Chat | [`transversal/_ia-chat/`](transversal/_ia-chat/) | TailAI | Full (Pro/Bus) |
| Branding Panel | [`transversal/_branding-panel/`](transversal/_branding-panel/) | TailAdmin | Business |

---

## Apps por Vertical

### 🏪 Comercio

#### POS (TailStore)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Productos | [`apps/comercio/pos/productos/`](apps/comercio/pos/productos/) | Catálogo con grilla tipo ecommerce, KPIs inventario, filtros |
| Ventas | [`apps/comercio/pos/ventas/`](apps/comercio/pos/ventas/) | Carrito de compras + checkout + ticket |
| Corte | [`apps/comercio/pos/corte/`](apps/comercio/pos/corte/) | Corte de caja con conteo de efectivo |
| Devoluciones | [`apps/comercio/pos/devoluciones/`](apps/comercio/pos/devoluciones/) | Devoluciones + form de reembolso |
| Reportes | [`apps/comercio/pos/reportes/`](apps/comercio/pos/reportes/) | Charts, KPIs, export PDF/CSV |

#### Inventario (TailBox)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Productos | [`apps/comercio/inventario/productos/`](apps/comercio/inventario/productos/) | Catálogo con tabla CRUD, stock, precios |
| Movimientos | [`apps/comercio/inventario/movimientos/`](apps/comercio/inventario/movimientos/) | Entradas/salidas con historial |
| Ajustes | [`apps/comercio/inventario/ajustes/`](apps/comercio/inventario/ajustes/) | Ajustes de inventario físico |
| Reportes | [`apps/comercio/inventario/reportes/`](apps/comercio/inventario/reportes/) | Charts + export |

### 🍽️ Gastronomía

#### Comanda (TailChat)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Mesas | [`apps/gastronomia/comanda/mesas/`](apps/gastronomia/comanda/mesas/) | Layout tipo chat con mesas activas |
| Menú | [`apps/gastronomia/comanda/menu/`](apps/gastronomia/comanda/menu/) | Catálogo de platillos y bebidas |
| Pedidos | [`apps/gastronomia/comanda/pedidos/`](apps/gastronomia/comanda/pedidos/) | Streaming de pedidos en tiempo real |
| Cuentas | [`apps/gastronomia/comanda/cuentas/`](apps/gastronomia/comanda/cuentas/) | Cierre de cuentas + split + pago |

### 💇 Belleza y Servicios

#### Citas (TailAdmin)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Calendario | [`apps/belleza/citas/calendario/`](apps/belleza/citas/calendario/) | Grilla mensual con citas |
| Clientes | [`apps/belleza/citas/clientes/`](apps/belleza/citas/clientes/) | Directorio de clientes + historial |
| Servicios | [`apps/belleza/citas/servicios/`](apps/belleza/citas/servicios/) | Catálogo de servicios y precios |
| Agenda | [`apps/belleza/citas/agenda/`](apps/belleza/citas/agenda/) | Vista diaria de citas + disponibilidad |

### ⚕️ Salud

#### Rx (TailDesk)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Recetas | [`apps/salud/rx/recetas/`](apps/salud/rx/recetas/) | Recetas médicas + form |
| Pacientes | [`apps/salud/rx/pacientes/`](apps/salud/rx/pacientes/) | Expediente de pacientes |
| Medicamentos | [`apps/salud/rx/medicamentos/`](apps/salud/rx/medicamentos/) | Catálogo de medicamentos + dosificación |
| Historial | [`apps/salud/rx/historial/`](apps/salud/rx/historial/) | Historial clínico por paciente |

### 🏗️ Construcción y Obra

#### Obra (TailProject — inspiración)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Dashboard Obra | [`apps/construccion/obra/dashboard-obra/`](apps/construccion/obra/dashboard-obra/) | KPIs de avance, presupuesto, tiempos |
| Etapas | [`apps/construccion/obra/etapas/`](apps/construccion/obra/etapas/) | Kanban de etapas de construcción |
| Materiales | [`apps/construccion/obra/materiales/`](apps/construccion/obra/materiales/) | Control de materiales + proveedores |
| Personal | [`apps/construccion/obra/personal/`](apps/construccion/obra/personal/) | Registro de personal + jornales |
| Reportes | [`apps/construccion/obra/reportes/`](apps/construccion/obra/reportes/) | Reportes de obra + fotos |

#### Checklist (TailBox)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Listas | [`apps/construccion/checklist/listas/`](apps/construccion/checklist/listas/) | Listas de verificación |
| Items | [`apps/construccion/checklist/items/`](apps/construccion/checklist/items/) | Items checkeables con estado |
| Plantillas | [`apps/construccion/checklist/plantillas/`](apps/construccion/checklist/plantillas/) | Plantillas reutilizables |
| Reportes | [`apps/construccion/checklist/reportes/`](apps/construccion/checklist/reportes/) | Reportes de cumplimiento |

### 🌾 Campo y Agro

#### Campo (TailGame)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Lotes | [`apps/campo/campo-app/lotes/`](apps/campo/campo-app/lotes/) | Mapa/grilla de lotes de cultivo |
| Cultivos | [`apps/campo/campo-app/cultivos/`](apps/campo/campo-app/cultivos/) | Ciclos de cultivo + seguimiento |
| Cosechas | [`apps/campo/campo-app/cosechas/`](apps/campo/campo-app/cosechas/) | Registro de cosechas + rendimiento |
| Insumos | [`apps/campo/campo-app/insumos/`](apps/campo/campo-app/insumos/) | Control de insumos y fertilizantes |

### 🚚 Logística y Transporte

#### Flota (TailServer)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Vehículos | [`apps/logistica/flota/vehiculos/`](apps/logistica/flota/vehiculos/) | Monitoreo de unidades |
| Rutas | [`apps/logistica/flota/rutas/`](apps/logistica/flota/rutas/) | Planificación de rutas |
| Mantenimiento | [`apps/logistica/flota/mantenimiento/`](apps/logistica/flota/mantenimiento/) | Control de mantenimiento |
| Combustible | [`apps/logistica/flota/combustible/`](apps/logistica/flota/combustible/) | Carga de combustible + consumo |

### 💼 Oficina y Freelancers

#### CRM (TailLead)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Contactos | [`apps/oficina/crm/contactos/`](apps/oficina/crm/contactos/) | Directorio de contactos + empresas |
| Pipeline | [`apps/oficina/crm/pipeline/`](apps/oficina/crm/pipeline/) | Kanban de ventas por etapa |
| Cotizaciones | [`apps/oficina/crm/cotizaciones/`](apps/oficina/crm/cotizaciones/) | Cotizaciones + PDF |
| Facturación | [`apps/oficina/crm/facturacion/`](apps/oficina/crm/facturacion/) | Facturas + estados de cuenta |

#### Contactos (Tailism)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Directorio | [`apps/oficina/contactos/directorio/`](apps/oficina/contactos/directorio/) | Directorio con búsqueda + etiquetas |
| Grupos | [`apps/oficina/contactos/grupos/`](apps/oficina/contactos/grupos/) | Grupos de contactos |
| Etiquetas | [`apps/oficina/contactos/etiquetas/`](apps/oficina/contactos/etiquetas/) | Gestión de etiquetas y categorías |

### 💰 Finanzas

#### Gastos (TailBank)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Transacciones | [`apps/finanzas/gastos/transacciones/`](apps/finanzas/gastos/transacciones/) | Registro de gastos + ingresos |
| Categorías | [`apps/finanzas/gastos/categorias/`](apps/finanzas/gastos/categorias/) | Categorías + presupuesto asignado |
| Presupuestos | [`apps/finanzas/gastos/presupuestos/`](apps/finanzas/gastos/presupuestos/) | Presupuestos mensuales vs real |
| Reportes | [`apps/finanzas/gastos/reportes/`](apps/finanzas/gastos/reportes/) | Charts estado de resultados |

#### PreFactura (TailBank)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Cotizaciones | [`apps/finanzas/prefactura/cotizaciones/`](apps/finanzas/prefactura/cotizaciones/) | Cotizaciones + PDF |
| Facturas | [`apps/finanzas/prefactura/facturas/`](apps/finanzas/prefactura/facturas/) | Facturas + estados |
| Clientes | [`apps/finanzas/prefactura/clientes/`](apps/finanzas/prefactura/clientes/) | Catálogo de clientes |
| Plantillas | [`apps/finanzas/prefactura/plantillas/`](apps/finanzas/prefactura/plantillas/) | Plantillas de documentos |

### ⏰ Personal

#### Asistencia (TailAdmin)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Check-in | [`apps/personal/asistencia/checkin/`](apps/personal/asistencia/checkin/) | Registro de entrada/salida |
| Personal | [`apps/personal/asistencia/personal/`](apps/personal/asistencia/personal/) | Catálogo de empleados |
| Reportes | [`apps/personal/asistencia/reportes/`](apps/personal/asistencia/reportes/) | Reportes de asistencia |

### 🤖 IA

#### IA Jutía (TailAI)

| Módulo | Carpeta | Descripción |
|--------|---------|-------------|
| Chat | [`apps/ia/ia-jutia/chat/`](apps/ia/ia-jutia/chat/) | Chat con FlexSearch + Transformers.js |
| OCR | [`apps/ia/ia-jutia/ocr/`](apps/ia/ia-jutia/ocr/) | Reconocimiento de texto en imágenes |
| Búsqueda | [`apps/ia/ia-jutia/busqueda/`](apps/ia/ia-jutia/busqueda/) | Búsqueda híbrida en todos los datos |

---

## Cómo usar este catálogo

1. Abres la carpeta del módulo que necesitas
2. Copias `module.html` + `module.js` a tu proyecto (o el code-generator lo hace automáticamente)
3. Reemplazas placeholders `[ID]`, `[TITLE]`, `[ICON]`, etc.
4. Registras el módulo en `project.config.js` y en el sidebar
5. Listo — el módulo se renderiza via `window.appRouter.navigate('[id]')`

Para más detalle, abre [`REFERENCE-TEMPLATES.html`](REFERENCE-TEMPLATES.html) en el navegador.
