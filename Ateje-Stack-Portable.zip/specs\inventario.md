# AHA Inventario — Control de stock offline

## Perfil
lite

## IA Jutia
lite

## Módulos
- inventario (CRUD productos con SKU, categoría, precio, cantidad, imagen, umbral mínimo)
- categorias (CRUD categorías con nombre y color)
- movimientos (entradas/salidas de stock: producto, cantidad, tipo, motivo, fecha)
- alertas (umbral mínimo configurable, notificación visual)
- reportes (dashboard con totales, stock bajo, actividad, gráficos Chart.js, export CSV)

## Tablas Dexie
```javascript
db.version(2).stores({
  categorias: 'id, nombre, *color, createdAt, updatedAt',
  productos: 'id, nombre, *sku, *categoriaId, precio, cantidad, *imagen, *umbralMinimo, *createdBy, createdAt, updatedAt',
  movimientos: 'id, *productoId, *tipo, cantidad, *motivo, *createdBy, createdAt',
  alertas: 'id, *productoId, *tipo, leida, createdAt',
  _sync_log: 'id, *tabla, *operacion, *idRegistro, *estado, *fecha, *createdBy, createdAt'
});
```

## Campos sensibles
ninguno

## UI
- Toolbar con botón Agregar + búsqueda
- Tabla responsive con foto, nombre, SKU, precio, cantidad, acciones
- Modal para crear/editar productos
- Empty state cuando no hay datos
- Loading skeleton
- Barra lateral con iconos
- Dashboard con stats y gráficos

## Librerías adicionales
chart.js (para reportes)
qrcode.js (para QR en productos)

## project.config.js
```javascript
window.APP_CONFIG = {
  app: { id: 'aha-inventario', nombre: 'AHA Inventario', version: '1.0.0' },
  perfil: 'lite',
  iaJutia: { perfil: 'lite' },
  modulosActivos: ['inventario', 'categorias', 'movimientos', 'alertas', 'reportes'],
  tema: { modo: 'light', colores: { primary: '#1e3a5f', secondary: '#64748b', accent: '#0ea5e9' } },
  cifrado: { camposSensibles: [] },
  ui: { formsMode: 'modal', alerts: 'toast', confirmDelete: true, avatars: false },
  data: { dir: 'data/', maxFileSize: 10485760 },
  sync: { primaryFormat: 'json', encrypt: true }
};
```

## Component library
daisyui
