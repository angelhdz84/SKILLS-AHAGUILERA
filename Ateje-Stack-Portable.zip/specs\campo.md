# AHA Campo — Spec Técnica

## Identidad
- **App:** AHA Campo
- **Perfil:** Lite
- **Target:** Agricultores, ganaderos, ingenieros agrónomos, dueños de ranchos
- **Tagline:** Registro de campo offline para agricultura y ganadería
- **Color primario:** #16a34a (green-600)
- **Descripción:** Registro diario de lotes, cultivos, ganado, insumos y gastos.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  lotes: 'id, nombre, *hectareas, *cultivoActual, *createdBy, createdAt, updatedAt',
  ciclos: 'id, *loteId, *cultivo, *fechaSiembra, *fechaCosecha, *createdBy, createdAt, updatedAt',
  registros_diarios: 'id, *loteId, *fecha, *tipo, *descripcion, *fotos, *createdBy, createdAt',
  animales: 'id, *arete, nombre, *especie, *raza, *fechaNacimiento, *createdBy, createdAt, updatedAt',
  eventos_animal: 'id, *animalId, *tipo, *fecha, *descripcion, *proximaFecha, *createdBy, createdAt',
  insumos: 'id, nombre, *tipo, *stockActual, *stockMinimo, *unidad, *createdBy, createdAt, updatedAt',
  movimientos_insumo: 'id, *insumoId, *tipo, *cantidad, *loteId, *animalId, *proveedor, *costo, *createdBy, createdAt',
  gastos: 'id, *concepto, *monto, *categoria, *loteId, *createdBy, createdAt',
  _sync_log, _ia_chats, _ia_messages
});
```

Tipos registro diario: riego, fertilización, plaga, temperatura, otro
Especies: bovino, porcino, ovino, caprino, equino, aves
Tipos insumo: semilla, fertilizante, vacuna, herramienta, alimento
Categorías gasto: insumos, mano de obra, maquinaria, transporte

## Módulos (5)

### lotes
- CRUD: nombre, hectáreas, cultivo actual, estado
- Grid con cultivo actual y última actividad

### cultivos
- Ciclos por lote: fecha siembra, cultivo, variedad, fecha cosecha
- Registro diario: riego, fertilización, plagas, fotos

### ganado
- Registro animales: arete, especie, raza, fecha nacimiento
- Eventos: vacunación, pesaje, inseminación (con próximas fechas)
- Historial por animal

### insumos
- CRUD: nombre, tipo, stock, mínimo, unidad
- Entradas (compra) y salidas (aplicación)
- Alerta si stock < mínimo

### gastos + reportes
- Gastos por lote o general
- Dashboard: lotes activos, animales registrados, insumos bajos
- Chart.js gastos por categoría
- Export CSV

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema green (primary: #16a34a)
- Chart.js
- ES5 estricto
