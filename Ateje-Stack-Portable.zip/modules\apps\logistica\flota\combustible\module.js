const ModuloFlotaCombustible = {
  id: 'flota-combustible',
  titulo: 'Combustible',
  icono: 'bi bi-fuel-pump',

  items: [],
  vehiculos: [],
  loading: true,
  errors: {},
  filtroVehiculo: '',
  kpis: { totalLitros: 0, totalImporte: 0, recargas: 0, promedioKm: 0 },

  tipos: ['Regular', 'Premium', 'Diésel', 'EcoExtra'],

  async init() {
    await Promise.all([this.cargar(), this.cargarVehiculos()]);
  },

  render() {
    return `
      <div x-data="flotaCombustibleData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-amber-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-fuel-pump text-amber-600"></i> Combustible
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Recargas</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.recargas"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total litros</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.totalLitros.toFixed(1)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total importe</p>
            <p class="text-2xl font-bold text-gray-900" x-text="'$' + kpis.totalImporte.toLocaleString('es-MX', {minimumFractionDigits:2})"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Promedio km/l</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.promedioKm.toFixed(1)"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Carga
          </button>
          <select x-model="filtroVehiculo" @change="cargar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-amber-500 outline-none transition-shadow">
            <option value="">Todos los vehículos</option>
            <template x-for="v in vehiculos" :key="v.id">
              <option :value="v.id" x-text="v.placas + ' - ' + (v.marca || '')"></option>
            </template>
          </select>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-fuel-pump text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">Sin cargas registradas</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Registrar primera carga
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Fecha</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Vehículo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Tipo</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Litros</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Importe</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Km</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Rendimiento</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Acciones</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <template x-for="c in items" :key="c.id">
                    <tr class="hover:bg-gray-50 transition-colors cursor-pointer" @click="abrirForm(c)">
                      <td class="px-4 py-3 text-gray-500 text-xs whitespace-nowrap" x-text="formatearFecha(c.createdAt)"></td>
                      <td class="px-4 py-3 font-medium text-gray-900" x-text="nombreVehiculo(c.vehiculoId)"></td>
                      <td class="px-4 py-3"><span class="text-xs text-gray-500" x-text="c.tipo || 'Regular'"></span></td>
                      <td class="px-4 py-3 text-right font-mono font-medium text-gray-900" x-text="c.litros?.toFixed(1)"></td>
                      <td class="px-4 py-3 text-right font-mono font-medium text-gray-900" x-text="'$' + (c.importe || 0).toLocaleString('es-MX', {minimumFractionDigits:2})"></td>
                      <td class="px-4 py-3 text-right text-gray-500" x-text="c.kilometraje ? c.kilometraje.toLocaleString() + ' km' : '—'"></td>
                      <td class="px-4 py-3 text-right">
                        <span class="font-mono text-xs font-medium" :class="rendimientoClass(c)" x-text="calcularRendimiento(c)"></span>
                      </td>
                      <td class="px-4 py-3 text-right">
                        <button class="text-gray-400 hover:text-red-500 transition-colors p-1" @click.stop="eliminar(c)">
                          <i class="bi bi-trash"></i>
                        </button>
                      </td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-4">
                <div class="h-4 w-20 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-28 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-14 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-14 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-20 bg-gray-200 rounded animate-pulse ml-auto"></div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.vehiculos = [];
    this.filtroVehiculo = '';
    this.loading = true;
    this.kpis = { totalLitros: 0, totalImporte: 0, recargas: 0, promedioKm: 0 };
  },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch { return f; } },
  nombreVehiculo(id) { const v = this.vehiculos.find(x => x.id === id); return v ? (v.placas || v.numeroEconomico || '—') : '—'; },
  calcularRendimiento(c) { if (!c.kilometraje || !c.litros || c.litros <= 0) return '—'; return (c.kilometraje / c.litros).toFixed(1) + ' km/l'; },
  rendimientoClass(c) { if (!c.kilometraje || !c.litros || c.litros <= 0) return 'text-gray-400'; const r = c.kilometraje / c.litros; if (r >= 10) return 'text-green-600'; if (r >= 6) return 'text-amber-600'; return 'text-red-600'; },

  async cargar() {
    try {
      this.loading = true;
      let datos = await db.cargas_combustible.orderBy('createdAt').reverse().toArray();
      if (this.filtroVehiculo) datos = datos.filter(c => c.vehiculoId === this.filtroVehiculo);
      this.items = datos;
      const litros = datos.reduce((s, c) => s + (c.litros || 0), 0);
      const importe = datos.reduce((s, c) => s + (c.importe || 0), 0);
      const conKm = datos.filter(c => c.kilometraje && c.litros > 0);
      const promKm = conKm.length > 0 ? conKm.reduce((s, c) => s + (c.kilometraje / c.litros), 0) / conKm.length : 0;
      this.kpis = { totalLitros: litros, totalImporte: importe, recargas: datos.length, promedioKm: promKm };
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarVehiculos() {
    try { this.vehiculos = await db.vehiculos.orderBy('placas').toArray(); }
    catch (e) { console.error(e); }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div class="grid grid-cols-2 gap-4">',
      '<div class="col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Vehículo <span class="text-red-500">*</span></label>',
      '<select x-model="form.vehiculoId" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow bg-white"',
      ':class="errors.vehiculoId ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-amber-500\'">',
      '<option value="">Seleccionar...</option>',
      '<template x-for="v in vehiculos" :key="v.id"><option :value="v.id" x-text="v.placas + \' - \' + (v.marca || \'\') + \' \' + (v.modelo || \'\')"></option></template>',
      '</select><template x-if="errors.vehiculoId"><p class="mt-1 text-sm text-red-500" x-text="errors.vehiculoId"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Litros <span class="text-red-500">*</span></label>',
      '<input type="number" step="0.1" min="0" x-model="form.litros" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.litros ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500\'" />',
      '<template x-if="errors.litros"><p class="mt-1 text-sm text-red-500" x-text="errors.litros"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Importe <span class="text-red-500">*</span></label>',
      '<input type="number" step="0.01" min="0" x-model="form.importe" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.importe ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500\'" />',
      '<template x-if="errors.importe"><p class="mt-1 text-sm text-red-500" x-text="errors.importe"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Kilometraje</label>',
      '<input type="number" min="0" x-model="form.kilometraje" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Tipo</label>',
      '<select x-model="form.tipo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500 transition-shadow bg-white">',
      '<template x-for="t in tipos" :key="t"><option :value="t" x-text="t"></option></template>',
      '</select></div>',
      '</div></div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Carga' : 'Nueva Carga de Combustible', html,
      async (data) => {
        this.errors = {};
        if (!data.vehiculoId) { this.errors.vehiculoId = 'Selecciona un vehículo'; return; }
        if (!data.litros || parseFloat(data.litros) <= 0) { this.errors.litros = 'Litros válido requerido'; return; }
        if (data.importe == null || parseFloat(data.importe) < 0) { this.errors.importe = 'Importe válido requerido'; return; }
        if (editando) await this.actualizar(item.id, data);
        else await this.guardar(data);
        await this.cargar();
      }, item || { tipo: 'Regular' }
    );
  },

  async guardar(datos) {
    try {
      await db.cargas_combustible.put({
        id: uuid(), vehiculoId: datos.vehiculoId, litros: parseFloat(datos.litros),
        importe: parseFloat(datos.importe), kilometraje: parseInt(datos.kilometraje) || null,
        tipo: datos.tipo || 'Regular', createdAt: new Date().toISOString()
      });
      UI.toast('Carga registrada', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async actualizar(id, datos) {
    try {
      const e = await db.cargas_combustible.get(id);
      if (!e) { UI.toast('No encontrado', 'error'); return; }
      await db.cargas_combustible.put({ ...e, vehiculoId: datos.vehiculoId,
        litros: parseFloat(datos.litros), importe: parseFloat(datos.importe),
        kilometraje: parseInt(datos.kilometraje) || null, tipo: datos.tipo || 'Regular' });
      UI.toast('Carga actualizada', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar esta carga de combustible?');
    if (!ok) return;
    try { await db.cargas_combustible.delete(item.id); UI.toast('Eliminado', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['flota-combustible'] = ModuloFlotaCombustible;

document.addEventListener('alpine:init', () => {
  Alpine.data('flotaCombustibleData', () => ModuloFlotaCombustible);
});
