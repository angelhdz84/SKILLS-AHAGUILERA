const ModuloGastosMovimientos = {
  id: 'gastos-movimientos',
  titulo: 'Movimientos',
  icono: 'bi bi-arrow-left-right',

  items: [],
  categorias: [],
  filtroMes: '',
  filtroCategoria: '',
  filtroTipo: '',
  searchQuery: '',
  loading: true,
  errors: {},

  async init() {
    const d = new Date();
    this.filtroMes = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
    await Promise.all([this.cargarMovimientos(), this.cargarCategorias()]);
  },

  render() {
    return `
      <div x-data="gastosMovimientosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-violet-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-arrow-left-right text-violet-600"></i> Movimientos
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-violet-600 text-white text-sm font-medium rounded-lg hover:bg-violet-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Movimiento
          </button>
          <input type="month" x-model="filtroMes" @change="filtrar"
                 class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 focus:ring-2 focus:ring-violet-500 outline-none transition-shadow" />
          <select x-model="filtroCategoria" @change="filtrar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-violet-500 outline-none transition-shadow">
            <option value="">Todas las categor\u00edas</option>
            <template x-for="c in categorias" :key="c.id"><option :value="c.nombre" x-text="c.nombre"></option></template>
          </select>
          <select x-model="filtroTipo" @change="filtrar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-violet-500 outline-none transition-shadow">
            <option value="">Todos</option>
            <option value="ingreso">Ingreso</option>
            <option value="egreso">Egreso</option>
          </select>
          <div class="relative flex-1 min-w-[160px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="filtrar" placeholder="Buscar..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-violet-500 outline-none transition-shadow" />
          </div>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-arrow-left-right text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">Sin movimientos este mes</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-violet-600 text-white text-sm font-medium rounded-lg hover:bg-violet-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Registrar
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Fecha</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Concepto</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Categor\u00eda</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Tipo</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Monto</th>
                    <th class="text-center px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider"></th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <template x-for="m in items" :key="m.id">
                    <tr class="hover:bg-gray-50 transition-colors cursor-pointer" @click="abrirForm(m)">
                      <td class="px-4 py-3 text-gray-500 text-xs whitespace-nowrap" x-text="formatearFecha(m.fecha || m.createdAt)"></td>
                      <td class="px-4 py-3 font-medium text-gray-900" x-text="m.nota || 'Sin concepto'"></td>
                      <td class="px-4 py-3 text-gray-500" x-text="m.categoria || '\u2014'"></td>
                      <td class="px-4 py-3">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                              :class="m.tipo === 'ingreso' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'"
                              x-text="m.tipo"></span>
                      </td>
                      <td class="px-4 py-3 text-right font-mono font-bold" :class="m.tipo === 'ingreso' ? 'text-green-600' : 'text-red-600'"
                          x-text="(m.tipo === 'ingreso' ? '+' : '-') + '$' + Number(m.monto || 0).toLocaleString('es-MX')"></td>
                      <td class="px-4 py-3 text-center">
                        <button class="text-gray-300 hover:text-red-500 transition-colors p-1" @click.stop="eliminar(m)">
                          <i class="bi bi-trash"></i>
                        </button>
                      </td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-4"><div class="h-4 w-16 bg-gray-200 rounded animate-pulse"></div><div class="h-4 w-32 bg-gray-200 rounded animate-pulse"></div><div class="h-4 w-20 bg-gray-200 rounded animate-pulse ml-auto"></div></div></template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = []; this.categorias = []; this.filtroMes = ''; this.filtroCategoria = ''; this.filtroTipo = ''; this.searchQuery = ''; this.loading = true;
  },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return f; } },

  async cargarMovimientos() {
    try {
      this.loading = true;
      this.items = await db.movimientos.orderBy('fecha').reverse().toArray();
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarCategorias() {
    try { this.categorias = await db.categorias.orderBy('nombre').toArray(); }
    catch (e) { console.error(e); }
  },

  filtrar() {
    Promise.resolve().then(async () => {
      try {
        this.loading = true;
        let datos = await db.movimientos.orderBy('fecha').reverse().toArray();
        if (this.filtroMes) datos = datos.filter(m => (m.fecha || m.createdAt || '').startsWith(this.filtroMes));
        if (this.filtroCategoria) datos = datos.filter(m => m.categoria === this.filtroCategoria);
        if (this.filtroTipo) datos = datos.filter(m => m.tipo === this.filtroTipo);
        const q = this.searchQuery.trim().toLowerCase();
        if (q) datos = datos.filter(m => (m.nota || '').toLowerCase().includes(q) || (m.categoria || '').toLowerCase().includes(q));
        this.items = datos;
      } catch (e) { console.error(e); }
      finally { this.loading = false; }
    });
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Tipo <span class="text-red-500">*</span></label>',
      '<select x-model="form.tipo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-violet-500 transition-shadow bg-white">',
      '<option value="ingreso">Ingreso</option><option value="egreso">Egreso</option></select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Monto <span class="text-red-500">*</span></label>',
      '<input type="number" step="0.01" min="0" x-model="form.monto" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.monto ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-violet-500 focus:border-violet-500\'" />',
      '<template x-if="errors.monto"><p class="mt-1 text-sm text-red-500" x-text="errors.monto"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Categor\u00eda <span class="text-red-500">*</span></label>',
      '<select x-model="form.categoria" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-violet-500 transition-shadow bg-white">',
      '<option value="">Seleccionar...</option>',
      '<template x-for="c in categorias" :key="c.id"><option :value="c.nombre" x-text="c.nombre"></option></template>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Fecha</label>',
      '<input type="date" x-model="form.fecha" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-violet-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nota / Concepto</label>',
      '<textarea x-model="form.nota" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-violet-500 transition-shadow"></textarea></div>',
      '</div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Movimiento' : 'Nuevo Movimiento', html,
      async (data) => {
        this.errors = {};
        if (!data.monto || data.monto <= 0) { this.errors.monto = 'Monto v\u00e1lido requerido'; return; }
        if (!data.categoria) { this.errors.categoria = 'Selecciona una categor\u00eda'; return; }
        if (editando) {
          const e = await db.movimientos.get(item.id);
          if (!e) { UI.toast('No encontrado', 'error'); return; }
          await db.movimientos.put({ ...e, tipo: data.tipo, monto: parseFloat(data.monto), categoria: data.categoria, nota: data.nota?.trim() || '', fecha: data.fecha || new Date().toISOString().slice(0, 10), updatedAt: new Date().toISOString() });
        } else {
          await db.movimientos.put({ id: window.uuid(), tipo: data.tipo, monto: parseFloat(data.monto), categoria: data.categoria, nota: data.nota?.trim() || '', fecha: data.fecha || new Date().toISOString().slice(0, 10), createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString() });
        }
        UI.toast(editando ? 'Actualizado' : 'Guardado', 'success');
        await this.cargarMovimientos();
      }, item || { tipo: 'egreso', fecha: new Date().toISOString().slice(0, 10), monto: '', nota: '', categoria: '' }
    );
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar este movimiento?');
    if (!ok) return;
    try { await db.movimientos.delete(item.id); UI.toast('Eliminado', 'success'); await this.cargarMovimientos(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['gastos-movimientos'] = ModuloGastosMovimientos;

document.addEventListener('alpine:init', () => {
  Alpine.data('gastosMovimientosData', () => ModuloGastosMovimientos);
});
