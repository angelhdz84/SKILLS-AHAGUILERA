const ModuloGastosCategorias = {
  id: 'gastos-categorias',
  titulo: 'Categor\u00edas',
  icono: 'bi bi-tags',

  items: [],
  predefinidas: ['Renta', 'Luz', 'Agua', 'Internet', 'Mercanc\u00eda', 'N\u00f3mina', 'Transporte', 'Alimentos', 'Servicios', 'Otros'],
  loading: true,

  async init() {
    await this.cargar();
    if (this.items.length === 0) await this.sembrarPredefinidas();
  },

  render() {
    return `
      <div x-data="gastosCategoriasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-violet-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-tags text-violet-600"></i> Categor\u00edas
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-violet-600 text-white text-sm font-medium rounded-lg hover:bg-violet-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Categor\u00eda
          </button>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-tags text-6xl mb-4"></i>
            <p class="text-lg text-gray-500">Sin categor\u00edas</p>
          </div>
        </template>

        <template x-if="loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="i in 6" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-5 w-24 bg-gray-200 rounded animate-pulse"></div></div></template>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="c in items" :key="c.id">
              <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between hover:shadow-md transition-shadow group">
                <div class="flex items-center gap-3">
                  <div class="w-4 h-4 rounded-full" :style="'background:' + (c.color || '#8b5cf6')"></div>
                  <span class="font-medium text-gray-900" x-text="c.nombre"></span>
                </div>
                <div class="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button class="text-gray-300 hover:text-violet-500 transition-colors p-1" @click="abrirForm(c)"><i class="bi bi-pencil"></i></button>
                  <button class="text-gray-300 hover:text-red-500 transition-colors p-1" @click="eliminar(c)"><i class="bi bi-trash"></i></button>
                </div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() { this.items = []; this.loading = true; },

  async cargar() {
    try {
      this.loading = true;
      this.items = await db.categorias.orderBy('nombre').toArray();
    } catch (e) { console.error(e); }
    finally { this.loading = false; }
  },

  async sembrarPredefinidas() {
    try {
      for (const nombre of this.predefinidas) {
        await db.categorias.put({ id: window.uuid(), nombre, tipo: 'egreso', color: '#8b5cf6', createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      }
      await db.categorias.put({ id: window.uuid(), nombre: 'Ventas / Honorarios', tipo: 'ingreso', color: '#16a34a', createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      await this.cargar();
    } catch (e) { console.error(e); }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre</label><input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-violet-500 transition-shadow" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Color</label><input type="color" x-model="form.color" class="w-full h-9 px-1 border border-gray-300 rounded-lg cursor-pointer" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Tipo</label><select x-model="form.tipo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-violet-500 transition-shadow bg-white"><option value="egreso">Egreso</option><option value="ingreso">Ingreso</option></select></div></div>';
    await UI.modalForm(editando ? 'Editar' : 'Nueva Categor\u00eda', html,
      async (data) => {
        if (!data.nombre?.trim()) { UI.toast('Nombre requerido', 'error'); return; }
        if (editando) {
          const e = await db.categorias.get(item.id);
          if (!e) { UI.toast('No encontrada', 'error'); return; }
          await db.categorias.put({ ...e, nombre: data.nombre.trim(), color: data.color || '#8b5cf6', tipo: data.tipo, updatedAt: new Date().toISOString() });
        } else {
          await db.categorias.put({ id: window.uuid(), nombre: data.nombre.trim(), color: data.color || '#8b5cf6', tipo: data.tipo, createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        }
        UI.toast(editando ? 'Actualizada' : 'Creada', 'success');
        await this.cargar();
      }, item || { nombre: '', color: '#8b5cf6', tipo: 'egreso' }
    );
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar ' + item.nombre + '?');
    if (!ok) return;
    try { await db.categorias.delete(item.id); UI.toast('Eliminada', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['gastos-categorias'] = ModuloGastosCategorias;

document.addEventListener('alpine:init', () => {
  Alpine.data('gastosCategoriasData', () => ModuloGastosCategorias);
});
