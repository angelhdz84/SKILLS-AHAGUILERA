﻿const ModuloInvAjustes = {
  id: 'inv-ajustes',
  titulo: 'Alertas',
  icono: 'bi bi-bell',

  tab: 'alertas',
  alertas: [],
  productos: [],
  loading: true,

  async init() {
    await Promise.all([this.cargarAlertas(), this.cargarProductos()]);
  },

  render() {
    return `
      <div x-data="invAjustesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-emerald-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-bell text-emerald-600"></i> Alertas
          </h2>
        </div>

        <div class="flex gap-1 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'alertas' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'alertas'"><i class="bi bi-exclamation-triangle"></i> Alertas</button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'config' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'config'"><i class="bi bi-sliders"></i> Umbrales</button>
        </div>

        <template x-if="tab === 'alertas'">
          <div>
            <template x-if="loading">
              <div class="space-y-3"><template x-for="i in 5" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-4"><div class="h-5 w-5 bg-gray-200 rounded animate-pulse"></div><div class="h-4 w-32 bg-gray-200 rounded animate-pulse"></div><div class="h-3 w-16 bg-gray-200 rounded animate-pulse ml-auto"></div></div></template></div>
            </template>
            <template x-if="!loading && alertas.length === 0">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                <i class="bi bi-check-circle text-6xl text-green-400 mb-4"></i>
                <p class="text-lg text-gray-500">Todo en orden</p>
                <p class="text-sm text-gray-400 mt-1">No hay productos con stock bajo</p>
              </div>
            </template>
            <template x-if="alertas.length > 0">
              <div class="space-y-3">
                <template x-for="a in alertas" :key="a.id">
                  <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between hover:shadow-md transition-shadow"
                       :class="a.cantidad <= 0 ? 'border-l-4 border-l-red-500' : 'border-l-4 border-l-amber-500'">
                    <div class="flex items-center gap-3 min-w-0">
                      <div class="w-10 h-10 rounded-full flex items-center justify-center text-lg"
                           :class="a.cantidad <= 0 ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'">
                        <i :class="a.cantidad <= 0 ? 'bi bi-exclamation-circle' : 'bi bi-exclamation-triangle'"></i>
                      </div>
                      <div class="min-w-0">
                        <p class="font-medium text-gray-900 truncate" x-text="a.nombre"></p>
                        <p class="text-xs text-gray-500" x-text="'Stock actual: ' + (a.cantidad || 0) + ' uds | M\u00ednimo: ' + (a.umbralMinimo || 5) + ' uds'"></p>
                      </div>
                    </div>
                    <button class="shrink-0 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors"
                            :class="a.cantidad <= 0 ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-amber-600 text-white hover:bg-amber-700'"
                            @click="ajustarStock(a)">
                      <i class="bi bi-plus-lg"></i> Ajustar stock
                    </button>
                  </div>
                </template>
              </div>
            </template>
          </div>
        </template>

        <template x-if="tab === 'config'">
          <div>
            <p class="text-sm text-gray-500 mb-4">Configura el umbral m\u00ednimo de stock para cada producto</p>
            <template x-if="productos.length === 0">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                <i class="bi bi-box-seam text-6xl mb-4"></i>
                <p class="text-lg text-gray-500">Sin productos</p>
              </div>
            </template>
            <template x-if="productos.length > 0">
              <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div class="overflow-x-auto">
                  <table class="w-full text-sm">
                    <thead class="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Producto</th>
                        <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Stock actual</th>
                        <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Umbral m\u00ednimo</th>
                        <th class="text-center px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Estado</th>
                      </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                      <template x-for="p in productos" :key="p.id">
                        <tr class="hover:bg-gray-50 transition-colors">
                          <td class="px-4 py-3 font-medium text-gray-900" x-text="p.nombre"></td>
                          <td class="px-4 py-3 text-right font-mono" x-text="p.cantidad || 0"></td>
                          <td class="px-4 py-3 text-right">
                            <input type="number" min="0" :value="p.umbralMinimo || 5"
                                   @change="actualizarUmbral(p.id, $event.target.value)"
                                   class="w-16 text-right px-2 py-1 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-emerald-500 outline-none" />
                          </td>
                          <td class="px-4 py-3 text-center">
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                                  :class="(!p.cantidad || p.cantidad <= 0) ? 'bg-red-100 text-red-700' : (p.cantidad <= (p.umbralMinimo || 5)) ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'"
                                  x-text="(!p.cantidad || p.cantidad <= 0) ? 'Agotado' : (p.cantidad <= (p.umbralMinimo || 5)) ? 'Bajo' : 'OK'"></span>
                          </td>
                        </tr>
                      </template>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.tab = 'alertas'; this.alertas = []; this.productos = []; this.loading = true;
  },

  async cargarAlertas() {
    try {
      this.loading = true;
      const prods = await db.productos.toArray();
      this.alertas = prods.filter(p => {
        const c = p.cantidad || 0;
        const u = p.umbralMinimo || 5;
        return c <= u;
      }).map(p => ({ id: p.id, nombre: p.nombre, cantidad: p.cantidad || 0, umbralMinimo: p.umbralMinimo || 5 }));
    } catch (e) { console.error(e); }
    finally { this.loading = false; }
  },

  async cargarProductos() {
    try { this.productos = await db.productos.orderBy('nombre').toArray(); }
    catch (e) { console.error(e); }
  },

  async actualizarUmbral(id, val) {
    const num = parseInt(val);
    if (isNaN(num) || num < 0) return;
    try {
      const p = await db.productos.get(id);
      if (!p) return;
      await db.productos.put({ ...p, umbralMinimo: num, updatedAt: new Date().toISOString() });
      await this.cargarAlertas();
      UI.toast('Umbral actualizado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async ajustarStock(item) {
    const cant = item.cantidad || 0;
    const html = '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nueva cantidad para <strong>' + item.nombre + '</strong></label><input type="number" min="0" x-model="form.cantidad" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-shadow" /></div>';
    await UI.modalForm('Ajustar Stock', html,
      async (data) => {
        try {
          const p = await db.productos.get(item.id);
          if (!p) { UI.toast('No encontrado', 'error'); return; }
          const nueva = parseInt(data.cantidad) || 0;
          const vieja = p.cantidad || 0;
          await db.productos.put({ ...p, cantidad: nueva, updatedAt: new Date().toISOString() });
          if (nueva !== vieja) {
            await db.movimientos.put({
              id: window.uuid(), productoId: item.id, tipo: 'ajuste', cantidad: Math.abs(nueva - vieja),
              motivo: 'Ajuste manual desde alertas: de ' + vieja + ' a ' + nueva,
              createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString()
            });
          }
          UI.toast('Stock ajustado', 'success');
          await this.cargarAlertas();
        } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
      }, { cantidad: item.cantidad || 0 }
    );
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['inv-ajustes'] = ModuloInvAjustes;

document.addEventListener('alpine:init', () => {
  Alpine.data('invAjustesData', () => ModuloInvAjustes);
});
