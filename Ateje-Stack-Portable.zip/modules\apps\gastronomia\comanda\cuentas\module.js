const ModuloComandaCuentas = {
  id: 'com-cuentas', titulo: 'Cuentas', icono: 'bi bi-cash-coin',
  items: [], comandas: [], mesas: [], loading: true,

  async init() {
    const [c, coms, ms] = await Promise.all([
      db.cuentas?.orderBy('createdAt').reverse().toArray() || [],
      db.comandas?.orderBy('createdAt').reverse().toArray() || [],
      db.mesas?.toArray() || []
    ]);
    this.items = c; this.comandas = coms; this.mesas = ms; this.loading = false;
  },

  render() {
    return `
      <div x-data="comCuentasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-red-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2"><i class="bi bi-cash-coin text-red-600"></i> Cuentas</h2>
        </div>
        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 shadow-sm" @click="nuevaCuenta()"><i class="bi bi-plus-lg"></i> Cobrar comanda</button>
          <button class="inline-flex items-center gap-1.5 px-4 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50" @click="verCorte()"><i class="bi bi-calculator"></i> Corte del d\u00eda</button>
        </div>
        <template x-if="!loading && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-cash-coin text-6xl mb-4"></i><p class="text-lg text-gray-500">Sin cuentas hoy</p></div>
        </template>
        <template x-if="items.length > 0">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <table class="w-full text-sm"><thead class="bg-gray-50 border-b border-gray-200"><tr><th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase">Mesa</th><th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase">Pago</th><th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase">Total</th><th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase">Hora</th></tr></thead>
              <tbody class="divide-y divide-gray-100">
                <template x-for="c in items" :key="c.id">
                  <tr class="hover:bg-gray-50"><td class="px-4 py-3 font-medium" x-text="nomMesa(c.mesaId) || '\u2014'"></td><td class="px-4 py-3 capitalize" x-text="c.formaPago || '\u2014'"></td><td class="px-4 py-3 text-right font-mono font-bold text-green-600">$<span x-text="Number(c.total || 0).toLocaleString('es-MX')"></span></td><td class="px-4 py-3 text-xs text-gray-400" x-text="(c.createdAt || '').slice(11, 19)"></td></tr>
                </template>
              </tbody>
            </table>
          </div>
        </template>
        <template x-if="loading"><div class="space-y-3"><template x-for="i in 4" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-4 w-48 bg-gray-200 rounded animate-pulse"></div></div></template></div></template>
      </div>
    `;
  },

  destroy() { this.items = []; this.comandas = []; this.mesas = []; this.loading = true; },
  nomMesa(id) { const m = this.mesas.find(x => x.id === id); return m ? m.nombre : ''; },

  async nuevaCuenta() {
    const comsAbiertas = this.comandas.filter(c => c.estado === 'abierta');
    if (comsAbiertas.length === 0) { UI.toast('No hay comandas abiertas', 'error'); return; }
    const ops = comsAbiertas.map(c => '<option value="' + c.id + '">' + (this.nomMesa(c.mesaId) || '?') + ' - $' + Number(c.total || 0).toLocaleString() + '</option>').join('');
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Comanda</label><select x-model="form.comandaId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500 bg-white"><option value="">Seleccionar...</option>' + ops + '</select></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Split (personas)</label><input type="number" min="1" x-model="form.split" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Forma de pago</label><select x-model="form.formaPago" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500 bg-white"><option value="efectivo">Efectivo</option><option value="tarjeta">Tarjeta</option><option value="transferencia">Transferencia</option></select></div></div>';
    await UI.modalForm('Cobrar', html, async (data) => {
      if (!data.comandaId) { UI.toast('Selecciona comanda', 'error'); return; }
      const com = await db.comandas.get(data.comandaId);
      if (!com) return;
      await db.cuentas.put({ id: window.uuid(), comandaId: data.comandaId, mesaId: com.mesaId, total: com.total, split: parseInt(data.split) || 1, formaPago: data.formaPago, createdBy: 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      await db.comandas.put({ ...com, estado: 'cerrada', updatedAt: new Date().toISOString() });
      const mesa = await db.mesas.get(com.mesaId);
      if (mesa) await db.mesas.put({ ...mesa, estado: 'disponible', updatedAt: new Date().toISOString() });
      UI.toast(parseInt(data.split) > 1 ? 'Cuenta dividida en ' + data.split : 'Cuenta cerrada', 'success');
      const [cts, coms, ms] = await Promise.all([db.cuentas.orderBy('createdAt').reverse().toArray(), db.comandas.orderBy('createdAt').reverse().toArray(), db.mesas.toArray()]);
      this.items = cts; this.comandas = coms; this.mesas = ms;
    }, { comandaId: '', split: 1, formaPago: 'efectivo' });
  },

  async verCorte() {
    const hoy = new Date().toISOString().slice(0, 10);
    const cuentasHoy = this.items.filter(c => (c.createdAt || '').startsWith(hoy));
    const total = cuentasHoy.reduce((s, c) => s + Number(c.total || 0), 0);
    const porPago = {}; for (const c of cuentasHoy) { porPago[c.formaPago || 'efectivo'] = (porPago[c.formaPago || 'efectivo'] || 0) + Number(c.total || 0); }
    const html = '<div class="space-y-3"><h3 class="font-bold text-lg">Corte del d\u00eda</h3><p class="text-3xl font-bold text-gray-900">$' + total.toLocaleString('es-MX', {minimumFractionDigits:2}) + '</p><hr><p class="text-sm text-gray-500">Cuentas: ' + cuentasHoy.length + '</p><hr>' + Object.entries(porPago).map(([k, v]) => '<div class="flex justify-between text-sm"><span class="capitalize">' + k + '</span><span class="font-mono font-bold">$' + v.toLocaleString('es-MX', {minimumFractionDigits:2}) + '</span></div>').join('') + '</div>';
    UI.modalHtml('Corte del d\u00eda - ' + hoy, html);
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['com-cuentas'] = ModuloComandaCuentas;
document.addEventListener('alpine:init', () => { Alpine.data('comCuentasData', () => ModuloComandaCuentas); });
