# AHA Obra — Spec Técnica

## Identidad
- **App:** AHA Obra
- **Perfil:** Lite
- **Target:** Constructores, arquitectos, maestros de obra, contratistas
- **Tagline:** Control de construcción y avance de obra offline
- **Color primario:** #dc2626 (red-600)
- **Descripción:** Gestión de obras, etapas, materiales, gastos, fotos de avance y reportes.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  obras: 'id, nombre, direccion, *tipo, presupuestoTotal, *estado, *createdBy, createdAt, updatedAt',
  etapas: 'id, *obraId, nombre, *estado, avance, createdAt, updatedAt',
  materiales: 'id, *obraId, *etapaId, nombre, *unidad, cantidad, precioUnitario, stockMinimo, createdAt, updatedAt',
  gastos_obra: 'id, *obraId, *etapaId, concepto, monto, *categoria, *createdBy, createdAt, updatedAt',
  avances_fotos: 'id, *obraId, *etapaId, *imagen, descripcion, createdAt',
  _sync_log, _ia_chats, _ia_messages
});
```

Tipos obra: casa, edificio, local comercial, bodega, otro
Estados obra: planeada, en progreso, completada, en pausa
Etapas: cimentación, estructura, instalaciones, acabados, entrega
Categorías gasto: material, mano de obra, renta, otros

## Módulos (6)

### obras
- CRUD: nombre, dirección, tipo, presupuesto, fechas, estado
- Dashboard de obra individual: avance general, presupuesto vs gastado

### etapas
- Etapas predefinidas por obra
- Avance % por etapa, fechas, estado
- Barra de progreso visual

### materiales
- CRUD por obra/etapa: nombre, unidad, cantidad, precio unitario, stock mínimo
- Alerta visual si stock < mínimo

### gastos
- Registro por obra/etapa: concepto, monto, categoría
- Comparativa presupuesto vs gasto real

### fotos
- Registro de fotos de avance por obra/etapa con descripción
- Línea de tiempo visual

### reportes
- Dashboard: obras activas, presupuesto total vs ejercido, avance general
- Chart.js gráficos
- Export CSV

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema red (primary: #dc2626)
- Chart.js
- ES5 estricto
