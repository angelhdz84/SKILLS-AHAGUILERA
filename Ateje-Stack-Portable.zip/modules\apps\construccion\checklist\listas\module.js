const ModuloChkListas = {
  id: 'chk-listas',
  titulo: 'Ubicaciones',
  icono: 'bi bi-geo-alt',

  items: [],
  errors: {},
  searchQuery: '',
  loading: true,
  saving: false,

  async init() {
    await this.cargar();
  },

  render() {
    return `
      <div x-data="chkListasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-blue-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-geo-alt text-blue-600"></i> Ubicaciones
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Ubicaci\u00f3n
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="cargar" placeholder="Buscar ubicaciones..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-shadow" />
          </div>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-geo-alt text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">No hay ubicaciones</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Agregar primera
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="overflow-x-auto rounded-lg border border-gray-200">
            <table class="w-full text-sm">
              <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Nombre</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">\u00c1rea</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Creado</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Acciones</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-100">
                <template x-for="(item, idx) in items" :key="item.id">
                  <tr class="hover:bg-gray-50 transition-colors cursor-pointer"
                      :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'"
                      @click="abrirForm(item)">
                    <td class="px-4 py-3">
                      <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                          <i class="bi bi-building text-sm"></i>
                        </div>
                        <span class="text-gray-900 font-medium" x-text="item.nombre"></span>
                      </div>
                    </td>
                    <td class="px-4 py-3">
                      <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-700" x-text="item.area || '\u2014'"></span>
                    </td>
                    <td class="px-4 py-3 text-gray-500" x-text="formatearFecha(item.createdAt)"></td>
                    <td class="px-4 py-3 text-right">
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" @click.stop="abrirForm(item)" title="Editar">
                        <i class="bi bi-pencil"></i>
                      </button>
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" @click.stop="eliminar(item)" title="Eliminar">
                        <i class="bi bi-trash"></i>
                      </button>
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i">
              <div class="h-14 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.searchQuery = '';
    this.loading = true;
  },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return f; } },

  async cargar() {
    try {
      this.loading = true;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.ubicaciones.orderBy('createdAt').reverse().toArray();
      if (filtro) datos = datos.filter(u => (u.nombre || '').toLowerCase().includes(filtro) || (u.area || '').toLowerCase().includes(filtro));
      this.items = datos;
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>',
      '<input type="text" x-model="form.nombre" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.nombre ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500\'" />',
      '<template x-if="errors.nombre"><p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">\u00c1rea</label>',
      '<input type="text" x-model="form.area" placeholder="Ej: Edificio A, Planta baja, etc." class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div>',
      '</div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Ubicaci\u00f3n' : 'Nueva Ubicaci\u00f3n', html,
      async (data) => {
        if (editando) await this.actualizar(item.id, data);
        else await this.guardar(data);
        await this.cargar();
      }, item || { nombre: '', area: '' }
    );
  },

  validarForm(d) {
    this.errors = {};
    if (!d.nombre || !d.nombre.trim()) this.errors.nombre = 'El nombre es obligatorio';
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    try {
      await db.ubicaciones.put({
        id: uuid(), nombre: datos.nombre.trim(), area: datos.area?.trim() || '',
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      });
      UI.toast('Ubicaci\u00f3n guardada', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    try {
      const e = await db.ubicaciones.get(id);
      if (!e) { UI.toast('No encontrada', 'error'); return; }
      await db.ubicaciones.put({ ...e, nombre: datos.nombre.trim(), area: datos.area?.trim() || '', updatedAt: new Date().toISOString() });
      UI.toast('Ubicaci\u00f3n actualizada', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar ' + (item.nombre || 'esta ubicaci\u00f3n') + '?');
    if (!ok) return;
    try { await db.ubicaciones.delete(item.id); UI.toast('Eliminada', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['chk-listas'] = ModuloChkListas;

document.addEventListener('alpine:init', () => {
  Alpine.data('chkListasData', () => ModuloChkListas);
});
