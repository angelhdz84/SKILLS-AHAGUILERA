// modules/apps/ia/ia-jutia/chat/module.js — Chat IA
// Interfaz de chat conversacional sobre _ia_chats + _ia_messages
// Dependencias: window.db, Alpine.js

;(function () {
  'use strict';

  var COLOR_PURPLE = 'purple';

  var ModuloIaChat = {
    id: 'ia-chat',
    titulo: 'Chat IA',
    icono: 'bi bi-chat-dots',
    color: COLOR_PURPLE,

    items: [],
    loading: true,
    chats: [],
    messages: [],
    currentChatId: null,
    inputText: '',
    sending: false,
    view: 'list',
    chatTitulo: '',

    async init() {
      this.loading = true;
      await this._ensureTables();
      await this._cargarChats();
      this.loading = false;
    },

    async _ensureTables() {
      if (!window.db) return;
      if (!window.db._ia_chats) {
        try {
          window.db.version(window.db.verno || 1).stores({
            _ia_chats: 'id, titulo, modelo, createdBy, createdAt, updatedAt',
            _ia_messages: 'id, chatId, rol, contenido, createdBy, createdAt'
          });
        } catch (e) {
          console.warn('[ia-chat] No se pudieron crear tablas:', e);
        }
      }
    },

    async _cargarChats() {
      if (!window.db || !window.db._ia_chats) {
        this.chats = [];
        return;
      }
      try {
        this.chats = await window.db._ia_chats
          .orderBy('updatedAt')
          .reverse()
          .toArray();
      } catch (e) {
        console.warn('[ia-chat] Error cargando chats:', e);
        this.chats = [];
      }
    },

    async crearChat() {
      var titulo = (this.chatTitulo || '').trim();
      if (!titulo) {
        if (window.UI) window.UI.toast('Escribe un título para la conversación', 'warning');
        return;
      }
      if (!window.db || !window.db._ia_chats) return;

      var chat = {
        id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        titulo: titulo,
        modelo: 'lite',
        createdBy: window.APP_USER || 'local',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      try {
        await window.db._ia_chats.put(chat);
        this.chatTitulo = '';
        await this._cargarChats();
        this.abrirChat(chat.id);
      } catch (e) {
        console.warn('[ia-chat] Error creando chat:', e);
        if (window.UI) window.UI.toast('Error al crear chat', 'error');
      }
    },

    async abrirChat(chatId) {
      this.currentChatId = chatId;
      this.view = 'chat';
      this.messages = [];

      if (!window.db || !window.db._ia_messages) return;

      try {
        this.messages = await window.db._ia_messages
          .where('chatId')
          .equals(chatId)
          .sortBy('createdAt');
      } catch (e) {
        console.warn('[ia-chat] Error cargando mensajes:', e);
      }
    },

    async enviar() {
      var texto = this.inputText.trim();
      if (!texto || this.sending) return;
      this.sending = true;

      try {
        if (!this.currentChatId) {
          var chat = {
            id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
            titulo: texto.length > 40 ? texto.slice(0, 40) + '...' : texto,
            modelo: 'lite',
            createdBy: window.APP_USER || 'local',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
          if (window.db && window.db._ia_chats) {
            await window.db._ia_chats.put(chat);
            this.currentChatId = chat.id;
            await this._cargarChats();
          }
        }

        await this._addMessage(this.currentChatId, 'user', texto);
        this.inputText = '';

        var respuesta = await this._generarRespuesta(texto);
        await this._addMessage(this.currentChatId, 'ia', respuesta.respuesta, respuesta.fuente);

        if (window.db && window.db._ia_chats) {
          try {
            var chatRow = await window.db._ia_chats.get(this.currentChatId);
            if (chatRow) {
              chatRow.updatedAt = new Date().toISOString();
              chatRow.messageCount = (chatRow.messageCount || 0) + 1;
              await window.db._ia_chats.put(chatRow);
            }
          } catch (e) {}
        }

        this.messages = await window.db._ia_messages
          .where('chatId')
          .equals(this.currentChatId)
          .sortBy('createdAt');
      } catch (e) {
        console.warn('[ia-chat] Error enviando:', e);
        if (window.UI) window.UI.toast('Error al enviar mensaje', 'error');
      } finally {
        this.sending = false;
      }
    },

    async _addMessage(chatId, rol, contenido, fuente) {
      if (!window.db || !window.db._ia_messages) return;
      var msg = {
        id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
        chatId: chatId,
        rol: rol,
        contenido: contenido,
        fuente: fuente || null,
        createdBy: window.APP_USER || 'local',
        createdAt: new Date().toISOString()
      };
      await window.db._ia_messages.put(msg);
    },

    async _generarRespuesta(texto) {
      if (window.ia && window.ia.chat) {
        try {
          return await window.ia.chat.ask(this.currentChatId, texto);
        } catch (e) {
          console.warn('[ia-chat] ask fallback:', e);
        }
      }
      return {
        respuesta: 'Hola! Soy tu asistente IA offline. Puedes preguntarme sobre los datos de la app. (El motor de IA se está cargando)',
        fuente: null
      };
    },

    async eliminarChat(chatId) {
      if (!window.UI || !(await window.UI.confirm('¿Eliminar esta conversación?'))) {
        if (!window.UI) return;
      }
      try {
        if (window.db && window.db._ia_chats) {
          await window.db._ia_chats.delete(chatId);
        }
        if (window.db && window.db._ia_messages) {
          var msgs = await window.db._ia_messages.where('chatId').equals(chatId).toArray();
          for (var i = 0; i < msgs.length; i++) {
            await window.db._ia_messages.delete(msgs[i].id);
          }
        }
        if (this.currentChatId === chatId) {
          this.volverALista();
        }
        await this._cargarChats();
        if (window.UI) window.UI.toast('Conversación eliminada', 'info');
      } catch (e) {
        console.warn('[ia-chat] Error eliminando:', e);
      }
    },

    volverALista() {
      this.view = 'list';
      this.currentChatId = null;
      this.messages = [];
    },

    formatDate(d) {
      if (!d) return '';
      var date = new Date(d);
      if (isNaN(date.getTime())) return '';
      var meses = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
      return date.getDate() + ' ' + meses[date.getMonth()] + ' ' + date.getFullYear();
    },

    formatRelative(d) {
      if (!d) return '';
      var date = new Date(d);
      if (isNaN(date.getTime())) return '';
      var diff = Date.now() - date.getTime();
      var seg = Math.floor(Math.abs(diff) / 1000);
      if (seg < 60) return 'ahora';
      var min = Math.floor(seg / 60);
      if (min < 60) return 'hace ' + min + ' min';
      var hor = Math.floor(min / 60);
      if (hor < 24) return 'hace ' + hor + ' h';
      var dia = Math.floor(hor / 24);
      if (dia < 30) return 'hace ' + dia + ' días';
      return 'hace ' + Math.floor(dia / 30) + ' meses';
    },

    render() {
      return '<div x-data="iaChatData" class="p-4 max-w-4xl mx-auto">' +
        '<div class="flex items-center gap-3 mb-4">' +
          '<div class="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-purple-600 dark:text-purple-400">' +
            '<i class="bi bi-chat-dots text-lg"></i>' +
          '</div>' +
          '<div class="flex-1">' +
            '<h2 class="text-xl font-bold">Chat IA</h2>' +
            '<p class="text-sm text-base-content/60" x-text="currentChatId ? \'Conversación activa\' : \'Tus conversaciones\'"></p>' +
          '</div>' +
          '<button class="btn btn-ghost btn-sm" @click="volverALista()" x-show="view === \'chat\'">' +
            '<i class="bi bi-arrow-left"></i> Volver' +
          '</button>' +
        '</div>' +

        '<template x-if="loading">' +
          '<div class="flex items-center justify-center py-20">' +
            '<span class="loading loading-spinner loading-lg text-purple-500"></span>' +
          '</div>' +
        '</template>' +

        '<template x-if="!loading && view === \'list\'">' +
          '<div>' +
            '<div class="card bg-base-100 shadow-sm border border-base-200 mb-4">' +
              '<div class="card-body p-4">' +
                '<div class="flex gap-2">' +
                  '<input type="text" x-model="chatTitulo" @keydown.enter="crearChat()" placeholder="Nueva conversación..." class="input input-bordered flex-1" />' +
                  '<button class="btn btn-primary" @click="crearChat()" :disabled="!chatTitulo.trim()">' +
                    '<i class="bi bi-plus-lg"></i> Crear' +
                  '</button>' +
                '</div>' +
              '</div>' +
            '</div>' +

            '<template x-if="chats.length === 0">' +
              '<div class="flex flex-col items-center justify-center py-16 text-base-content/40">' +
                '<i class="bi bi-chat-square-text text-5xl mb-3"></i>' +
                '<p class="text-lg font-medium">Sin conversaciones</p>' +
                '<p class="text-sm">Crea una nueva conversación para empezar</p>' +
              '</div>' +
            '</template>' +

            '<div class="space-y-2">' +
              '<template x-for="chat in chats" :key="chat.id">' +
                '<div class="card bg-base-100 shadow-sm border border-base-200 hover:border-purple-300 cursor-pointer transition-colors" @click="abrirChat(chat.id)">' +
                  '<div class="card-body p-3 flex-row items-center">' +
                    '<div class="flex-1 min-w-0">' +
                      '<p class="font-medium truncate" x-text="chat.titulo"></p>' +
                      '<p class="text-xs text-base-content/50">' +
                        '<span x-text="formatRelative(chat.updatedAt)"></span>' +
                        '<span x-show="chat.messageCount"> · <span x-text="chat.messageCount"></span> mensajes</span>' +
                      '</p>' +
                    '</div>' +
                    '<button class="btn btn-ghost btn-xs text-error" @click.stop="eliminarChat(chat.id)" title="Eliminar">' +
                      '<i class="bi bi-trash3"></i>' +
                    '</button>' +
                  '</div>' +
                '</div>' +
              '</template>' +
            '</div>' +
          '</div>' +
        '</template>' +

        '<template x-if="!loading && view === \'chat\'">' +
          '<div class="flex flex-col h-[65vh]">' +
            '<div class="flex-1 overflow-y-auto mb-3 space-y-3 p-2 rounded-xl bg-base-200/30">' +
              '<template x-if="messages.length === 0">' +
                '<div class="flex flex-col items-center justify-center h-full text-base-content/40">' +
                  '<i class="bi bi-chat-square-dots text-5xl mb-3"></i>' +
                  '<p class="text-sm">Escribe algo para comenzar</p>' +
                '</div>' +
              '</template>' +
              '<template x-for="msg in messages" :key="msg.id">' +
                '<div class="flex" :class="msg.rol === \'user\' ? \'justify-end\' : \'justify-start\'">' +
                  '<div class="max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap" ' +
                    ':class="msg.rol === \'user\' ? \'bg-purple-600 text-white rounded-br-md\' : \'bg-base-100 border border-base-200 rounded-bl-md\'">' +
                    '<p class="[&amp;>strong]:font-semibold" x-text="msg.contenido"></p>' +
                    '<p class="text-[10px] opacity-50 mt-1" x-show="msg.fuente" x-text="\'Fuente: \' + msg.fuente"></p>' +
                  '</div>' +
                '</div>' +
              '</template>' +
              '<template x-if="sending">' +
                '<div class="flex justify-start">' +
                  '<div class="max-w-[80%] rounded-2xl px-4 py-3 bg-base-100 border border-base-200 rounded-bl-md">' +
                    '<span class="loading loading-dots loading-sm text-purple-500"></span>' +
                  '</div>' +
                '</div>' +
              '</template>' +
            '</div>' +

            '<div class="flex gap-2">' +
              '<input type="text" x-model="inputText" @keydown.enter="enviar()" placeholder="Escribe un mensaje..." ' +
                'class="input input-bordered flex-1" :disabled="sending" />' +
              '<button class="btn btn-purple btn-primary" @click="enviar()" :disabled="!inputText.trim() || sending">' +
                '<template x-if="!sending"><i class="bi bi-send"></i></template>' +
                '<template x-if="sending"><span class="loading loading-spinner loading-sm"></span></template>' +
              '</button>' +
            '</div>' +
          '</div>' +
        '</template>' +
      '</div>';
    },

    destroy() {
      this.items = [];
      this.chats = [];
      this.messages = [];
      this.currentChatId = null;
      this.loading = true;
    }
  };

  window.MODULES = window.MODULES || {};
  window.MODULES[ModuloIaChat.id] = ModuloIaChat;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      if (typeof Alpine !== 'undefined') {
        Alpine.data('iaChatData', function () { return ModuloIaChat; });
      }
    });
  } else {
    if (typeof Alpine !== 'undefined') {
      Alpine.data('iaChatData', function () { return ModuloIaChat; });
    }
  }
})();
