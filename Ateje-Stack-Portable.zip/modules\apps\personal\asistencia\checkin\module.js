const ModuloAsisCheckin = {
  id: 'asis-checkin',
  titulo: 'Marcaje',
  icono: 'bi bi-clock-fill',
  items: [],
  hoy: [],
  loading: true,
  empleados: [],

  async init() {
    console.log('[' + this.id + '] Inicializando');
    await this.cargar();
  },

  render() {
    if (this.loading) {
      return '<div class="p-4 space-y-3">' +
        '<div class="sk-el sk-heading"></div>' +
        '<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">' +
        '<div class="sk-el sk-card"></div>' +
        '<div class="sk-el sk-card"></div>' +
        '<div class="sk-el sk-card"></div>' +
        '<div class="sk-el sk-card"></div>' +
        '</div>' +
        '<div class="sk-el sk-heading mt-6"></div>' +
        '<div class="sk-el sk-row"></div>' +
        '<div class="sk-el sk-row"></div>' +
        '</div>';
    }

    var grid = this.empleados.filter(function(e) { return e.activo !== false; }).map(function(e, i) {
      var iniciales = (e.nombre || '??').split(' ').map(function(s) { return s[0]; }).join('').substring(0, 2).toUpperCase();
      var marcajesHoy = this.hoy.filter(function(m) { return m.empleadoId === e.id; });
      var entrada = marcajesHoy.find(function(m) { return m.tipo === 'entrada'; });
      var salida = marcajesHoy.find(function(m) { return m.tipo === 'salida'; });
      var estado = !entrada ? 'pendiente' : (!salida ? 'adentro' : 'completo');
      var estadoColor = estado === 'completo' ? 'border-l-green-500 bg-green-50 dark:bg-green-900/20' : (estado === 'adentro' ? 'border-l-amber-500 bg-amber-50 dark:bg-amber-900/20' : 'border-l-gray-300 bg-base-100');
      var badgeHTML = estado === 'completo' ? '<span class="badge badge-success badge-xs">Completo</span>'
        : (estado === 'adentro' ? '<span class="badge badge-warning badge-xs">Adentro</span>'
          : '<span class="badge badge-ghost badge-xs">Pendiente</span>');
      var accion = estado === 'completo' ? 'marcarSalida' : 'marcarEntrada';
      var iconoAccion = estado === 'completo' ? 'bi bi-box-arrow-left' : (estado === 'adentro' ? 'bi bi-box-arrow-left' : 'bi bi-box-arrow-in-right');
      var textAccion = estado === 'completo' ? 'Re-marcar' : (estado === 'adentro' ? 'Salida' : 'Entrada');
      var bgAccion = estado === 'completo' ? 'btn-ghost' : (estado === 'adentro' ? 'btn-warning' : 'btn-success');
      var horaEntrada = entrada ? new Date(entrada.hora).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' }) : '—';
      var horaSalida = salida ? new Date(salida.hora).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' }) : '—';

      return '<div class="stagger-item card card-ds border-l-4 ' + estadoColor + ' p-4 cursor-pointer hover:shadow-md transition-shadow" style="animation-delay:' + (i * 0.04) + 's">' +
        '<div class="flex items-start justify-between mb-2">' +
        '<div class="flex items-center gap-2">' +
        '<div class="avatar placeholder">' +
        '<div class="w-10 rounded-full bg-green-100 text-green-600 text-sm font-bold">' + iniciales + '</div>' +
        '</div>' +
        '<div><div class="font-semibold text-sm">' + this._esc(e.nombre) + '</div><div class="text-xs text-base-content/50">' + this._esc(e.puesto || '') + '</div></div>' +
        '</div>' +
        badgeHTML +
        '</div>' +
        '<div class="flex items-center justify-between text-xs text-base-content/60 mb-3">' +
        '<span><i class="bi bi-door-open"></i> ' + horaEntrada + '</span>' +
        '<span><i class="bi bi-door-closed"></i> ' + horaSalida + '</span>' +
        '</div>' +
        '<button class="btn ' + bgAccion + ' btn-sm w-full btn-spring" onclick="ModuloAsisCheckin.' + accion + '(\'' + e.id + '\')">' +
        '<i class="' + iconoAccion + '"></i> ' + textAccion +
        '</button>' +
        '</div>';
    }.bind(this)).join('');

    var hoyRows = this.hoy.map(function(m, i) {
      var emp = this.empleados.find(function(e) { return e.id === m.empleadoId; });
      var nombreEmp = emp ? emp.nombre : 'Desconocido';
      var iniciales = (nombreEmp || '??').split(' ').map(function(s) { return s[0]; }).join('').substring(0, 2).toUpperCase();
      var tipoBadge = m.tipo === 'entrada'
        ? '<span class="badge badge-success badge-xs"><i class="bi bi-box-arrow-in-right"></i> Entrada</span>'
        : '<span class="badge badge-warning badge-xs"><i class="bi bi-box-arrow-left"></i> Salida</span>';
      var hora = m.hora ? new Date(m.hora).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' }) : '—';
      var metodo = m.metodo || 'manual';
      return '<tr class="stagger-item" style="animation-delay:' + (i * 0.02) + 's">' +
        '<td><div class="flex items-center gap-2"><div class="avatar placeholder"><div class="w-7 rounded-full bg-base-200 text-base-content/60 text-xs font-bold">' + iniciales + '</div></div>' + this._esc(nombreEmp) + '</div></td>' +
        '<td>' + tipoBadge + '</td>' +
        '<td class="font-mono text-sm">' + hora + '</td>' +
        '<td class="hidden sm:table-cell text-xs text-base-content/50"><i class="bi bi-' + (metodo === 'qr' ? 'qr-code' : 'hand-index') + '"></i> ' + metodo + '</td>' +
        '<td><button class="btn btn-ghost btn-xs btn-square text-error" onclick="ModuloAsisCheckin._eliminarMarcaje(\'' + m.id + '\')" title="Eliminar"><i class="bi bi-x-lg"></i></button></td>' +
        '</tr>';
    }.bind(this)).join('');

    return '<div class="p-4">' +
      '<div class="flex items-center justify-between mb-4">' +
      '<h2 class="text-xl font-bold flex items-center gap-2"><i class="bi bi-clock-fill text-green-500"></i> Marcaje del día</h2>' +
      '<span class="text-sm text-base-content/50">' + new Date().toLocaleDateString('es', { weekday: 'long', day: 'numeric', month: 'long' }) + '</span>' +
      '</div>' +
      '<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mb-6">' + grid + '</div>' +
      '<div class="divider text-xs text-base-content/40 uppercase tracking-wider">Registros de hoy</div>' +
      (this.hoy.length === 0
        ? '<div class="empty-state"><div class="empty-state-icon bg-green-100"><i class="bi bi-clock-history text-green-500"></i></div><p class="empty-state-title">Sin registros hoy</p><p class="empty-state-desc">Los empleados aún no han marcado</p></div>'
        : '<div class="overflow-x-auto rounded-box border border-base-200"><table class="table table-sm"><thead><tr><th>Empleado</th><th>Tipo</th><th>Hora</th><th class="hidden sm:table-cell">Método</th><th></th></tr></thead><tbody>' + hoyRows + '</tbody></table></div>') +
      '</div>';
  },

  destroy() {
    this.items = [];
    this.hoy = [];
    this.empleados = [];
    this.loading = true;
  },

  async cargar() {
    this.loading = true;
    try {
      if (window.db) {
        this.empleados = db.empleados ? await db.empleados.orderBy('nombre').toArray() : [];
        var hoyStr = new Date().toISOString().slice(0, 10);
        if (db.marcajes) {
          this.hoy = await db.marcajes.where('fecha').equals(hoyStr).toArray();
          this.hoy.sort(function(a, b) { return new Date(b.hora) - new Date(a.hora); });
        } else {
          this.hoy = [];
        }
      } else {
        this.empleados = [];
        this.hoy = [];
      }
    } catch (e) {
      console.error('[' + this.id + '] Error al cargar:', e.message);
      this.empleados = [];
      this.hoy = [];
    }
    this.loading = false;
  },

  async marcarEntrada(empleadoId) {
    var emp = this.empleados.find(function(e) { return e.id === empleadoId; });
    if (!emp) return;

    var hoyD = new Date();
    var hoyStr = hoyD.toISOString().slice(0, 10);
    var hoyReg = this.hoy.filter(function(m) { return m.empleadoId === empleadoId; });
    var entrada = hoyReg.find(function(m) { return m.tipo === 'entrada'; });
    if (entrada && !hoyReg.find(function(m) { return m.tipo === 'salida'; })) {
      var ok = await UI.confirm(this._esc(emp.nombre) + ' ya marcó entrada hoy sin salida.<br>¿Marcar salida en su lugar?', 'Ya marcó entrada');
      if (ok) {
        await this.marcarSalida(empleadoId);
      }
      return;
    }

    try {
      var marcaje = {
        id: uuid(),
        empleadoId: empleadoId,
        tipo: 'entrada',
        fecha: hoyStr,
        hora: hoyD.toISOString(),
        ubicacion: '',
        metodo: 'manual',
        createdBy: (window.APP_CONFIG && APP_CONFIG.usuarioActual) || 'admin',
        createdAt: new Date()
      };
      await db.marcajes.put(marcaje);
      UI.toast(this._esc(emp.nombre) + ' — Entrada registrada', 'success');
      await this.cargar();
    } catch (e) {
      UI.toast('Error al marcar: ' + e.message, 'error');
    }
  },

  async marcarSalida(empleadoId) {
    var emp = this.empleados.find(function(e) { return e.id === empleadoId; });
    if (!emp) return;

    var hoyD = new Date();
    var hoyStr = hoyD.toISOString().slice(0, 10);
    var hoyReg = this.hoy.filter(function(m) { return m.empleadoId === empleadoId; });
    var entrada = hoyReg.find(function(m) { return m.tipo === 'entrada'; });
    if (!entrada) {
      var ok = await UI.confirm(this._esc(emp.nombre) + ' no marcó entrada hoy.<br>¿Marcar entrada primero?', 'Sin entrada');
      if (ok) {
        await this.marcarEntrada(empleadoId);
      }
      return;
    }
    var salida = hoyReg.find(function(m) { return m.tipo === 'salida'; });
    if (salida) {
      UI.toast(this._esc(emp.nombre) + ' ya registró salida hoy', 'warning');
      return;
    }

    try {
      var marcaje = {
        id: uuid(),
        empleadoId: empleadoId,
        tipo: 'salida',
        fecha: hoyStr,
        hora: hoyD.toISOString(),
        ubicacion: '',
        metodo: 'manual',
        createdBy: (window.APP_CONFIG && APP_CONFIG.usuarioActual) || 'admin',
        createdAt: new Date()
      };
      await db.marcajes.put(marcaje);
      UI.toast(this._esc(emp.nombre) + ' — Salida registrada', 'success');
      await this.cargar();
    } catch (e) {
      UI.toast('Error al marcar: ' + e.message, 'error');
    }
  },

  async _eliminarMarcaje(id) {
    var item = this.hoy.find(function(m) { return m.id === id; });
    if (!item) return;
    var ok = await UI.confirm('¿Eliminar este registro de marcaje?', 'Eliminar marcaje');
    if (!ok) return;
    try {
      await db.marcajes.delete(id);
      UI.toast('Marcaje eliminado', 'success');
      await this.cargar();
    } catch (e) {
      UI.toast('Error al eliminar: ' + e.message, 'error');
    }
  },

  _esc: function(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
};

window.MODULES = window.MODULES || {};
window.MODULES[ModuloAsisCheckin.id] = ModuloAsisCheckin;

document.addEventListener('alpine:init', function() {
  Alpine.data('asisCheckinData', function() { return ModuloAsisCheckin; });
});
