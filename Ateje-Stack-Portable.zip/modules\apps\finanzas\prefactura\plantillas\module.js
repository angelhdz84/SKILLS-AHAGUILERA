const ModuloPFReportes = {
  id: 'pf-reportes',
  titulo: 'Reportes',
  icono: 'bi bi-graph-up',

  loading: true,
  resumen: { totalMes: 0, facturasMes: 0, clientes: 0, promedio: 0 },
  facturas: [],
  clientes: [],
  chartInstance: null,

  async init() {
    const [facts, clis] = await Promise.all([
      db.facturas.orderBy('createdAt').reverse().toArray(),
      db.clientes_fiscales.toArray()
    ]);
    this.facturas = facts;
    this.clientes = clis;
    this.calcular();
    this.$nextTick(() => {
      const el = this.$el?.querySelector('#chartPF');
      if (el) setTimeout(() => this.renderChart(el), 100);
    });
    this.loading = false;
  },

  render() {
    return `
      <div x-data="pfReportesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-sky-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-graph-up text-sky-600"></i> Reportes
          </h2>
        </div>

        <template x-if="loading">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <template x-for="i in 4" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-3 w-16 bg-gray-200 animate-pulse mb-2"></div><div class="h-7 w-24 bg-gray-200 animate-pulse"></div></div></template>
          </div>
        </template>

        <template x-if="!loading">
          <div>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total facturado mes</p><p class="text-2xl font-bold text-sky-600" x-text="formatearMoneda(resumen.totalMes)"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Facturas este mes</p><p class="text-2xl font-bold text-gray-900" x-text="resumen.facturasMes"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Clientes registrados</p><p class="text-2xl font-bold text-gray-900" x-text="resumen.clientes"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Promedio por factura</p><p class="text-2xl font-bold text-emerald-600" x-text="formatearMoneda(resumen.promedio)"></p></div>
            </div>

            <div class="bg-white rounded-xl border border-gray-200 p-4 mb-6">
              <h3 class="font-semibold text-gray-900 mb-3 text-sm">Ingresos por mes (facturado)</h3>
              <canvas id="chartPF" class="max-h-64"></canvas>
            </div>

            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden mb-6">
              <div class="overflow-x-auto">
                <table class="w-full text-sm">
                  <thead class="bg-gray-50 border-b border-gray-200">
                    <tr><th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Folio</th><th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Cliente</th><th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Fecha</th><th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Total</th></tr>
                  </thead>
                  <tbody class="divide-y divide-gray-100">
                    <template x-for="f in facturas.slice(0, 10)" :key="f.id">
                      <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-4 py-3 font-mono text-xs font-bold text-sky-600" x-text="f.folio"></td>
                        <td class="px-4 py-3 text-gray-900" x-text="nombreCliente(f.clienteId)"></td>
                        <td class="px-4 py-3 text-gray-500 text-xs" x-text="formatearFecha(f.createdAt)"></td>
                        <td class="px-4 py-3 text-right font-mono font-bold" x-text="'$' + Number(f.total || 0).toLocaleString('es-MX')"></td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>

            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 text-white text-sm font-medium rounded-lg hover:bg-sky-700 transition-colors shadow-sm" @click="exportarCSV">
              <i class="bi bi-download"></i> Exportar CSV
            </button>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.loading = true; this.facturas = []; this.clientes = [];
    this.resumen = { totalMes: 0, facturasMes: 0, clientes: 0, promedio: 0 };
    if (this.chartInstance) { this.chartInstance.destroy(); this.chartInstance = null; }
  },

  formatearMoneda(v) { if (v == null || isNaN(v)) return '$0.00'; return '$' + Number(v).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); },
  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return f; } },
  nombreCliente(id) { const c = this.clientes.find(x => x.id === id); return c ? c.nombre : '\u2014'; },

  calcular() {
    const ahora = new Date();
    const mesActual = ahora.getFullYear() + '-' + String(ahora.getMonth() + 1).padStart(2, '0');
    const delMes = this.facturas.filter(f => (f.createdAt || '').startsWith(mesActual));
    const totalMes = delMes.reduce((s, f) => s + Number(f.total || 0), 0);
    const prom = this.facturas.length > 0 ? this.facturas.reduce((s, f) => s + Number(f.total || 0), 0) / this.facturas.length : 0;
    this.resumen = { totalMes, facturasMes: delMes.length, clientes: this.clientes.length, promedio: prom };
  },

  renderChart(el) {
    if (this.chartInstance) { this.chartInstance.destroy(); }
    const mapa = {};
    for (const f of this.facturas) {
      const mes = (f.createdAt || '').slice(0, 7);
      if (!mes) continue;
      if (!mapa[mes]) mapa[mes] = 0;
      mapa[mes] += Number(f.total || 0);
    }
    const periodos = Object.entries(mapa).sort(([a], [b]) => a.localeCompare(b));
    const meses = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    const labels = periodos.map(([k]) => { const [, m] = k.split('-'); return meses[parseInt(m) - 1]; });
    const datos = periodos.map(([, v]) => v);
    try {
      this.chartInstance = new Chart(el, {
        type: 'bar',
        data: { labels, datasets: [{ label: 'Facturado', data: datos, backgroundColor: '#0284c7', borderRadius: 6 }] },
        options: { responsive: true, maintainAspectRatio: true, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: '#f3f4f6' } } }, plugins: { legend: { display: false } } }
      });
    } catch (e) { console.error('Chart:', e); }
  },

  async exportarCSV() {
    try {
      let csv = '\uFEFFFolio,Fecha,Cliente,Subtotal,IVA,Total\n';
      for (const f of this.facturas) {
        const cli = this.clientes.find(c => c.id === f.clienteId);
        csv += (f.folio || '') + ',' + (f.createdAt || '').slice(0, 10) + ',' + (cli?.nombre || '\u2014') + ',' + (f.subtotal || 0) + ',' + (f.iva || 0) + ',' + (f.total || 0) + '\n';
      }
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'facturas_' + new Date().toISOString().slice(0, 10) + '.csv';
      link.click();
      URL.revokeObjectURL(link.href);
      UI.toast('CSV exportado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['pf-reportes'] = ModuloPFReportes;

document.addEventListener('alpine:init', () => {
  Alpine.data('pfReportesData', () => ModuloPFReportes);
});
