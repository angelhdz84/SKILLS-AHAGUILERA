﻿const ModuloCitasAgenda = {
  id: 'citas-agenda',
  titulo: 'Agenda',
  icono: 'bi bi-calendar-check',

  citas: [],
  clientes: [],
  servicios: [],
  profesionales: [],
  filtroProfesional: '',
  fecha: new Date().toISOString().split('T')[0],
  loading: true,
  kpis: { citasHoy: 0, pendientes: 0, completadas: 0, ingresosHoy: 0 },

  async init() {
    await Promise.all([this.cargarCatalogos(), this.cargarCitas()]);
  },

  render() {
    return 
      <div x-data="citasAgendaData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-pink-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-calendar-check text-pink-600"></i> Agenda
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Citas hoy</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.citasHoy"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Pendientes</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.pendientes"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Completadas</p>
            <p class="text-2xl font-bold text-green-600" x-text="kpis.completadas"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Ingresos hoy</p>
            <p class="text-2xl font-bold text-pink-600" x-text="formatearMoneda(kpis.ingresosHoy)"></p>
          </div>
        </div>

        <div class="flex flex-wrap items-center gap-3 mb-6">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-pink-600 text-white text-sm font-medium rounded-lg hover:bg-pink-700 transition-colors shadow-sm" @click="abrirFormCita()">
            <i class="bi bi-plus-lg"></i> Nueva cita
          </button>
          <div class="flex items-center gap-1">
            <button class="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors" @click="cambiarFecha(-1)">
              <i class="bi bi-chevron-left text-sm"></i>
            </button>
            <input type="date" x-model="fecha" @change="cargarCitas"
                   class="px-3 py-1.5 border border-gray-300 rounded-lg text-sm text-gray-700 focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none transition-shadow" />
            <button class="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors" @click="cambiarFecha(1)">
              <i class="bi bi-chevron-right text-sm"></i>
            </button>
            <button class="px-3 py-1.5 text-xs text-pink-600 hover:text-pink-700 font-medium" @click="fecha = new Date().toISOString().split('T')[0]; cargarCitas()">Hoy</button>
          </div>
          <select x-model="filtroProfesional" @change="cargarCitas"
                  class="px-3 py-1.5 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none transition-shadow">
            <option value="">Todos</option>
            <template x-for="p in profesionales" :key="p.id">
              <option :value="p.id" x-text="p.nombre"></option>
            </template>
          </select>
        </div>

        <template x-if="!loading && citas.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-calendar-check text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">Sin citas para esta fecha</p>
            <p class="text-sm text-gray-400 mb-6" x-text="formatearFecha(fecha)"></p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-pink-600 text-white text-sm font-medium rounded-lg hover:bg-pink-700 transition-colors" @click="abrirFormCita()">
              <i class="bi bi-plus-lg"></i> Agendar cita
            </button>
          </div>
        </template>

        <template x-if="!loading && citas.length > 0">
          <div class="space-y-3">
            <template x-for="c in citas" :key="c.id">
              <div class="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                <div class="flex items-stretch">
                  <div class="w-20 bg-gradient-to-b shrink-0 flex flex-col items-center justify-center p-3" :style="'background:' + colorProfesional(c.profesionalId)">
                    <span class="text-white text-lg font-bold" x-text="c.horaInicio ? c.horaInicio.substring(0,5) : '--'"></span>
                    <span class="text-white/80 text-xs mt-0.5" x-text="c.estado === 'completada' ? 'Hecha' : c.estado === 'cancelada' ? 'Cancelada' : 'Pend.'"></span>
                  </div>
                  <div class="flex-1 p-4">
                    <div class="flex items-start justify-between mb-1">
                      <div @click="abrirFormCita(c)" class="cursor-pointer flex-1">
                        <h3 class="font-semibold text-gray-900" x-text="nombreCliente(c.clienteId)"></h3>
                        <div class="flex items-center gap-3 text-xs text-gray-500">
                          <span><i class="bi bi-scissors"></i> <span x-text="nombreServicio(c.servicioId)"></span></span>
                          <span><i class="bi bi-person-badge"></i> <span x-text="nombreProfesional(c.profesionalId)"></span></span>
                        </div>
                      </div>
                      <div class="text-right shrink-0">
                        <div class="text-sm font-bold text-pink-600" x-text="formatearMoneda(precioServicio(c.servicioId))"></div>
                        <div class="flex gap-1 mt-1" x-show="c.estado !== 'completada' && c.estado !== 'cancelada'">
                          <button class="text-xs px-2 py-0.5 bg-green-100 text-green-700 rounded hover:bg-green-200 transition-colors" @click.stop="completarCita(c)">Hecha</button>
                          <button class="text-xs px-2 py-0.5 bg-red-100 text-red-600 rounded hover:bg-red-200 transition-colors" @click.stop="cancelarCita(c)">X</button>
                        </div>
                      </div>
                    </div>
                    <template x-if="c.estado === 'cancelada' && c.motivoCancelacion">
                      <div class="mt-1 text-xs text-red-500 bg-red-50 px-2 py-1 rounded inline-block">
                        <i class="bi bi-x-circle"></i> <span x-text="c.motivoCancelacion"></span>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
            </template>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 4" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div class="flex">
                  <div class="w-20 bg-gray-200 animate-pulse shrink-0"></div>
                  <div class="flex-1 p-4 space-y-2">
                    <div class="h-4 bg-gray-200 rounded animate-pulse w-1/3"></div>
                    <div class="h-3 bg-gray-200 rounded animate-pulse w-1/2"></div>
                  </div>
                </div>
              </div>
            </template>
          </div>
        </template>
      </div>
    ;
  },

  destroy() {
    this.citas = [];
    this.clientes = [];
    this.servicios = [];
    this.profesionales = [];
    this.filtroProfesional = '';
    this.loading = true;
    this.kpis = { citasHoy: 0, pendientes: 0, completadas: 0, ingresosHoy: 0 };
  },

  formatearMoneda(v) {
    if (v == null || isNaN(v)) return '.00';
    return '$' + Number(v).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  formatearFecha(f) {
    if (!f) return '';
    try { return new Date(f + 'T12:00:00').toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric' }); }
    catch { return f; }
  },

  nombreCliente(id) {
    const c = this.clientes.find(x => x.id === id); return c ? c.nombre : '\u2014';
  },
  nombreServicio(id) {
    const s = this.servicios.find(x => x.id === id); return s ? s.nombre : '\u2014';
  },
  nombreProfesional(id) {
    const p = this.profesionales.find(x => x.id === id); return p ? p.nombre : '\u2014';
  },
  precioServicio(id) {
    const s = this.servicios.find(x => x.id === id); return s ? (s.precio || 0) : 0;
  },
  colorProfesional(id) {
    const p = this.profesionales.find(x => x.id === id);
    return p && p.color ? p.color : '#ec4899';
  },

  async cargarCatalogos() {
    try {
      [this.clientes, this.servicios, this.profesionales] = await Promise.all([
        db.clientes.orderBy('nombre').toArray(),
        db.servicios.orderBy('nombre').toArray(),
        db.profesionales.orderBy('nombre').toArray()
      ]);
    } catch (e) { console.error('Error cargando catalogos:', e); }
  },

  async cargarCitas() {
    try {
      this.loading = true;
      let datos = await db.citas.where('fecha').equals(this.fecha).toArray();
      datos.sort((a, b) => (a.horaInicio || '00:00').localeCompare(b.horaInicio || '00:00'));
      if (this.filtroProfesional) datos = datos.filter(c => c.profesionalId === this.filtroProfesional);
      this.citas = datos;
      let pendientes = 0, completadas = 0, ingresos = 0;
      for (const c of datos) {
        if (c.estado === 'pendiente' || c.estado === 'confirmada') pendientes++;
        else if (c.estado === 'completada') { completadas++; ingresos += this.precioServicio(c.servicioId); }
      }
      this.kpis = { citasHoy: datos.length, pendientes, completadas, ingresosHoy: ingresos };
    } catch (e) {
      console.error('Error cargando citas:', e);
      UI.toast('Error al cargar citas', 'error');
    } finally { this.loading = false; }
  },

  cambiarFecha(delta) {
    const d = new Date(this.fecha + 'T12:00:00');
    d.setDate(d.getDate() + delta);
    this.fecha = d.toISOString().split('T')[0];
    this.cargarCitas();
  },

  async abrirFormCita(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Cliente <span class="text-red-500">*</span></label>',
      '<select x-model="form.clienteId" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow bg-white"',
      ':class="errors.clienteId ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-pink-500 focus:border-pink-500\'">',
      '<option value="">Seleccionar cliente...</option>',
      '<template x-for="c in clientes" :key="c.id"><option :value="c.id" x-text="c.nombre"></option></template>',
      '</select><template x-if="errors.clienteId"><p class="mt-1 text-sm text-red-500" x-text="errors.clienteId"></p></template></div>',
      '<div class="grid grid-cols-2 gap-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Servicio <span class="text-red-500">*</span></label>',
      '<select x-model="form.servicioId" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow bg-white"',
      ':class="errors.servicioId ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-pink-500 focus:border-pink-500\'">',
      '<option value="">Seleccionar...</option>',
      '<template x-for="s in servicios" :key="s.id"><option :value="s.id" x-text="s.nombre + \' (\' + formatearMoneda(s.precio) + \')\'"></option></template>',
      '</select><template x-if="errors.servicioId"><p class="mt-1 text-sm text-red-500" x-text="errors.servicioId"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Profesional <span class="text-red-500">*</span></label>',
      '<select x-model="form.profesionalId" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow bg-white"',
      ':class="errors.profesionalId ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-pink-500 focus:border-pink-500\'">',
      '<option value="">Seleccionar...</option>',
      '<template x-for="p in profesionales" :key="p.id"><option :value="p.id" x-text="p.nombre"></option></template>',
      '</select><template x-if="errors.profesionalId"><p class="mt-1 text-sm text-red-500" x-text="errors.profesionalId"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Fecha</label>',
      '<input type="date" x-model="form.fecha" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Hora</label>',
      '<input type="time" x-model="form.horaInicio" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-shadow" /></div>',
      '</div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Notas</label>',
      '<textarea x-model="form.notas" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-shadow"></textarea></div>',
      '</div>'
    ].join('\n');
    await UI.modalForm(
      editando ? 'Editar Cita' : 'Nueva Cita',
      html,
      async (data) => {
        if (!editando) data.estado = 'pendiente';
        if (editando) await this.actualizarCita(item.id, data);
        else await this.guardarCita(data);
        await this.cargarCitas();
      },
      item ? { ...item, fecha: item.fecha || this.fecha, horaInicio: item.horaInicio || '10:00' } : { fecha: this.fecha, horaInicio: '10:00' }
    );
  },

  validarCita(d) {
    this.errors = {};
    if (!d.clienteId) this.errors.clienteId = 'Selecciona un cliente';
    if (!d.servicioId) this.errors.servicioId = 'Selecciona un servicio';
    if (!d.profesionalId) this.errors.profesionalId = 'Selecciona un profesional';
    return Object.keys(this.errors).length === 0;
  },

  async guardarCita(datos) {
    if (!this.validarCita(datos)) return;
    try {
      const srv = this.servicios.find(s => s.id === datos.servicioId);
      const duracion = srv ? (srv.duracion || 30) : 30;
      const hInicio = datos.horaInicio || '10:00';
      const [h, m] = hInicio.split(':').map(Number);
      const fin = new Date(0, 0, 0, h, m + duracion);
      const hFin = String(fin.getHours()).padStart(2, '0') + ':' + String(fin.getMinutes()).padStart(2, '0');
      await db.citas.put({
        id: uuid(),
        clienteId: datos.clienteId,
        profesionalId: datos.profesionalId,
        servicioId: datos.servicioId,
        fecha: datos.fecha || this.fecha,
        horaInicio: hInicio,
        horaFin: hFin,
        estado: datos.estado || 'pendiente',
        notas: datos.notas?.trim() || '',
        motivoCancelacion: '',
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      UI.toast('Cita agendada', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async actualizarCita(id, datos) {
    if (!this.validarCita(datos)) return;
    try {
      const existente = await db.citas.get(id);
      if (!existente) { UI.toast('Cita no encontrada', 'error'); return; }
      const srv = this.servicios.find(s => s.id === (datos.servicioId || existente.servicioId));
      const duracion = srv ? (srv.duracion || 30) : 30;
      const hInicio = datos.horaInicio || existente.horaInicio;
      const [h, m] = hInicio.split(':').map(Number);
      const fin = new Date(0, 0, 0, h, m + duracion);
      const hFin = String(fin.getHours()).padStart(2, '0') + ':' + String(fin.getMinutes()).padStart(2, '0');
      await db.citas.put({
        ...existente,
        clienteId: datos.clienteId || existente.clienteId,
        profesionalId: datos.profesionalId || existente.profesionalId,
        servicioId: datos.servicioId || existente.servicioId,
        fecha: datos.fecha || existente.fecha,
        horaInicio: hInicio,
        horaFin: hFin,
        notas: datos.notas?.trim() ?? existente.notas,
        updatedAt: new Date().toISOString()
      });
      UI.toast('Cita actualizada', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async completarCita(item) {
    try {
      const c = await db.citas.get(item.id);
      if (!c) { UI.toast('Cita no encontrada', 'error'); return; }
      c.estado = 'completada';
      c.updatedAt = new Date().toISOString();
      await db.citas.put(c);
      const srv = this.servicios.find(s => s.id === c.servicioId);
      await this.actualizarClienteVisita(c.clienteId, srv ? srv.precio : 0);
      UI.toast('Cita completada', 'success');
      await this.cargarCitas();
    } catch (e) { UI.toast(e.message, 'error'); }
  },

  async cancelarCita(item) {
    const motivo = prompt('Motivo de cancelaci\u00f3n:');
    if (motivo === null) return;
    try {
      const c = await db.citas.get(item.id);
      if (!c) { UI.toast('Cita no encontrada', 'error'); return; }
      c.estado = 'cancelada';
      c.motivoCancelacion = motivo || 'Sin motivo';
      c.updatedAt = new Date().toISOString();
      await db.citas.put(c);
      UI.toast('Cita cancelada', 'success');
      await this.cargarCitas();
    } catch (e) { UI.toast(e.message, 'error'); }
  },

  async actualizarClienteVisita(clienteId, monto) {
    if (!clienteId) return;
    try {
      const c = await db.clientes.get(clienteId);
      if (c) {
        c.visitas = (c.visitas || 0) + 1;
        c.totalGastado = (c.totalGastado || 0) + (monto || 0);
        c.frecuente = c.visitas >= 3;
        c.updatedAt = new Date().toISOString();
        await db.clientes.put(c);
      }
    } catch (e) { console.error('Error actualizando visita:', e); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['citas-agenda'] = ModuloCitasAgenda;

document.addEventListener('alpine:init', () => {
  Alpine.data('citasAgendaData', () => ModuloCitasAgenda);
});
