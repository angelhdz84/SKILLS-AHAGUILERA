# AHA Contactos — Spec Técnica

## Identidad
- **App:** AHA Contactos
- **Perfil:** Lite
- **Target:** Vendedores, inmobiliarias, agentes de seguros, pymes
- **Tagline:** CRM manual companion para vendedores
- **Color primario:** #6366f1 (indigo-500)
- **Descripción:** Gestiona contactos de ventas, da seguimiento, organiza agenda comercial offline.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  contactos: 'id, nombre, *telefono, *email, *empresa, *etiqueta, *notas, *ultimoContacto, *createdBy, createdAt, updatedAt',
  historial: 'id, *contactoId, *tipo, *descripcion, *fecha, createdAt',
  plantillas: 'id, nombre, *contenido, *categoria, *createdBy, createdAt, updatedAt',
  recordatorios: 'id, *contactoId, *fecha, *nota, completado, *createdBy, createdAt, updatedAt',
  _sync_log: 'id, *tabla, *operacion, *idRegistro, *estado, *fecha, *createdBy, createdAt',
  _ia_chats: 'id, *titulo, *modelo, *createdBy, createdAt, updatedAt',
  _ia_messages: 'id, *chatId, *rol, contenido, *createdBy, createdAt'
});
```

Etiquetas predefinidas: prospecto, cliente, VIP, inactivo
Tipos historial: llamada, mensaje, reunión, nota
Categorías plantillas: saludo, seguimiento, oferta, cobro, cierre

## Entry point
`core/main.js`

## Módulos (5)

### dashboard
- Contactos nuevos del día (hoy)
- Seguimientos pendientes (recordatorios activos)
- Total clientes por etiqueta (donut chart)
- Stats cards + chart

### contactos
- CRUD: nombre, teléfono, email, empresa, notas, etiqueta (select)
- Lista con búsqueda instantánea
- Badges de etiqueta (prospecto/amarillo, cliente/verde, VIP/dorado, inactivo/gris)
- Modal CRUD

### historial
- Timeline de interacciones por contacto
- Tipos: llamada, mensaje, reunión, nota (con iconos)
- Registro manual con fecha y descripción
- Filtro por contacto

### plantillas
- Grid de tarjetas por categoría (saludo, seguimiento, oferta, cobro, cierre)
- Botón copiar al portapapeles
- Editor crear/editar plantillas

### recordatorios
- Lista con check completado
- Fecha asignada, nota, contacto relacionado
- Filtro: hoy / semana / todos

### Export (integrado en toolbar)
- CSV de contactos con filtro por etiqueta

## Estructura

```
aha-contactos/
├── index.html, manifest.json, sw.js, project.config.js, .gitignore, README.md
├── core/ (main, app, db, crypto, theme, ui, env, network, sync, seed, search-palette, file-store, license)
├── modules/
│   ├── dashboard/module.html + module.js
│   ├── contactos/module.html + module.js
│   ├── historial/module.html + module.js
│   ├── plantillas/module.html + module.js
│   └── recordatorios/module.html + module.js
├── assets/js/libs/ (alpine, dexie, crypto-js, pako, chart.js)
├── assets/css/ (daisyui, tailwind.play, bootstrap-icons, animate.min)
├── assets/icons/ (icon-192, icon-512)
└── data/defaults/ (avatar.svg, placeholder.svg)
```

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema indigo (color primary: #6366f1)
- Chart.js para gráficos (donut dashboard)
- ES5 estricto
