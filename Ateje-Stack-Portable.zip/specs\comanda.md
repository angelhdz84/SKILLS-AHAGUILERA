# AHA Comanda — Toma de pedidos offline para restaurantes

## Perfil
lite

## IA Jutia
lite

## Módulos
- **dashboard** (panel resumen: mesas del día, comandas activas, total del día, platillo más vendido, hora pico)
- **mesas** (gestión de mesas: nombre/número, capacidad, ubicación, estados: disponible/ocupada/cuenta, mapa visual del salón con colores)
- **comandas** (crear comanda por mesa, agregar platillos por categoría, cantidad, notas por platillo, historial por fecha)
- **platillos** (CRUD platillos: nombre, categoría, precio, disponible/no disponible, foto opcional desde archivo)
- **cuentas** (cerrar comanda, total con subtotal por item, split entre N personas, formas de pago: efectivo/tarjeta/transferencia)
- **cortes** (corte de caja del día, total ventas por forma de pago, platillos más vendidos, export PDF y CSV)

## Tablas Dexie
```javascript
db.version(2).stores({
  mesas: 'id, nombre, *capacidad, estado, *createdBy, createdAt, updatedAt',
  categorias: 'id, nombre, *color, orden, createdAt, updatedAt',
  platillos: 'id, nombre, *categoriaId, precio, disponible, *imagen, *createdBy, createdAt, updatedAt',
  comandas: 'id, *mesaId, *estado, items, total, *createdBy, createdAt, updatedAt',
  cuentas: 'id, *comandaId, total, split, formaPago, *createdBy, createdAt, updatedAt',
  cortes: 'id, fecha, totalVentas, *porFormaPago, *platillosVendidos, *createdBy, createdAt, updatedAt',
  _sync_log: 'id, *tabla, *operacion, *idRegistro, *estado, *fecha, *createdBy, createdAt',
  _ia_chats: 'id, *titulo, *modelo, *createdBy, createdAt, updatedAt',
  _ia_messages: 'id, *chatId, *rol, contenido, *createdBy, createdAt'
});
```

## Campos sensibles
ninguno

## UI
- Mapa de mesas visual con grid y colores (verde=libre, rojo=ocupada, amarillo=cuenta)
- Toolbar con botón Agregar + búsqueda
- Tablas responsive
- Modal para formularios
- Empty state cuando no hay datos
- Loading skeleton
- Barra lateral con iconos
- Dashboard con stats y cards
- Export PDF para cortes

## Librerías adicionales
chart.js

## project.config.js
```javascript
window.APP_CONFIG = {
  app: { id: 'aha-comanda', nombre: 'AHA Comanda', version: '1.0.0' },
  perfil: 'lite',
  iaJutia: { perfil: 'lite' },
  modulosActivos: ['dashboard', 'mesas', 'comandas', 'platillos', 'cuentas', 'cortes'],
  tema: { modo: 'light', colores: { primary: '#b91c1c', secondary: '#78716c', accent: '#f59e0b' } },
  cifrado: { camposSensibles: [] },
  ui: { formsMode: 'modal', alerts: 'toast', confirmDelete: true, avatars: false },
  data: { dir: 'data/', maxFileSize: 10485760 },
  sync: { primaryFormat: 'json', encrypt: true }
};
```

## Component library
daisyui
