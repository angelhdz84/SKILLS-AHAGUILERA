const ModuloPOSCorte = {
  id: 'pos-corte',
  titulo: 'Corte de Caja',
  icono: 'bi bi-cash-stack',

  denominaciones: [
    { valor: 1000, etiqueta: '$1,000', cantidad: 0 },
    { valor: 500, etiqueta: '$500', cantidad: 0 },
    { valor: 200, etiqueta: '$200', cantidad: 0 },
    { valor: 100, etiqueta: '$100', cantidad: 0 },
    { valor: 50, etiqueta: '$50', cantidad: 0 },
    { valor: 20, etiqueta: '$20', cantidad: 0 },
    { valor: 10, etiqueta: '$10', cantidad: 0 },
    { valor: 5, etiqueta: '$5', cantidad: 0 },
    { valor: 2, etiqueta: '$2', cantidad: 0 },
    { valor: 1, etiqueta: '$1', cantidad: 0 }
  ],
  turno: 'unico',
  observaciones: '',
  historial: [],
  cargando: true,
  guardando: false,
  kpis: { esperado: 0, transacciones: 0, contado: 0, diferencia: 0, diferenciaPorcentaje: 0 },

  async init() {
    await Promise.all([this.cargarHistorial(), this.calcularEsperado()]);
  },

  render(params = {}) {
    return ModuloPOSCorte.renderStatic(params);
  },

  renderStatic(params = {}) {
    return `
      <div x-data="posCorteData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-indigo-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-cash-stack text-indigo-600"></i> Corte de Caja
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Esperado</p>
            <p class="text-2xl font-bold text-gray-900" x-text="formatearMoneda(kpis.esperado)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Contado</p>
            <p class="text-2xl font-bold text-indigo-600" x-text="formatearMoneda(kpis.contado)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Diferencia</p>
            <p class="text-2xl font-bold" :class="kpis.diferencia >= 0 ? 'text-green-600' : 'text-red-600'"
                 x-text="(kpis.diferencia >= 0 ? '+' : '') + formatearMoneda(kpis.diferencia)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Desviaci\u00f3n</p>
            <p class="text-2xl font-bold" :class="Math.abs(kpis.diferenciaPorcentaje) <= 1 ? 'text-green-600' : 'text-amber-600'"
                 x-text="(kpis.diferenciaPorcentaje >= 0 ? '+' : '') + kpis.diferenciaPorcentaje.toFixed(2) + '%'"></p>
          </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <h3 class="font-semibold text-gray-900 mb-4">Conteo de efectivo</h3>
            <div class="space-y-3">
              <template x-for="(den, i) in denominaciones" :key="den.valor">
                <div class="flex items-center gap-3">
                  <span class="w-24 text-sm font-medium text-gray-700" x-text="den.etiqueta"></span>
                  <span class="text-xs text-gray-400 w-12" x-text="'x' + den.cantidad"></span>
                  <input type="number" min="0" x-model="den.cantidad" @input="recalcularConteo"
                         class="w-20 px-2 py-1.5 border border-gray-300 rounded-lg text-sm text-center text-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" />
                  <span class="text-sm font-medium text-gray-900 w-24 text-right" x-text="formatearMoneda(den.valor * den.cantidad)"></span>
                </div>
              </template>
              <div class="pt-3 border-t border-gray-200 flex items-center justify-between">
                <span class="font-semibold text-gray-900">Total contado</span>
                <span class="text-lg font-bold text-indigo-600" x-text="formatearMoneda(totalContado)"></span>
              </div>
            </div>
          </div>

          <div class="space-y-4">
            <div class="bg-white rounded-xl border border-gray-200 p-4">
              <h3 class="font-semibold text-gray-900 mb-4">Resumen del d\u00eda</h3>
              <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                  <span class="text-gray-500">Ventas del d\u00eda</span>
                  <span class="font-medium text-gray-900" x-text="formatearMoneda(kpis.esperado)"></span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-500">Transacciones</span>
                  <span class="font-medium text-gray-900" x-text="kpis.transacciones"></span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-500">Total contado</span>
                  <span class="font-medium" :class="kpis.diferencia >= 0 ? 'text-green-600' : 'text-red-600'"
                        x-text="formatearMoneda(kpis.contado)"></span>
                </div>
                <div class="pt-2 border-t border-gray-200">
                  <div class="flex justify-between">
                    <span class="font-semibold text-gray-900">Diferencia</span>
                    <span class="font-semibold" :class="kpis.diferencia >= 0 ? 'text-green-600' : 'text-red-600'"
                          x-text="(kpis.diferencia >= 0 ? '+' : '') + formatearMoneda(kpis.diferencia)"></span>
                  </div>
                </div>
              </div>
            </div>

            <div class="bg-white rounded-xl border border-gray-200 p-4">
              <h3 class="font-semibold text-gray-900 mb-4">Cerrar corte</h3>
              <div class="space-y-3">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">Turno</label>
                  <select x-model="turno"
                          class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow">
                    <option value="matutino">Matutino</option>
                    <option value="vespertino">Vespertino</option>
                    <option value="unico">\u00danico</option>
                  </select>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">Observaciones</label>
                  <textarea x-model="observaciones" rows="2"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow"
                            placeholder="Notas sobre el corte..."></textarea>
                </div>
                <button class="w-full py-2.5 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        :disabled="totalContado <= 0 || guardando"
                        @click="cerrarCorte()">
                  <i class="bi bi-lock"></i> Cerrar corte
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="bg-white rounded-xl border border-gray-200 p-4" x-show="historial.length">
          <h3 class="font-semibold text-gray-900 mb-4">Cortes anteriores</h3>
          <div class="overflow-x-auto">
            <table class="w-full text-sm">
              <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Fecha</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Turno</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Esperado</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Contado</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Diferencia</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-100">
                <template x-for="(c, idx) in historial" :key="c.id">
                  <tr class="hover:bg-gray-50 transition-colors" :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'">
                    <td class="px-4 py-3 text-gray-900" x-text="formatearFechaCompleta(c.createdAt)"></td>
                    <td class="px-4 py-3 text-gray-600 capitalize" x-text="c.turno"></td>
                    <td class="px-4 py-3 text-right text-gray-900" x-text="formatearMoneda(c.esperado)"></td>
                    <td class="px-4 py-3 text-right text-gray-900" x-text="formatearMoneda(c.contado)"></td>
                    <td class="px-4 py-3 text-right font-medium"
                        :class="c.diferencia >= 0 ? 'text-green-600' : 'text-red-600'"
                        x-text="(c.diferencia >= 0 ? '+' : '') + formatearMoneda(c.diferencia)"></td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
        </div>

        <template x-if="cargando">
          <div class="space-y-4">
            <div class="grid grid-cols-4 gap-4">
              <template x-for="i in 4" :key="i">
                <div class="h-24 bg-gray-200 rounded-xl animate-pulse"></div>
              </template>
            </div>
            <div class="grid grid-cols-2 gap-6">
              <div class="h-80 bg-gray-200 rounded-xl animate-pulse"></div>
              <div class="h-80 bg-gray-200 rounded-xl animate-pulse"></div>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.denominaciones = this.denominaciones.map(d => ({ ...d, cantidad: 0 }));
    this.turno = 'unico';
    this.observaciones = '';
    this.historial = [];
    this.cargando = true;
    this.kpis = { esperado: 0, transacciones: 0, contado: 0, diferencia: 0, diferenciaPorcentaje: 0 };
  },

  get totalContado() {
    let t = 0;
    for (const d of this.denominaciones) t += d.valor * (parseInt(d.cantidad) || 0);
    return t;
  },

  formatearMoneda(valor) {
    if (valor == null || isNaN(valor)) return '$0.00';
    return '$' + Number(valor).toLocaleString('es-MX', {
      minimumFractionDigits: 2, maximumFractionDigits: 2
    });
  },

  formatearFechaCompleta(fecha) {
    if (!fecha) return '';
    try {
      return new Date(fecha).toLocaleDateString('es-MX', {
        year: 'numeric', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit'
      });
    } catch { return fecha; }
  },

  recalcularConteo() {
    const contado = this.totalContado;
    const esperado = this.kpis.esperado;
    const diferencia = contado - esperado;
    this.kpis.contado = contado;
    this.kpis.diferencia = diferencia;
    this.kpis.diferenciaPorcentaje = esperado > 0 ? (diferencia / esperado) * 100 : 0;
  },

  async calcularEsperado() {
    try {
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0);
      const hoyStr = hoy.toISOString();
      const manana = new Date(hoy);
      manana.setDate(manana.getDate() + 1);
      const mananaStr = manana.toISOString();
      const ventas = await db.ventas
        .where('createdAt')
        .between(hoyStr, mananaStr)
        .toArray();
      let total = 0;
      for (const v of ventas) total += v.total || 0;
      this.kpis.esperado = total;
      this.kpis.transacciones = ventas.length;
      this.recalcularConteo();
    } catch (e) {
      console.error('Error calculando esperado:', e);
      UI.toast('Error al calcular ventas del d\u00eda', 'error');
    }
  },

  async cargarHistorial() {
    try {
      this.cargando = true;
      this.historial = await db.cortes.orderBy('createdAt').reverse().limit(20).toArray();
    } catch (e) {
      console.error('Error cargando historial:', e);
    } finally {
      this.cargando = false;
    }
  },

  async cerrarCorte() {
    if (this.totalContado <= 0) return;
    this.guardando = true;
    try {
      const corte = {
        id: uuid(),
        fecha: new Date().toISOString().split('T')[0],
        turno: this.turno,
        esperado: this.kpis.esperado,
        contado: this.totalContado,
        diferencia: this.totalContado - this.kpis.esperado,
        denominaciones: this.denominaciones.map(d => ({ valor: d.valor, cantidad: parseInt(d.cantidad) || 0 })),
        observaciones: this.observaciones.trim(),
        cerradoPor: APP_CONFIG?.usuarioActual || 'anon',
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      await db.cortes.put(corte);
      UI.toast('Corte cerrado exitosamente', 'success');
      this.denominaciones = this.denominaciones.map(d => ({ ...d, cantidad: 0 }));
      this.observaciones = '';
      await this.cargarHistorial();
      await this.calcularEsperado();
    } catch (e) {
      console.error('Error al cerrar corte:', e);
      UI.toast('Error al cerrar corte: ' + e.message, 'error');
    } finally {
      this.guardando = false;
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['pos-corte'] = ModuloPOSCorte;

document.addEventListener('alpine:init', () => {
  Alpine.data('posCorteData', () => ModuloPOSCorte);
});
