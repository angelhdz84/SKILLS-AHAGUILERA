const ModuloCRMPipeline = {
  id: 'crm-pipeline',
  titulo: 'Pipeline',
  icono: 'bi bi-kanban',

  etapas: ['prospecto', 'contactado', 'propuesta', 'negociacion', 'cerrado'],
  colores: ['#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#10b981'],
  deals: [],
  contactos: [],
  loading: true,
  dragId: null,

  async init() {
    const [d, c] = await Promise.all([
      db.deals?.orderBy('createdAt').toArray() || [],
      db.contactos?.orderBy('nombre').toArray() || []
    ]);
    this.deals = d || [];
    this.contactos = c || [];
    this.loading = false;
  },

  render() {
    return `
      <div x-data="crmPipelineData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-blue-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-kanban text-blue-600"></i> Pipeline
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Deal</button>
        </div>

        <template x-if="loading">
          <div class="grid grid-cols-5 gap-4"><template x-for="i in 5" :key="i"><div class="bg-gray-100 rounded-xl p-4 min-h-[300px]"><div class="h-5 w-20 bg-white rounded animate-pulse mb-3"></div><template x-for="j in 3" :key="j"><div class="bg-white rounded-lg p-3 mb-2 animate-pulse"><div class="h-3 w-24 bg-gray-200 rounded mb-2"></div><div class="h-3 w-16 bg-gray-200 rounded"></div></div></template></div></template></div>
        </template>

        <template x-if="!loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 overflow-x-auto">
            <template x-for="(etapa, i) in etapas" :key="etapa">
              <div class="bg-gray-50 rounded-xl p-3 min-w-[200px]" @dragover.prevent @drop="moverDeal($event, etapa)">
                <h3 class="font-semibold text-sm capitalize mb-3 flex items-center gap-2 px-1">
                  <span class="w-3 h-3 rounded-full" :style="'background:' + colores[i]"></span>
                  <span x-text="etapa"></span>
                  <span class="text-xs text-gray-400 font-normal" x-text="'(' + deals.filter(d => d.etapa === etapa).length + ')'"></span>
                </h3>
                <template x-for="d in deals.filter(x => x.etapa === etapa)" :key="d.id">
                  <div class="bg-white rounded-lg border border-gray-200 p-3 mb-2 cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow"
                       draggable="true" @dragstart="dragId = d.id" @click="editarDeal(d)">
                    <p class="text-sm font-medium text-gray-900 truncate" x-text="d.nombre"></p>
                    <p class="text-xs text-gray-500 mt-1" x-text="nombreContacto(d.contactoId)"></p>
                    <div class="flex items-center justify-between mt-2 pt-2 border-t border-gray-100">
                      <span class="text-sm font-bold text-blue-600" x-text="'$' + Number(d.monto || 0).toLocaleString('es-MX')"></span>
                      <span class="text-xs text-gray-400" x-text="d.probabilidad ? d.probabilidad + '%' : ''"></span>
                    </div>
                  </div>
                </template>
                <template x-if="deals.filter(x => x.etapa === etapa).length === 0">
                  <p class="text-center text-gray-400 text-xs py-6">Sin deals</p>
                </template>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() { this.deals = []; this.contactos = []; this.loading = true; this.dragId = null; },
  nombreContacto(id) { const c = this.contactos.find(x => x.id === id); return c ? c.nombre : '\u2014'; },

  async moverDeal(ev, etapa) {
    const id = this.dragId;
    this.dragId = null;
    if (!id) return;
    try {
      const d = await db.deals.get(id);
      if (!d || d.etapa === etapa) return;
      await db.deals.put({ ...d, etapa, updatedAt: new Date().toISOString() });
      const idx = this.deals.findIndex(x => x.id === id);
      if (idx >= 0) { this.deals[idx].etapa = etapa; }
      UI.toast('Movido a ' + etapa, 'success');
    } catch (e) { UI.toast('Error', 'error'); }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const pc = this.contactos;
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre del deal <span class="text-red-500">*</span></label><input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Contacto</label><select x-model="form.contactoId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow bg-white"><option value="">Seleccionar...</option>' + (pc || []).map(c => '<option value="' + c.id + '">' + c.nombre + '</option>').join('') + '</select></div><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Monto</label><input type="number" min="0" step="0.01" x-model="form.monto" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Probabilidad %</label><input type="number" min="0" max="100" x-model="form.probabilidad" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Etapa</label><select x-model="form.etapa" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow bg-white"><option value="prospecto">Prospecto</option><option value="contactado">Contactado</option><option value="propuesta">Propuesta</option><option value="negociacion">Negociaci\u00f3n</option><option value="cerrado">Cerrado</option></select></div></div>';
    await UI.modalForm(editando ? 'Editar Deal' : 'Nuevo Deal', html, async (data) => {
      if (!data.nombre?.trim()) { UI.toast('Nombre requerido', 'error'); return; }
      if (editando) {
        const e = await db.deals.get(item.id);
        if (!e) { UI.toast('No encontrado', 'error'); return; }
        await db.deals.put({ ...e, nombre: data.nombre.trim(), contactoId: data.contactoId || '', monto: parseFloat(data.monto) || 0, probabilidad: parseInt(data.probabilidad) || 0, etapa: data.etapa, updatedAt: new Date().toISOString() });
      } else {
        await db.deals.put({ id: window.uuid(), nombre: data.nombre.trim(), contactoId: data.contactoId || '', monto: parseFloat(data.monto) || 0, probabilidad: parseInt(data.probabilidad) || 0, etapa: data.etapa || 'prospecto', createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      }
      UI.toast(editando ? 'Actualizado' : 'Creado', 'success');
      const [d] = await Promise.all([db.deals.orderBy('createdAt').toArray()]);
      this.deals = d;
    }, item || { nombre: '', contactoId: '', monto: '', probabilidad: 50, etapa: 'prospecto' });
  },

  editarDeal(item) {
    this.abrirForm(item);
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['crm-pipeline'] = ModuloCRMPipeline;

document.addEventListener('alpine:init', () => {
  Alpine.data('crmPipelineData', () => ModuloCRMPipeline);
});
