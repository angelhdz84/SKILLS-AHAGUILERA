const ModuloContactosDirectorio = {
  id: 'ctc-directorio',
  titulo: 'Directorio',
  icono: 'bi bi-person-lines-fill',

  items: [],
  searchQuery: '',
  filtroEtiqueta: '',
  loading: true,
  kpis: { total: 0, hoy: 0, prospectos: 0, vips: 0 },
  hoy: '',

  async init() {
    this.hoy = new Date().toISOString().slice(0, 10);
    await this.cargar();
  },

  render() {
    return `
      <div x-data="ctcDirectorioData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-orange-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-person-lines-fill text-orange-600"></i> Directorio
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total</p><p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p></div>
          <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Hoy</p><p class="text-2xl font-bold text-orange-600" x-text="kpis.hoy"></p></div>
          <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Prospectos</p><p class="text-2xl font-bold text-blue-600" x-text="kpis.prospectos"></p></div>
          <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">VIP</p><p class="text-2xl font-bold text-amber-600" x-text="kpis.vips"></p></div>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-orange-600 text-white text-sm font-medium rounded-lg hover:bg-orange-700 transition-colors shadow-sm" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Contacto</button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="filtrar" placeholder="Buscar nombre, tel\u00e9fono o empresa..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-orange-500 outline-none transition-shadow" />
          </div>
          <select x-model="filtroEtiqueta" @change="filtrar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-orange-500 outline-none transition-shadow">
            <option value="">Todas</option>
            <option value="prospecto">Prospecto</option>
            <option value="cliente">Cliente</option>
            <option value="VIP">VIP</option>
            <option value="inactivo">Inactivo</option>
          </select>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-person-lines-fill text-6xl mb-4"></i><p class="text-lg text-gray-500 mb-2">Sin contactos</p><button class="inline-flex items-center gap-1.5 px-4 py-2 bg-orange-600 text-white text-sm font-medium rounded-lg hover:bg-orange-700 transition-colors" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Agregar</button></div>
        </template>

        <template x-if="items.length > 0">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            <template x-for="c in items" :key="c.id">
              <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md hover:-translate-y-0.5 transition-all cursor-pointer" @click="abrirForm(c)">
                <div class="flex items-start gap-3 mb-3">
                  <div class="w-10 h-10 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center font-bold text-sm shrink-0" x-text="(c.nombre || '?')[0].toUpperCase()"></div>
                  <div class="min-w-0 flex-1">
                    <h3 class="font-semibold text-gray-900 text-sm truncate" x-text="c.nombre"></h3>
                    <p class="text-xs text-gray-500" x-text="c.empresa || c.email || ''"></p>
                  </div>
                  <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                        :class="claseEtiqueta(c.etiqueta)"
                        x-text="c.etiqueta || 'prospecto'"></span>
                </div>
                <div class="flex items-center gap-2 text-xs text-gray-400">
                  <i class="bi bi-telephone"></i><span x-text="c.telefono || '\u2014'"></span>
                </div>
                <div class="flex gap-1 mt-3 pt-3 border-t border-gray-100">
                  <button class="flex-1 text-xs text-orange-600 hover:bg-orange-50 rounded-lg py-1.5 transition-colors font-medium" @click.stop="copiarTelefono(c.telefono)"><i class="bi bi-whatsapp"></i> WhatsApp</button>
                  <button class="flex-1 text-xs text-gray-500 hover:bg-gray-50 rounded-lg py-1.5 transition-colors font-medium" @click.stop="abrirHistorial(c)"><i class="bi bi-clock-history"></i> Historial</button>
                </div>
              </div>
            </template>
          </div>
        </template>

        <template x-if="loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            <template x-for="i in 8" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-10 w-10 bg-gray-200 rounded-full animate-pulse mb-3"></div><div class="h-4 w-32 bg-gray-200 rounded animate-pulse mb-2"></div><div class="h-3 w-24 bg-gray-200 rounded animate-pulse"></div></div></template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() { this.items = []; this.searchQuery = ''; this.filtroEtiqueta = ''; this.loading = true; },

  claseEtiqueta(e) {
    const m = { prospecto: 'bg-blue-100 text-blue-700', cliente: 'bg-green-100 text-green-700', VIP: 'bg-amber-100 text-amber-700', inactivo: 'bg-gray-100 text-gray-500' };
    return m[e] || 'bg-blue-100 text-blue-700';
  },

  async cargar() {
    try {
      this.loading = true;
      this.items = await db.contactos.orderBy('createdAt').reverse().toArray();
      const hoy = new Date().toISOString().slice(0, 10);
      const total = this.items.length;
      const hoyCount = this.items.filter(c => (c.createdAt || '').startsWith(hoy)).length;
      const prospectos = this.items.filter(c => (c.etiqueta || 'prospecto') === 'prospecto').length;
      const vips = this.items.filter(c => c.etiqueta === 'VIP').length;
      this.kpis = { total, hoy: hoyCount, prospectos, vips };
    } catch (e) { console.error(e); UI.toast('Error', 'error'); }
    finally { this.loading = false; }
  },

  filtrar() {
    Promise.resolve().then(async () => {
      try {
        this.loading = true;
        let datos = await db.contactos.orderBy('createdAt').reverse().toArray();
        const q = this.searchQuery.trim().toLowerCase();
        if (q) datos = datos.filter(c => (c.nombre || '').toLowerCase().includes(q) || (c.telefono || '').includes(q) || (c.empresa || '').toLowerCase().includes(q));
        if (this.filtroEtiqueta) datos = datos.filter(c => c.etiqueta === this.filtroEtiqueta);
        this.items = datos;
      } catch (e) { console.error(e); }
      finally { this.loading = false; }
    });
  },

  copiarTelefono(tel) {
    if (!tel) { UI.toast('Sin tel\u00e9fono', 'error'); return; }
    navigator.clipboard.writeText(tel).then(() => UI.toast('Tel\u00e9fono copiado: ' + tel, 'success')).catch(() => {});
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>',
      '<input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow" /></div>',
      '<div class="grid grid-cols-2 gap-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Tel\u00e9fono</label><input type="tel" x-model="form.telefono" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input type="email" x-model="form.email" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow" /></div>',
      '</div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Empresa</label><input type="text" x-model="form.empresa" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Etiqueta</label><select x-model="form.etiqueta" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow bg-white"><option value="prospecto">Prospecto</option><option value="cliente">Cliente</option><option value="VIP">VIP</option><option value="inactivo">Inactivo</option></select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Notas</label><textarea x-model="form.notas" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow"></textarea></div>',
      '</div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Contacto' : 'Nuevo Contacto', html,
      async (data) => {
        if (!data.nombre?.trim()) { UI.toast('Nombre requerido', 'error'); return; }
        if (editando) {
          const e = await db.contactos.get(item.id);
          if (!e) { UI.toast('No encontrado', 'error'); return; }
          await db.contactos.put({ ...e, nombre: data.nombre.trim(), telefono: data.telefono || '', email: data.email || '', empresa: data.empresa || '', etiqueta: data.etiqueta || 'prospecto', notas: data.notas || '', updatedAt: new Date().toISOString() });
        } else {
          await db.contactos.put({ id: window.uuid(), nombre: data.nombre.trim(), telefono: data.telefono || '', email: data.email || '', empresa: data.empresa || '', etiqueta: data.etiqueta || 'prospecto', notas: data.notas || '', createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        }
        UI.toast(editando ? 'Actualizado' : 'Guardado', 'success');
        await this.cargar();
      }, item || { nombre: '', telefono: '', email: '', empresa: '', etiqueta: 'prospecto', notas: '' }
    );
  },

  async abrirHistorial(item) {
    const historial = await db.historial.where('contactoId').equals(item.id).reverse().sortBy('fecha');
    const recordatorios = await db.recordatorios.where('contactoId').equals(item.id).toArray();
    const html = [
      '<div class="space-y-4 max-h-96 overflow-y-auto">',
      '<div class="flex gap-2 mb-2"><button class="inline-flex items-center gap-1 px-3 py-1.5 bg-orange-600 text-white text-xs font-medium rounded-lg hover:bg-orange-700 transition-colors" onclick="addHistorial(\'' + item.id + '\')"><i class="bi bi-plus-lg"></i> Registrar</button></div>',
      '<h4 class="text-xs font-semibold uppercase tracking-wider text-gray-500">Historial</h4>',
      historial.length === 0 ? '<p class="text-gray-400 text-sm py-2">Sin interacciones</p>' : historial.map(h => '<div class="flex items-start gap-2 py-1.5 border-b border-gray-100 last:border-0"><span class="text-xs text-gray-400 shrink-0 w-16">' + (h.fecha || '').slice(0, 10) + '</span><span class="text-xs px-1.5 py-0.5 rounded-full font-medium ' + (h.tipo === 'llamada' ? 'bg-blue-100 text-blue-700' : h.tipo === 'reunion' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-700') + '">' + (h.tipo || 'nota') + '</span><span class="text-sm text-gray-700">' + (h.descripcion || '') + '</span></div>').join(''),
      '<h4 class="text-xs font-semibold uppercase tracking-wider text-gray-500 mt-3">Recordatorios</h4>',
      recordatorios.length === 0 ? '<p class="text-gray-400 text-sm py-2">Sin recordatorios</p>' : recordatorios.map(r => '<div class="flex items-center gap-2 py-1 text-sm"><i class="bi ' + (r.completado ? 'bi-check-circle-fill text-green-500' : 'bi-alarm text-amber-500') + '"></i><span>' + (r.fecha || '').slice(0, 10) + ' - ' + (r.nota || '') + '</span></div>').join('')
    ].join('\n');
    UI.modalHtml(item.nombre, html);
  },

  async registrarHistorial(contactoId) {
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Tipo</label><select x-model="form.tipo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow bg-white"><option value="llamada">Llamada</option><option value="mensaje">Mensaje</option><option value="reunion">Reuni\u00f3n</option><option value="nota">Nota</option></select></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Descripci\u00f3n</label><textarea x-model="form.descripcion" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow"></textarea></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Fecha</label><input type="date" x-model="form.fecha" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow" /></div></div>';
    await UI.modalForm('Registrar interacci\u00f3n', html, async (data) => {
      await db.historial.put({ id: window.uuid(), contactoId, tipo: data.tipo, descripcion: data.descripcion?.trim() || '', fecha: data.fecha || new Date().toISOString().slice(0, 10), createdAt: new Date().toISOString() });
      UI.toast('Registrado', 'success');
    }, { tipo: 'nota', descripcion: '', fecha: new Date().toISOString().slice(0, 10) });
  }
};

window.addHistorial = function(id) { const m = window.MODULES['ctc-directorio']; if (m) m.registrarHistorial(id); };

window.MODULES = window.MODULES || {};
window.MODULES['ctc-directorio'] = ModuloContactosDirectorio;

document.addEventListener('alpine:init', () => {
  Alpine.data('ctcDirectorioData', () => ModuloContactosDirectorio);
});
