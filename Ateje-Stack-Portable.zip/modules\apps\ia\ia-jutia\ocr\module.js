// modules/apps/ia/ia-jutia/ocr/module.js — OCR IA
// Subida de archivos para procesamiento OCR con resultados simulados
// Dependencias: window.db, Alpine.js
// El motor OCR real se carga por separado (perfil Full)

;(function () {
  'use strict';

  var COLOR_AMBER = 'amber';
  var TABLA_OCR = '_ia_ocr';

  var ModuloIaOcr = {
    id: 'ia-ocr',
    titulo: 'OCR',
    icono: 'bi bi-file-earmark-image',
    color: COLOR_AMBER,

    items: [],
    loading: true,
    procesando: false,
    arrastrando: false,
    resultados: [],
    archivoSeleccionado: null,
    nombreArchivo: '',

    async init() {
      this.loading = true;
      await this._ensureTable();
      await this._cargarResultados();
      this.loading = false;
    },

    async _ensureTable() {
      if (!window.db) return;
      if (!window.db._ia_ocr) {
        try {
          window.db.version(window.db.verno || 1).stores({
            _ia_ocr: 'id, nombre, tipo, estado, createdBy, createdAt'
          });
        } catch (e) {
          console.warn('[ia-ocr] No se pudo crear tabla:', e);
        }
      }
    },

    async _cargarResultados() {
      if (!window.db || !window.db._ia_ocr) {
        this.resultados = [];
        return;
      }
      try {
        this.resultados = await window.db._ia_ocr
          .orderBy('createdAt')
          .reverse()
          .toArray();
      } catch (e) {
        console.warn('[ia-ocr] Error cargando resultados:', e);
        this.resultados = [];
      }
    },

    onDragOver(e) {
      e.preventDefault();
      this.arrastrando = true;
    },

    onDragLeave(e) {
      e.preventDefault();
      this.arrastrando = false;
    },

    onDrop(e) {
      e.preventDefault();
      this.arrastrando = false;
      var files = e.dataTransfer.files;
      if (files && files.length > 0) {
        this._seleccionarArchivo(files[0]);
      }
    },

    seleccionarArchivo(e) {
      var files = e.target.files;
      if (files && files.length > 0) {
        this._seleccionarArchivo(files[0]);
      }
    },

    _seleccionarArchivo(file) {
      var tiposPermitidos = [
        'image/png', 'image/jpeg', 'image/webp',
        'application/pdf',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain'
      ];

      if (tiposPermitidos.indexOf(file.type) === -1 && file.type !== '') {
        if (window.UI) window.UI.toast('Tipo de archivo no soportado', 'warning');
        return;
      }

      this.archivoSeleccionado = file;
      this.nombreArchivo = file.name;
    },

    async procesar() {
      if (!this.archivoSeleccionado || this.procesando) return;
      this.procesando = true;

      try {
        var textoExtraido = await this._mockOCR(this.archivoSeleccionado);

        var registro = {
          id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
          nombre: this.archivoSeleccionado.name,
          tipo: this.archivoSeleccionado.type || 'unknown',
          tamaño: this.archivoSeleccionado.size,
          estado: 'completado',
          texto: textoExtraido,
          createdBy: window.APP_USER || 'local',
          createdAt: new Date().toISOString()
        };

        if (window.db && window.db._ia_ocr) {
          await window.db._ia_ocr.put(registro);
        }

        this.archivoSeleccionado = null;
        this.nombreArchivo = '';
        await this._cargarResultados();

        if (window.UI) window.UI.toast('OCR completado', 'success');
      } catch (e) {
        console.warn('[ia-ocr] Error procesando:', e);
        if (window.UI) window.UI.toast('Error al procesar archivo', 'error');
      } finally {
        this.procesando = false;
      }
    },

    _mockOCR(file) {
      return new Promise(function (resolve) {
        var segundos = 1000 + Math.random() * 2000;
        setTimeout(function () {
          var nombre = file.name.replace(/\.[^.]+$/, '');
          var lines = [
            '=== Documento: ' + nombre + ' ===',
            '',
            'Fecha de procesamiento: ' + new Date().toLocaleString('es-MX'),
            'Tamaño: ' + ModuloIaOcr._formatBytes(file.size),
            'Tipo: ' + (file.type || 'desconocido'),
            '',
            '--- Contenido extraído ---',
            '',
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.',
            '',
            '[OCR模拟] Este es el resultado del procesamiento óptico.',
            'La calidad del texto depende de la resolución de la imagen original.',
            '',
            '--- Fin del documento ---'
          ];
          resolve(lines.join('\n'));
        }, segundos);
      });
    },

    _formatBytes(bytes) {
      if (!bytes || bytes === 0) return '0 B';
      var units = ['B', 'KB', 'MB', 'GB'];
      var i = Math.floor(Math.log(bytes) / Math.log(1024));
      return (bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0) + ' ' + units[i];
    },

    eliminarResultado(id) {
      var self = this;
      (async function () {
        if (window.UI && !(await window.UI.confirm('¿Eliminar este resultado?'))) return;
        try {
          if (window.db && window.db._ia_ocr) {
            await window.db._ia_ocr.delete(id);
          }
          await self._cargarResultados();
          if (window.UI) window.UI.toast('Resultado eliminado', 'info');
        } catch (e) {
          console.warn('[ia-ocr] Error eliminando:', e);
        }
      })();
    },

    render() {
      return '<div x-data="iaOcrData" class="p-4 max-w-4xl mx-auto">' +
        '<div class="flex items-center gap-3 mb-6">' +
          '<div class="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-amber-600 dark:text-amber-400">' +
            '<i class="bi bi-file-earmark-image text-lg"></i>' +
          '</div>' +
          '<div>' +
            '<h2 class="text-xl font-bold">OCR</h2>' +
            '<p class="text-sm text-base-content/60">Reconocimiento óptico de caracteres offline</p>' +
          '</div>' +
        '</div>' +

        '<template x-if="loading">' +
          '<div class="flex items-center justify-center py-20">' +
            '<span class="loading loading-spinner loading-lg text-amber-500"></span>' +
          '</div>' +
        '</template>' +

        '<template x-if="!loading">' +
          '<div>' +
            '<div class="card bg-base-100 shadow-sm border border-base-200 mb-6" ' +
              '@dragover.prevent="onDragOver($event)" @dragleave.prevent="onDragLeave($event)" @drop.prevent="onDrop($event)">' +
              '<div class="card-body p-6">' +

                '<div class="flex flex-col items-center justify-center py-8 border-2 border-dashed rounded-2xl transition-colors cursor-pointer" ' +
                  ':class="arrastrando ? \'border-amber-500 bg-amber-50 dark:bg-amber-900/20\' : \'border-base-300 hover:border-amber-400\'">' +
                  '<i class="bi bi-cloud-upload text-5xl text-base-content/30 mb-3"></i>' +
                  '<p class="font-medium">Arrastra un archivo aquí</p>' +
                  '<p class="text-sm text-base-content/50 mb-4">o haz clic para seleccionar</p>' +
                  '<input type="file" accept="image/png,image/jpeg,image/webp,application/pdf,.docx,.txt" ' +
                    'class="hidden" id="ocr-file-input" @change="seleccionarArchivo($event)" />' +
                  '<button class="btn btn-outline btn-sm" @click="$refs.fileInput.click()" ' +
                    'x-ref="fileInput" @click="$event.target.previousElementSibling.click()" ' +
                    '@click="$nextTick(() => document.getElementById(\'ocr-file-input\').click())">' +
                    '<i class="bi bi-folder2-open"></i> Seleccionar archivo' +
                  '</button>' +
                '</div>' +

                '<template x-if="archivoSeleccionado">' +
                  '<div class="mt-4 p-3 bg-base-200 rounded-xl flex items-center justify-between">' +
                    '<div class="flex items-center gap-3 min-w-0">' +
                      '<i class="bi bi-file-earmark text-lg text-amber-500"></i>' +
                      '<div class="min-w-0">' +
                        '<p class="font-medium text-sm truncate" x-text="nombreArchivo"></p>' +
                        '<p class="text-xs text-base-content/50" x-text="_formatBytes(archivoSeleccionado.size)"></p>' +
                      '</div>' +
                    '</div>' +
                    '<div class="flex gap-2">' +
                      '<button class="btn btn-ghost btn-xs" @click="archivoSeleccionado = null; nombreArchivo = \'\'">' +
                        '<i class="bi bi-x-lg"></i>' +
                      '</button>' +
                      '<button class="btn btn-primary btn-sm" @click="procesar()" :disabled="procesando">' +
                        '<template x-if="!procesando"><i class="bi bi-magic"></i></template>' +
                        '<template x-if="procesando"><span class="loading loading-spinner loading-sm"></span></template>' +
                        ' Procesar' +
                      '</button>' +
                    '</div>' +
                  '</div>' +
                '</template>' +

                '<template x-if="procesando && !archivoSeleccionado">' +
                  '<div class="mt-4 p-4 bg-base-200 rounded-xl flex items-center justify-center gap-3">' +
                    '<span class="loading loading-spinner loading-md text-amber-500"></span>' +
                    '<span class="text-sm">Procesando OCR...</span>' +
                  '</div>' +
                '</template>' +
              '</div>' +
            '</div>' +

            '<h3 class="text-sm font-semibold uppercase tracking-wider text-base-content/50 mb-3">Resultados</h3>' +

            '<template x-if="resultados.length === 0">' +
              '<div class="flex flex-col items-center justify-center py-12 text-base-content/40">' +
                '<i class="bi bi-file-earmark-text text-5xl mb-3"></i>' +
                '<p class="text-lg font-medium">Sin resultados</p>' +
                '<p class="text-sm">Procesa un archivo para ver los resultados aquí</p>' +
              '</div>' +
            '</template>' +

            '<div class="space-y-3">' +
              '<template x-for="r in resultados" :key="r.id">' +
                '<div class="card bg-base-100 shadow-sm border border-base-200">' +
                  '<div class="card-body p-4">' +
                    '<div class="flex items-start justify-between">' +
                      '<div class="flex items-center gap-3 min-w-0">' +
                        '<div class="w-9 h-9 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-amber-600 flex-shrink-0">' +
                          '<i class="bi bi-file-text"></i>' +
                        '</div>' +
                        '<div class="min-w-0">' +
                          '<p class="font-medium text-sm truncate" x-text="r.nombre"></p>' +
                          '<p class="text-xs text-base-content/50">' +
                            '<span x-text="_formatBytes(r.tamaño || 0)"></span>' +
                            ' · <span x-text="r.createdAt ? new Date(r.createdAt).toLocaleDateString(\'es-MX\') : \'\'"></span>' +
                          '</p>' +
                        '</div>' +
                      '</div>' +
                      '<button class="btn btn-ghost btn-xs text-error" @click="eliminarResultado(r.id)" title="Eliminar">' +
                        '<i class="bi bi-trash3"></i>' +
                      '</button>' +
                    '</div>' +

                    '<details class="mt-3">' +
                      '<summary class="text-xs text-base-content/50 cursor-pointer hover:text-base-content/80">' +
                        '<i class="bi bi-chevron-down mr-1"></i> Ver texto extraído' +
                      '</summary>' +
                      '<pre class="mt-2 p-3 bg-base-200 rounded-xl text-xs leading-relaxed overflow-x-auto max-h-60 overflow-y-auto whitespace-pre-wrap" x-text="r.texto || \'Sin contenido\'"></pre>' +
                    '</details>' +
                  '</div>' +
                '</div>' +
              '</template>' +
            '</div>' +
          '</div>' +
        '</template>' +
      '</div>';
    },

    destroy() {
      this.items = [];
      this.resultados = [];
      this.archivoSeleccionado = null;
      this.loading = true;
      this.procesando = false;
    }
  };

  window.MODULES = window.MODULES || {};
  window.MODULES[ModuloIaOcr.id] = ModuloIaOcr;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      if (typeof Alpine !== 'undefined') {
        Alpine.data('iaOcrData', function () { return ModuloIaOcr; });
      }
    });
  } else {
    if (typeof Alpine !== 'undefined') {
      Alpine.data('iaOcrData', function () { return ModuloIaOcr; });
    }
  }
})();
