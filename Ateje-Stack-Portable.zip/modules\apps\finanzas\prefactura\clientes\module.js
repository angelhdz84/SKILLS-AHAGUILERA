const ModuloPFClientes = {
  id: 'pf-clientes',
  titulo: 'Clientes',
  icono: 'bi bi-building',

  items: [],
  searchQuery: '',
  loading: true,
  errors: {},

  async init() {
    await this.cargar();
  },

  render() {
    return `
      <div x-data="pfClientesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-sky-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-building text-sky-600"></i> Clientes fiscales
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 text-white text-sm font-medium rounded-lg hover:bg-sky-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Cliente
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="filtrar" placeholder="Buscar por nombre o RFC..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-sky-500 outline-none transition-shadow" />
          </div>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-building text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">Sin clientes</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 text-white text-sm font-medium rounded-lg hover:bg-sky-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Agregar
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="c in items" :key="c.id">
              <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md hover:-translate-y-0.5 transition-all cursor-pointer" @click="abrirForm(c)">
                <div class="flex items-start gap-3">
                  <div class="w-10 h-10 rounded-full bg-sky-100 text-sky-600 flex items-center justify-center font-bold text-sm shrink-0" x-text="(c.nombre || '?')[0].toUpperCase()"></div>
                  <div class="min-w-0 flex-1">
                    <h3 class="font-semibold text-gray-900 text-sm truncate" x-text="c.nombre"></h3>
                    <p class="text-xs text-gray-500 font-mono mt-0.5" x-text="c.rfc || 'Sin RFC'"></p>
                    <p class="text-xs text-gray-400 mt-1 truncate" x-text="c.email || c.telefono || ''"></p>
                  </div>
                </div>
              </div>
            </template>
          </div>
        </template>

        <template x-if="loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="i in 6" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-10 w-10 bg-gray-200 rounded-full animate-pulse mb-3"></div><div class="h-4 w-32 bg-gray-200 rounded animate-pulse mb-2"></div><div class="h-3 w-24 bg-gray-200 rounded animate-pulse"></div></div></template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() { this.items = []; this.searchQuery = ''; this.loading = true; },

  async cargar() {
    try {
      this.loading = true;
      this.items = await db.clientes_fiscales.orderBy('nombre').toArray();
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  filtrar() {
    Promise.resolve().then(async () => {
      try {
        this.loading = true;
        let datos = await db.clientes_fiscales.orderBy('nombre').toArray();
        const q = this.searchQuery.trim().toLowerCase();
        if (q) datos = datos.filter(c => (c.nombre || '').toLowerCase().includes(q) || (c.rfc || '').toLowerCase().includes(q));
        this.items = datos;
      } catch (e) { console.error(e); }
      finally { this.loading = false; }
    });
  },

  validarRFC(rfc) {
    if (!rfc) return true;
    return /^[A-Z&Ñ]{3,4}\d{6}[A-Z0-9]{3}$/.test(rfc.toUpperCase());
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre / Raz\u00f3n social <span class="text-red-500">*</span></label>',
      '<input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" /></div>',
      '<div class="grid grid-cols-2 gap-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">RFC</label>',
      '<input type="text" x-model="form.rfc" maxlength="13" class="w-full px-3 py-2 border rounded-lg text-sm font-mono uppercase outline-none transition-shadow" :class="errors.rfc ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-sky-500\'" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">R\u00e9gimen fiscal</label>',
      '<select x-model="form.regimen" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow bg-white">',
      '<option value="">Seleccionar...</option>',
      '<option value="601">601 - General de Ley Personas Morales</option>',
      '<option value="605">605 - Sueldos y Salarios e Ingresos Asimilados</option>',
      '<option value="606">606 - Arrendamiento</option>',
      '<option value="608">608 - Dem\u00e1s ingresos</option>',
      '<option value="609">609 - Consolidaci\u00f3n</option>',
      '<option value="610">610 - Residentes en el Extranjero</option>',
      '<option value="611">611 - Ingresos por Dividendos</option>',
      '<option value="612">612 - Personas F\u00edsicas con Actividades Empresariales</option>',
      '<option value="614">614 - Ingresos por intereses</option>',
      '<option value="616">616 - Sin obligaciones fiscales</option>',
      '<option value="620">620 - Sociedades Cooperativas de Producci\u00f3n</option>',
      '<option value="621">621 - Incorporaci\u00f3n Fiscal</option>',
      '<option value="622">622 - Actividades Agr\u00edcolas, Ganaderas, Silv\u00edcolas y Pesqueras</option>',
      '<option value="623">623 - Opcional para Grupos de Sociedades</option>',
      '<option value="624">624 - Coordinados</option>',
      '<option value="625">625 - R\u00e9gimen de las Actividades Empresariales con ingresos a trav\u00e9s de Plataformas Tecnol\u00f3gicas</option>',
      '</select></div>',
      '</div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Direcci\u00f3n fiscal</label>',
      '<textarea x-model="form.direccion" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow"></textarea></div>',
      '<div class="grid grid-cols-2 gap-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input type="email" x-model="form.email" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Tel\u00e9fono</label><input type="tel" x-model="form.telefono" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" /></div>',
      '</div></div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Cliente' : 'Nuevo Cliente Fiscal', html,
      async (data) => {
        this.errors = {};
        if (!data.nombre?.trim()) { UI.toast('Nombre requerido', 'error'); return; }
        if (data.rfc && !this.validarRFC(data.rfc)) { this.errors.rfc = 'Formato RFC inv\u00e1lido'; return; }
        if (editando) {
          const e = await db.clientes_fiscales.get(item.id);
          if (!e) { UI.toast('No encontrado', 'error'); return; }
          await db.clientes_fiscales.put({ ...e, nombre: data.nombre.trim(), rfc: (data.rfc || '').toUpperCase(), regimen: data.regimen || '', direccion: data.direccion || '', email: data.email || '', telefono: data.telefono || '', updatedAt: new Date().toISOString() });
        } else {
          await db.clientes_fiscales.put({ id: window.uuid(), nombre: data.nombre.trim(), rfc: (data.rfc || '').toUpperCase(), regimen: data.regimen || '', direccion: data.direccion || '', email: data.email || '', telefono: data.telefono || '', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        }
        UI.toast(editando ? 'Actualizado' : 'Guardado', 'success');
        await this.cargar();
      }, item || { nombre: '', rfc: '', regimen: '', direccion: '', email: '', telefono: '' }
    );
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['pf-clientes'] = ModuloPFClientes;

document.addEventListener('alpine:init', () => {
  Alpine.data('pfClientesData', () => ModuloPFClientes);
});
