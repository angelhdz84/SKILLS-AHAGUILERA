const ModuloContactosEtiquetas = {
  id: 'ctc-etiquetas',
  titulo: 'Plantillas',
  icono: 'bi bi-chat-dots',

  tab: 'plantillas',
  plantillas: [],
  loading: true,
  categorias: ['saludo', 'seguimiento', 'oferta', 'cobro', 'cierre'],

  async init() {
    await this.cargarPlantillas();
    if (this.plantillas.length === 0) await this.sembrar();
  },

  render() {
    return `
      <div x-data="ctcEtiquetasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-orange-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-chat-dots text-orange-600"></i> Plantillas
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-orange-600 text-white text-sm font-medium rounded-lg hover:bg-orange-700 transition-colors shadow-sm" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Plantilla</button>
        </div>

        <template x-if="loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"><template x-for="i in 6" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4 space-y-3"><div class="h-4 w-20 bg-gray-200 rounded animate-pulse"></div><div class="h-12 bg-gray-200 rounded animate-pulse"></div></div></template></div>
        </template>

        <template x-if="!loading && plantillas.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-chat-dots text-6xl mb-4"></i><p class="text-lg text-gray-500">Sin plantillas</p></div>
        </template>

        <template x-if="plantillas.length > 0">
          <div>
            <template x-for="cat in categorias" :key="cat">
              <div class="mb-6">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm capitalize flex items-center gap-2"><i :class="iconoCategoria(cat)" class="text-orange-600"></i> <span x-text="cat"></span></h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <template x-for="p in plantillas.filter(x => x.categoria === cat)" :key="p.id">
                    <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow group">
                      <p class="text-sm text-gray-700 mb-3 leading-relaxed" x-text="p.contenido"></p>
                      <div class="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button class="inline-flex items-center gap-1 px-3 py-1.5 bg-orange-100 text-orange-700 text-xs font-medium rounded-lg hover:bg-orange-200 transition-colors" @click="copiar(p.contenido)"><i class="bi bi-clipboard"></i> Copiar</button>
                        <button class="inline-flex items-center gap-1 px-3 py-1.5 bg-gray-100 text-gray-600 text-xs font-medium rounded-lg hover:bg-gray-200 transition-colors" @click="abrirForm(p)"><i class="bi bi-pencil"></i></button>
                        <button class="inline-flex items-center gap-1 px-3 py-1.5 bg-red-50 text-red-600 text-xs font-medium rounded-lg hover:bg-red-100 transition-colors" @click="eliminar(p)"><i class="bi bi-trash"></i></button>
                      </div>
                    </div>
                  </template>
                </div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() { this.plantillas = []; this.loading = true; },

  iconoCategoria(c) { const m = { saludo: 'bi bi-hand-wave', seguimiento: 'bi bi-arrow-repeat', oferta: 'bi bi-tag', cobro: 'bi bi-credit-card', cierre: 'bi bi-check-circle' }; return m[c] || 'bi bi-chat'; },

  async cargarPlantillas() {
    try {
      this.loading = true;
      this.plantillas = await db.plantillas.orderBy('categoria').toArray();
    } catch (e) { console.error(e); }
    finally { this.loading = false; }
  },

  async sembrar() {
    const defaults = [
      { nombre: 'Saludo inicial', contenido: '\u00a1Hola! Soy [nombre], de [empresa]. Te escribo para ponerme en contacto y ver c\u00f3mo puedo ayudarte.', categoria: 'saludo' },
      { nombre: 'Saludo cordial', contenido: 'Hola, \u00bfc\u00f3mo est\u00e1s? Te contacto de parte de [empresa] para hacer seguimiento.', categoria: 'saludo' },
      { nombre: 'Seguimiento suave', contenido: '\u00a1Hola! \u00bfQu\u00e9 tal? Solo quer\u00eda darle seguimiento a la conversaci\u00f3n anterior y ver si tienes alguna duda.', categoria: 'seguimiento' },
      { nombre: 'Recordatorio propuesta', contenido: 'Te recuerdo que la propuesta que te env\u00ede sigue vigente. \u00bfQuieres que la revisemos juntos?', categoria: 'seguimiento' },
      { nombre: 'Oferta especial', contenido: 'Esta semana tenemos una oferta especial en [producto/servicio]. \u00bfTe interesa conocer los detalles?', categoria: 'oferta' },
      { nombre: 'Descuento', contenido: 'Por ser cliente frecuente, te ofrezco un descuento exclusivo del [X]% en [producto]. \u00bfTe parece bien?', categoria: 'oferta' },
      { nombre: 'Recordatorio pago', contenido: 'Te recuerdo cordialmente que tu factura con vencimiento el [fecha] est\u00e1 por vencer. \u00a1Gracias por tu atenci\u00f3n!', categoria: 'cobro' },
      { nombre: 'Agradecimiento pago', contenido: '\u00a1Gracias por tu pago! Queda registrado. Si necesitas tu recibo o factura, h\u00e1zmelo saber.', categoria: 'cobro' },
      { nombre: 'Cierre venta', contenido: '\u00a1Gracias por tu confianza! Quedamos en enviarte [producto/servicio] a la brevedad. Ante cualquier duda, ac\u00e1 estoy.', categoria: 'cierre' },
      { nombre: 'Post-venta', contenido: '\u00bfQu\u00e9 tal te va con [producto]? Quiero asegurarme de que todo est\u00e9 bien. \u00bfNecesitas algo m\u00e1s?', categoria: 'cierre' }
    ];
    try {
      for (const p of defaults) {
        await db.plantillas.put({ id: window.uuid(), ...p, createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      }
      await this.cargarPlantillas();
    } catch (e) { console.error(e); }
  },

  copiar(texto) {
    navigator.clipboard.writeText(texto).then(() => UI.toast('Copiado al portapapeles', 'success')).catch(() => {});
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Categor\u00eda</label><select x-model="form.categoria" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow bg-white"><option value="saludo">Saludo</option><option value="seguimiento">Seguimiento</option><option value="oferta">Oferta</option><option value="cobro">Cobro</option><option value="cierre">Cierre</option></select></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Mensaje</label><textarea x-model="form.contenido" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-orange-500 transition-shadow" placeholder="Usa [corchetes] para indicar campos variables"></textarea></div></div>';
    await UI.modalForm(editando ? 'Editar Plantilla' : 'Nueva Plantilla', html,
      async (data) => {
        if (!data.contenido?.trim()) { UI.toast('Contenido requerido', 'error'); return; }
        if (editando) {
          const e = await db.plantillas.get(item.id);
          if (!e) { UI.toast('No encontrada', 'error'); return; }
          await db.plantillas.put({ ...e, categoria: data.categoria, contenido: data.contenido.trim(), updatedAt: new Date().toISOString() });
        } else {
          await db.plantillas.put({ id: window.uuid(), nombre: data.categoria + ' - ' + Date.now(), categoria: data.categoria, contenido: data.contenido.trim(), createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        }
        UI.toast(editando ? 'Actualizada' : 'Creada', 'success');
        await this.cargarPlantillas();
      }, item || { categoria: 'saludo', contenido: '' }
    );
  },

  async eliminar(item) {
    if (!await UI.confirm('Eliminar esta plantilla?')) return;
    try { await db.plantillas.delete(item.id); UI.toast('Eliminada', 'success'); await this.cargarPlantillas(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['ctc-etiquetas'] = ModuloContactosEtiquetas;

document.addEventListener('alpine:init', () => {
  Alpine.data('ctcEtiquetasData', () => ModuloContactosEtiquetas);
});
