﻿const ModuloObraPersonal = {
  id: 'obra-personal',
  titulo: 'Personal y Gastos',
  icono: 'bi bi-people',
  items: [],
  loading: true,
  obraSeleccionada: null,
  obras: [],
  categorias: ['mano_obra', 'subcontrato', 'viaticos', 'equipo', 'transporte', 'alimentacion', 'otro'],

  async init() {
    await this.cargarObras();
    await this.cargar();
  },

  async cargarObras() {
    try {
      this.obras = await db.obras.toArray();
    } catch (e) {
      this.obras = [];
    }
  },

  async cargar() {
    this.loading = true;
    try {
      let query = db.gastos_obra.orderBy('createdAt').reverse();
      if (this.obraSeleccionada) {
        query = db.gastos_obra.where('obraId').equals(this.obraSeleccionada);
      }
      this.items = await query.toArray();
    } catch (e) {
      console.error('Error cargando gastos:', e);
      this.items = [];
    } finally {
      this.loading = false;
    }
  },

  render() {
    if (this.loading) return this.renderSkeleton();
    const totalGastos = this.items.reduce((s, g) => s + (Number(g.monto) || 0), 0);
    const porCategoria = {};
    this.items.forEach(g => {
      const cat = g.categoria || 'otro';
      porCategoria[cat] = (porCategoria[cat] || 0) + (Number(g.monto) || 0);
    });
    const labels = { mano_obra: 'Mano de obra', subcontrato: 'Subcontrato', viaticos: 'Viáticos', equipo: 'Equipo', transporte: 'Transporte', alimentacion: 'Alimentación', otro: 'Otro' };
    return \
      <div class="space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <h2 class="text-2xl font-bold flex items-center gap-2">
            <i class="bi bi-people text-red-500"></i> Personal y Gastos
          </h2>
          <div class="flex gap-2">
            <select x-model="obraPersonalData.obraSeleccionada" @change="obraPersonalData.cargar()" class="select select-bordered select-sm">
              <option value="">Todas las obras</option>
              <template x-for="obra in obraPersonalData.obras" :key="obra.id">
                <option :value="obra.id" x-text="obra.nombre"></option>
              </template>
            </select>
            <button @click="obraPersonalData.abrirForm()" class="btn btn-primary btn-sm gap-1">
              <i class="bi bi-plus-lg"></i> Agregar
            </button>
          </div>
        </div>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div class="stat bg-base-100 rounded-xl shadow-sm border border-base-200 p-3">
            <div class="stat-title text-xs">Total gastos</div>
            <div class="stat-value text-xl font-bold text-red-500" x-text="obraPersonalData.formatCurrency(obraPersonalData.items.reduce((s,g) => s + (Number(g.monto)||0), 0))"></div>
          </div>
          <template x-for="(total, cat) in \.__porCategoria || {}" :key="cat">
            <div class="stat bg-base-100 rounded-xl shadow-sm border border-base-200 p-3">
              <div class="stat-title text-xs" x-text="cat.replace(/_/g,' ').replace(/\\b\\w/g, c => c.toUpperCase())"></div>
              <div class="stat-value text-lg font-bold" x-text="formatCurrency(total)"></div>
            </div>
          </template>
        </div>
        <div x-show="obraPersonalData.items.length === 0" class="empty-state">
          <div class="empty-state-icon bg-red-50"><i class="bi bi-people text-red-400"></i></div>
          <div class="empty-state-title">Sin gastos registrados</div>
          <div class="empty-state-desc">Agrega los gastos de personal y obra</div>
          <button @click="obraPersonalData.abrirForm()" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Agregar gasto</button>
        </div>
        <div x-show="obraPersonalData.items.length > 0" class="overflow-x-auto">
          <table class="table table-zebra">
            <thead>
              <tr class="text-xs uppercase text-base-content/50">
                <th>Concepto</th>
                <th class="hidden sm:table-cell">Categoría</th>
                <th class="hidden lg:table-cell">Obra</th>
                <th>Monto</th>
                <th class="hidden md:table-cell">Fecha</th>
                <th class="text-right">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <template x-for="(item, i) in obraPersonalData.items" :key="item.id">
                <tr class="stagger-item" :style="'animation-delay: ' + (i * 0.04) + 's'">
                  <td><span class="font-medium" x-text="item.concepto"></span></td>
                  <td class="hidden sm:table-cell">
                    <span :class="'badge badge-sm ' + (item.categoria === 'mano_obra' ? 'badge-error' : item.categoria === 'subcontrato' ? 'badge-warning' : 'badge-ghost')" x-text="(item.categoria || 'otro').replace(/_/g,' ').replace(/\\b\\w/g, c => c.toUpperCase())"></span>
                  </td>
                  <td class="hidden lg:table-cell text-sm text-base-content/60" x-text="obraPersonalData.obras.find(o => o.id === item.obraId)?.nombre || '-'"></td>
                  <td class="font-medium" x-text="formatCurrency(item.monto)"></td>
                  <td class="hidden md:table-cell text-sm text-base-content/60" x-text="new Date(item.createdAt).toLocaleDateString('es-MX', {day:'2-digit',month:'short',year:'numeric'})"></td>
                  <td class="text-right">
                    <div class="flex gap-1 justify-end">
                      <button @click="obraPersonalData.abrirForm(item)" class="btn btn-ghost btn-xs btn-square" title="Editar"><i class="bi bi-pencil"></i></button>
                      <button @click="obraPersonalData.eliminar(item)" class="btn btn-ghost btn-xs btn-square text-error" title="Eliminar"><i class="bi bi-trash"></i></button>
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
    \;
  },

  renderSkeleton() {
    return \
      <div class="space-y-4">
        <div class="sk-heading w-48"></div>
        <div class="grid grid-cols-4 gap-3">\</div>
        \
      </div>
    \;
  },

  formatCurrency(n) {
    const v = Number(n) || 0;
    return '$' + v.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  async abrirForm(item) {
    const editando = !!item;
    const obraOptions = this.obras.map(o => \<option value="\" \>\</option>\).join('');
    const catOptions = this.categorias.map(c => \<option value="\" \></option>\).join('');
    let etapaOptions = '<option value="">Sin etapa</option>';
    try {
      const etapas = await db.etapas.toArray();
      etapaOptions += etapas.map(e => \<option value="\" \>\</option>\).join('');
    } catch (e) {}
    const html = \
      <div class="space-y-4">
        <label class="form-control w-full">
          <span class="label-text">Concepto</span>
          <input type="text" x-model="form.concepto" class="input input-bordered" required />
        </label>
        <div class="grid grid-cols-2 gap-4">
          <label class="form-control w-full">
            <span class="label-text">Obra</span>
            <select x-model="form.obraId" class="select select-bordered" required>
              <option value="">Seleccionar</option>
              \
            </select>
          </label>
          <label class="form-control w-full">
            <span class="label-text">Categoría</span>
            <select x-model="form.categoria" class="select select-bordered">
              \
            </select>
          </label>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <label class="form-control w-full">
            <span class="label-text">Monto</span>
            <input type="number" x-model="form.monto" class="input input-bordered" min="0" step="0.01" required />
          </label>
          <label class="form-control w-full">
            <span class="label-text">Etapa (opcional)</span>
            <select x-model="form.etapaId" class="select select-bordered">
              \
            </select>
          </label>
        </div>
      </div>
    \;
    await UI.modalForm(
      editando ? 'Editar gasto' : 'Nuevo gasto',
      html,
      async (data) => {
        const payload = {
          obraId: data.obraId,
          etapaId: data.etapaId || '',
          concepto: data.concepto,
          monto: Number(data.monto) || 0,
          categoria: data.categoria || 'otro'
        };
        if (editando) {
          await this.actualizar(item.id, payload);
        } else {
          await this.guardar(payload);
        }
      }
    );
  },

  async guardar(datos) {
    const registro = {
      id: uuid(),
      ...datos,
      createdBy: APP_CONFIG?.usuarioActual || 'anon',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    await db.gastos_obra.put(registro);
    UI.toast('Gasto registrado', 'success');
    await this.cargar();
  },

  async actualizar(id, datos) {
    const existente = await db.gastos_obra.get(id);
    if (!existente) { UI.toast('Gasto no encontrado', 'error'); return; }
    const actualizado = { ...existente, ...datos, id, updatedAt: new Date().toISOString() };
    await db.gastos_obra.put(actualizado);
    UI.toast('Gasto actualizado', 'success');
    await this.cargar();
  },

  async eliminar(item) {
    const ok = await UI.confirm(\Eliminar gasto "\"?\);
    if (!ok) return;
    try {
      await db.gastos_obra.delete(item.id);
      UI.toast('Gasto eliminado', 'success');
      await this.cargar();
    } catch (e) {
      UI.toast(e.message, 'error');
    }
  },

  destroy() {
    this.items = [];
    this.loading = true;
    this.obraSeleccionada = null;
  }
};

window.MODULES = window.MODULES || {};
window.MODULES[ModuloObraPersonal.id] = ModuloObraPersonal;

document.addEventListener('alpine:init', () => {
  Alpine.data('obraPersonalData', () => ModuloObraPersonal);
});
