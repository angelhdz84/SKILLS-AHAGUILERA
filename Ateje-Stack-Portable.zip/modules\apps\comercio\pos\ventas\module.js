const ModuloPOSVentas = {
  id: 'pos-ventas',
  titulo: 'Ventas',
  icono: 'bi bi-cart3',

  carrito: [],
  historial: [],
  productos: [],
  productosFiltrados: [],
  categorias: [],
  searchQuery: '',
  filtroCategoria: '',
  metodoPago: 'efectivo',
  montoPago: '',
  cargando: true,
  buscandoProductos: false,
  kpis: { ventasHoy: 0, transacciones: 0, ticketPromedio: 0, efectivoHoy: 0 },

  async init() {
    await Promise.all([this.cargarProductos(), this.cargarHistorial()]);
  },

  render(params = {}) {
    return `
      <div x-data="posVentasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-indigo-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-cart3 text-indigo-600"></i> Ventas
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Ventas hoy</p>
            <p class="text-2xl font-bold text-gray-900" x-text="formatearMoneda(kpis.ventasHoy)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Transacciones</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.transacciones"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Ticket promedio</p>
            <p class="text-2xl font-bold text-indigo-600" x-text="formatearMoneda(kpis.ticketPromedio)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Efectivo hoy</p>
            <p class="text-2xl font-bold text-green-600" x-text="formatearMoneda(kpis.efectivoHoy)"></p>
          </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <div class="lg:col-span-3">
            <div class="bg-white rounded-xl border border-gray-200 p-4 mb-4">
              <div class="relative">
                <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input type="search" x-model="searchQuery" @input.debounce="buscarProductos" placeholder="Buscar producto por nombre o SKU..."
                       class="w-full pl-9 pr-3 py-2.5 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow" />
              </div>
              <div class="mt-3 flex gap-2 overflow-x-auto pb-1" x-show="categorias.length">
                <button class="whitespace-nowrap px-3 py-1.5 text-xs font-medium rounded-lg transition-colors"
                        :class="filtroCategoria === '' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'"
                        @click="filtroCategoria = ''; buscarProductos()">Todas</button>
                <template x-for="cat in categorias" :key="cat">
                  <button class="whitespace-nowrap px-3 py-1.5 text-xs font-medium rounded-lg transition-colors"
                          :class="filtroCategoria === cat ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'"
                          @click="filtroCategoria = cat; buscarProductos()" x-text="cat"></button>
                </template>
              </div>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <template x-for="p in productosFiltrados" :key="p.id">
                <div class="bg-white rounded-xl border border-gray-200 p-3 hover:shadow-md hover:border-indigo-300 transition-all duration-150 cursor-pointer"
                     @click="agregarAlCarrito(p)">
                  <div class="h-20 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg flex items-center justify-center mb-2">
                    <template x-if="p.imagen">
                      <img :src="p.imagen" :alt="p.nombre" class="w-full h-full object-cover rounded-lg" />
                    </template>
                    <template x-if="!p.imagen">
                      <i class="bi bi-box-seam text-2xl text-gray-300"></i>
                    </template>
                  </div>
                  <p class="text-sm font-medium text-gray-900 truncate" x-text="p.nombre"></p>
                  <div class="flex items-center justify-between mt-1">
                    <span class="text-sm font-bold text-indigo-600" x-text="formatearMoneda(p.precio)"></span>
                    <span class="text-xs text-gray-400" x-text="p.stock + ' uds'"></span>
                  </div>
                </div>
              </template>
              <template x-if="productosFiltrados.length === 0 && !buscandoProductos">
                <div class="col-span-full text-center py-8 text-gray-400">
                  <i class="bi bi-search text-3xl mb-2 block"></i>
                  <p class="text-sm">No se encontraron productos</p>
                </div>
              </template>
            </div>

            <div class="mt-4" x-show="historial.length">
              <h3 class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">Ventas del d\u00eda</h3>
              <div class="space-y-2">
                <template x-for="v in historial" :key="v.id">
                  <div class="bg-white rounded-lg border border-gray-200 p-3 flex items-center justify-between">
                    <div>
                      <p class="text-sm font-medium text-gray-900" x-text="'#' + v.folio"></p>
                      <p class="text-xs text-gray-400" x-text="v.metodoPago + ' \u00b7 ' + formatearFecha(v.createdAt)"></p>
                    </div>
                    <span class="text-sm font-bold text-gray-900" x-text="formatearMoneda(v.total)"></span>
                  </div>
                </template>
              </div>
            </div>
          </div>

          <div class="lg:col-span-2">
            <div class="bg-white rounded-xl border border-gray-200 sticky top-4">
              <div class="p-4 border-b border-gray-100">
                <div class="flex items-center justify-between">
                  <h3 class="font-semibold text-gray-900">Carrito</h3>
                  <span class="text-sm text-gray-500" x-text="carrito.length + ' art\u00edculo(s)'"></span>
                </div>
              </div>

              <div class="p-4 min-h-[200px]" x-show="carrito.length === 0">
                <div class="flex flex-col items-center justify-center py-8 text-gray-400">
                  <i class="bi bi-cart text-4xl mb-2"></i>
                  <p class="text-sm">Carrito vac\u00edo</p>
                  <p class="text-xs text-gray-300 mt-1">Selecciona productos para agregar</p>
                </div>
              </div>

              <div class="p-4 space-y-3 max-h-[320px] overflow-y-auto" x-show="carrito.length">
                <template x-for="(item, idx) in carrito" :key="item.id">
                  <div class="flex items-center gap-3 py-2 border-b border-gray-100 last:border-0">
                    <div class="flex-1 min-w-0">
                      <p class="text-sm font-medium text-gray-900 truncate" x-text="item.nombre"></p>
                      <p class="text-xs text-gray-400" x-text="formatearMoneda(item.precio) + ' c/u'"></p>
                    </div>
                    <div class="flex items-center gap-1">
                      <button class="w-7 h-7 flex items-center justify-center rounded-md border border-gray-200 text-gray-500 hover:bg-gray-50 transition-colors text-sm" @click="cambiarCantidad(idx, -1)">
                        <i class="bi bi-dash"></i>
                      </button>
                      <span class="w-8 text-center text-sm font-medium text-gray-900" x-text="item.cantidad"></span>
                      <button class="w-7 h-7 flex items-center justify-center rounded-md border border-gray-200 text-gray-500 hover:bg-gray-50 transition-colors text-sm" @click="cambiarCantidad(idx, 1)">
                        <i class="bi bi-plus"></i>
                      </button>
                    </div>
                    <span class="text-sm font-semibold text-gray-900 w-20 text-right" x-text="formatearMoneda(item.subtotal)"></span>
                    <button class="text-gray-300 hover:text-red-500 transition-colors" @click="carrito.splice(idx, 1)">
                      <i class="bi bi-x-lg text-xs"></i>
                    </button>
                  </div>
                </template>
              </div>

              <div class="p-4 border-t border-gray-100" x-show="carrito.length">
                <div class="flex items-center justify-between mb-4">
                  <span class="text-base font-semibold text-gray-900">Total</span>
                  <span class="text-xl font-bold text-indigo-600" x-text="formatearMoneda(totalCarrito)"></span>
                </div>

                <div class="space-y-2">
                  <select x-model="metodoPago"
                          class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow">
                    <option value="efectivo">Efectivo</option>
                    <option value="tarjeta">Tarjeta</option>
                    <option value="transferencia">Transferencia</option>
                    <option value="mixto">Mixto</option>
                  </select>
                  <template x-if="metodoPago === 'efectivo' || metodoPago === 'mixto'">
                    <input type="number" step="0.01" min="0" x-model="montoPago"
                           placeholder="Monto recibido"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" />
                  </template>
                  <template x-if="cambio > 0">
                    <div class="flex items-center justify-between text-sm">
                      <span class="text-gray-500">Cambio</span>
                      <span class="font-medium text-green-600" x-text="formatearMoneda(cambio)"></span>
                    </div>
                  </template>
                  <button class="w-full py-2.5 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                          :disabled="carrito.length === 0 || !puedeCobrar"
                          @click="cobrar()">
                    <i class="bi bi-check2-circle"></i> Cobrar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <template x-if="cargando">
          <div class="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div class="lg:col-span-3 space-y-4">
              <div class="h-12 bg-gray-200 rounded-lg animate-pulse"></div>
              <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <template x-for="i in 6" :key="i">
                  <div class="bg-white rounded-xl border border-gray-200 p-3">
                    <div class="h-20 bg-gray-200 rounded-lg animate-pulse mb-2"></div>
                    <div class="h-4 bg-gray-200 rounded animate-pulse w-3/4 mb-1"></div>
                    <div class="h-4 bg-gray-200 rounded animate-pulse w-1/2"></div>
                  </div>
                </template>
              </div>
            </div>
            <div class="lg:col-span-2">
              <div class="bg-white rounded-xl border border-gray-200 p-4 space-y-4">
                <div class="h-6 bg-gray-200 rounded animate-pulse w-1/3"></div>
                <div class="h-32 bg-gray-200 rounded animate-pulse"></div>
              </div>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.carrito = [];
    this.historial = [];
    this.productos = [];
    this.searchQuery = '';
    this.filtroCategoria = '';
    this.cargando = true;
    this.kpis = { ventasHoy: 0, transacciones: 0, ticketPromedio: 0, efectivoHoy: 0 };
  },

  get totalCarrito() {
    let t = 0;
    for (const item of this.carrito) t += item.subtotal;
    return t;
  },

  get cambio() {
    if (!this.montoPago) return 0;
    const pago = parseFloat(this.montoPago) || 0;
    return Math.max(0, pago - this.totalCarrito);
  },

  get puedeCobrar() {
    if (this.carrito.length === 0) return false;
    if (this.metodoPago === 'efectivo' || this.metodoPago === 'mixto') {
      const pago = parseFloat(this.montoPago) || 0;
      return pago >= this.totalCarrito;
    }
    return true;
  },

  formatearFecha(fecha) {
    if (!fecha) return '';
    try {
      return new Date(fecha).toLocaleTimeString('es-MX', {
        hour: '2-digit', minute: '2-digit'
      });
    } catch { return fecha; }
  },

  formatearMoneda(valor) {
    if (valor == null || isNaN(valor)) return '$0.00';
    return '$' + Number(valor).toLocaleString('es-MX', {
      minimumFractionDigits: 2, maximumFractionDigits: 2
    });
  },

  esHoy(fecha) {
    const d = new Date(fecha);
    const h = new Date();
    return d.getFullYear() === h.getFullYear() &&
           d.getMonth() === h.getMonth() &&
           d.getDate() === h.getDate();
  },

  async cargarProductos() {
    try {
      this.cargando = true;
      this.productos = await db.productos.where('estado').equals('activo').toArray();
      this.productos = this.productos.filter(p => (p.stock || 0) > 0);
      const cats = new Set();
      for (const p of this.productos) {
        if (p.categoria) cats.add(p.categoria);
      }
      this.categorias = [...cats].sort();
      this.buscarProductos();
    } catch (e) {
      console.error('Error cargando productos:', e);
      UI.toast('Error al cargar productos', 'error');
    } finally {
      this.cargando = false;
    }
  },

  async cargarHistorial() {
    try {
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0);
      const hoyStr = hoy.toISOString();
      const manana = new Date(hoy);
      manana.setDate(manana.getDate() + 1);
      const mananaStr = manana.toISOString();
      const ventas = await db.ventas
        .where('createdAt')
        .between(hoyStr, mananaStr)
        .reverse()
        .toArray();
      this.historial = ventas;
      let total = 0;
      let efectivo = 0;
      for (const v of ventas) {
        total += v.total || 0;
        if (v.metodoPago === 'efectivo') efectivo += v.total || 0;
      }
      this.kpis = {
        ventasHoy: total,
        transacciones: ventas.length,
        ticketPromedio: ventas.length > 0 ? total / ventas.length : 0,
        efectivoHoy: efectivo
      };
    } catch (e) {
      console.error('Error cargando historial:', e);
    }
  },

  buscarProductos() {
    this.buscandoProductos = true;
    const q = this.searchQuery.trim().toLowerCase();
    let filtrados = this.productos;
    if (q) {
      filtrados = filtrados.filter(p =>
        (p.nombre || '').toLowerCase().includes(q) ||
        (p.sku || '').toLowerCase().includes(q)
      );
    }
    if (this.filtroCategoria) {
      filtrados = filtrados.filter(p => p.categoria === this.filtroCategoria);
    }
    this.productosFiltrados = filtrados;
    this.buscandoProductos = false;
  },

  agregarAlCarrito(producto) {
    const existente = this.carrito.findIndex(i => i.id === producto.id);
    if (existente >= 0) {
      this.carrito[existente].cantidad++;
      this.carrito[existente].subtotal = this.carrito[existente].precio * this.carrito[existente].cantidad;
    } else {
      this.carrito.push({
        id: producto.id,
        nombre: producto.nombre,
        precio: producto.precio,
        cantidad: 1,
        subtotal: producto.precio,
        imagen: producto.imagen || ''
      });
    }
  },

  cambiarCantidad(idx, delta) {
    const item = this.carrito[idx];
    item.cantidad = Math.max(1, item.cantidad + delta);
    item.subtotal = item.precio * item.cantidad;
  },

  async cobrar() {
    if (!this.puedeCobrar) return;
    const total = this.totalCarrito;
    const pago = parseFloat(this.montoPago) || total;
    const folio = 'V-' + new Date().getTime().toString(36).toUpperCase();
    const venta = {
      id: uuid(),
      folio: folio,
      items: this.carrito.map(i => ({
        id: i.id, nombre: i.nombre, precio: i.precio,
        cantidad: i.cantidad, subtotal: i.subtotal
      })),
      total: total,
      pago: pago,
      cambio: pago - total,
      metodoPago: this.metodoPago,
      cliente: '',
      estado: 'completada',
      createdBy: APP_CONFIG?.usuarioActual || 'anon',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    try {
      for (const item of this.carrito) {
        const prod = await db.productos.get(item.id);
        if (prod) {
          prod.stock = (prod.stock || 0) - item.cantidad;
          prod.updatedAt = new Date().toISOString();
          await db.productos.put(prod);
        }
      }
      await db.ventas.put(venta);
      UI.toast('Venta #' + folio + ' completada', 'success');
      this.carrito = [];
      this.montoPago = '';
      await Promise.all([this.cargarProductos(), this.cargarHistorial()]);
    } catch (e) {
      console.error('Error al cobrar:', e);
      UI.toast('Error al procesar venta: ' + e.message, 'error');
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['pos-ventas'] = ModuloPOSVentas;

document.addEventListener('alpine:init', () => {
  Alpine.data('posVentasData', () => ModuloPOSVentas);
});
