const ModuloFlotaVehiculos = {
  id: 'flota-vehiculos',
  titulo: 'Vehículos',
  icono: 'bi bi-truck',

  items: [],
  loading: true,
  errors: {},
  searchQuery: '',
  filtroEstado: '',
  kpis: { total: 0, activos: 0, enTaller: 0, fueraServicio: 0 },

  tipos: ['Sedán', 'SUV', 'Pickup', 'Carga', 'Motocicleta', 'Camión', 'Van'],
  estados: ['Activo', 'En taller', 'Fuera de servicio', 'Vendido'],

  async init() {
    await this.cargar();
  },

  render() {
    return `
      <div x-data="flotaVehiculosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-sky-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-truck text-sky-600"></i> Vehículos
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Activos</p>
            <p class="text-2xl font-bold text-sky-600" x-text="kpis.activos"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">En taller</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.enTaller"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Fuera de servicio</p>
            <p class="text-2xl font-bold text-red-600" x-text="kpis.fueraServicio"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 text-white text-sm font-medium rounded-lg hover:bg-sky-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Vehículo
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="cargar" placeholder="Buscar por placas o económico..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none transition-shadow" />
          </div>
          <select x-model="filtroEstado" @change="cargar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-sky-500 outline-none transition-shadow">
            <option value="">Todos los estados</option>
            <template x-for="e in estados" :key="e">
              <option :value="e" x-text="e"></option>
            </template>
          </select>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-truck text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">Sin vehículos registrados</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 text-white text-sm font-medium rounded-lg hover:bg-sky-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Agregar primero
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Placas</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Económico</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Marca / Modelo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Año</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Tipo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Estado</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Acciones</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <template x-for="v in items" :key="v.id">
                    <tr class="hover:bg-gray-50 transition-colors cursor-pointer" @click="abrirForm(v)">
                      <td class="px-4 py-3 font-medium text-gray-900" x-text="v.placas || '—'"></td>
                      <td class="px-4 py-3 text-gray-700" x-text="v.numeroEconomico || '—'"></td>
                      <td class="px-4 py-3 text-gray-700" x-text="(v.marca || '') + ' ' + (v.modelo || '')"></td>
                      <td class="px-4 py-3 text-gray-500" x-text="v.anio || '—'"></td>
                      <td class="px-4 py-3"><span class="text-xs text-gray-500" x-text="v.tipo || '—'"></span></td>
                      <td class="px-4 py-3">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium" :class="estadoClass(v.estado)" x-text="v.estado || 'Activo'"></span>
                      </td>
                      <td class="px-4 py-3 text-right">
                        <button class="text-gray-400 hover:text-red-500 transition-colors p-1" @click.stop="eliminar(v)">
                          <i class="bi bi-trash"></i>
                        </button>
                      </td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-4">
                <div class="h-4 w-24 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-16 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-36 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-12 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-5 w-20 bg-gray-200 rounded animate-pulse ml-auto"></div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.searchQuery = '';
    this.filtroEstado = '';
    this.loading = true;
    this.kpis = { total: 0, activos: 0, enTaller: 0, fueraServicio: 0 };
  },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return f; } },

  estadoClass(e) {
    const m = { 'Activo': 'bg-sky-100 text-sky-700', 'En taller': 'bg-amber-100 text-amber-700', 'Fuera de servicio': 'bg-red-100 text-red-700', 'Vendido': 'bg-gray-100 text-gray-700' };
    return m[e] || 'bg-gray-100 text-gray-700';
  },

  async cargar() {
    try {
      this.loading = true;
      let datos = await db.vehiculos.orderBy('createdAt').reverse().toArray();
      const q = this.searchQuery.trim().toLowerCase();
      if (q) datos = datos.filter(v => (v.placas || '').toLowerCase().includes(q) || (v.numeroEconomico || '').toLowerCase().includes(q) || (v.marca || '').toLowerCase().includes(q));
      if (this.filtroEstado) datos = datos.filter(v => v.estado === this.filtroEstado);
      this.items = datos;
      this.kpis = {
        total: datos.length,
        activos: datos.filter(v => v.estado === 'Activo' || !v.estado).length,
        enTaller: datos.filter(v => v.estado === 'En taller').length,
        fueraServicio: datos.filter(v => v.estado === 'Fuera de servicio').length
      };
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div class="grid grid-cols-2 gap-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Placas <span class="text-red-500">*</span></label>',
      '<input type="text" x-model="form.placas" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow uppercase"',
      ':class="errors.placas ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-sky-500 focus:border-sky-500\'" />',
      '<template x-if="errors.placas"><p class="mt-1 text-sm text-red-500" x-text="errors.placas"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">No. Económico</label>',
      '<input type="text" x-model="form.numeroEconomico" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Marca <span class="text-red-500">*</span></label>',
      '<input type="text" x-model="form.marca" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.marca ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-sky-500 focus:border-sky-500\'" />',
      '<template x-if="errors.marca"><p class="mt-1 text-sm text-red-500" x-text="errors.marca"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Modelo</label>',
      '<input type="text" x-model="form.modelo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Año</label>',
      '<input type="number" min="1990" max="2099" x-model="form.anio" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Tipo</label>',
      '<select x-model="form.tipo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow bg-white">',
      '<option value="">Seleccionar...</option>',
      '<template x-for="t in tipos" :key="t"><option :value="t" x-text="t"></option></template>',
      '</select></div>',
      '<div class="col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Estado</label>',
      '<select x-model="form.estado" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow bg-white">',
      '<template x-for="e in estados" :key="e"><option :value="e" x-text="e"></option></template>',
      '</select></div>',
      '</div></div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Vehículo' : 'Nuevo Vehículo', html,
      async (data) => {
        if (editando) await this.actualizar(item.id, data);
        else await this.guardar(data);
        await this.cargar();
      }, item || { estado: 'Activo' }
    );
  },

  validarForm(d) {
    this.errors = {};
    if (!d.placas || !d.placas.trim()) this.errors.placas = 'Las placas son obligatorias';
    if (!d.marca || !d.marca.trim()) this.errors.marca = 'La marca es obligatoria';
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    try {
      await db.vehiculos.put({
        id: uuid(), placas: datos.placas.trim().toUpperCase(), numeroEconomico: datos.numeroEconomico?.trim() || '',
        marca: datos.marca.trim(), modelo: datos.modelo?.trim() || '', anio: parseInt(datos.anio) || null,
        tipo: datos.tipo || '', estado: datos.estado || 'Activo',
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      });
      UI.toast('Vehículo guardado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    try {
      const e = await db.vehiculos.get(id);
      if (!e) { UI.toast('No encontrado', 'error'); return; }
      await db.vehiculos.put({ ...e, placas: datos.placas.trim().toUpperCase(),
        numeroEconomico: datos.numeroEconomico?.trim() || '', marca: datos.marca.trim(),
        modelo: datos.modelo?.trim() || '', anio: parseInt(datos.anio) || null,
        tipo: datos.tipo || '', estado: datos.estado || 'Activo',
        updatedAt: new Date().toISOString() });
      UI.toast('Vehículo actualizado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar vehículo ' + (item.placas || '') + '?');
    if (!ok) return;
    try { await db.vehiculos.delete(item.id); UI.toast('Eliminado', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['flota-vehiculos'] = ModuloFlotaVehiculos;

document.addEventListener('alpine:init', () => {
  Alpine.data('flotaVehiculosData', () => ModuloFlotaVehiculos);
});
