const ModuloPOSProductos = {
  id: 'pos-productos',
  titulo: 'Productos',
  icono: 'bi bi-box-seam',

  items: [],
  item: null,
  categorias: [],
  errors: {},
  searchQuery: '',
  filtroCategoria: '',
  loading: true,
  error: null,
  saving: false,
  page: 1,
  pageSize: 12,
  totalPages: 1,
  kpis: { total: 0, bajoStock: 0, sinStock: 0, valorTotal: 0 },

  async init() {
    await this.cargarDatos();
  },

  render(params = {}) {
    return `
      <div x-data="posProductosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-indigo-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-box-seam text-indigo-600"></i> Productos
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Stock bajo</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.bajoStock"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Sin stock</p>
            <p class="text-2xl font-bold text-red-600" x-text="kpis.sinStock"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Valor inventario</p>
            <p class="text-2xl font-bold text-gray-900" x-text="formatearMoneda(kpis.valorTotal)"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-6">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Producto
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="buscar" placeholder="Buscar productos..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow" />
          </div>
          <select x-model="filtroCategoria" @change="buscar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow">
            <option value="">Todas las categor\u00edas</option>
            <template x-for="cat in categorias" :key="cat">
              <option :value="cat" x-text="cat"></option>
            </template>
          </select>
          <button class="inline-flex items-center gap-1.5 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors" @click="exportarCSV()" x-show="items.length">
            <i class="bi bi-download"></i> Exportar
          </button>
        </div>

        <template x-if="error">
          <div class="p-4 mb-4 bg-red-50 border border-red-200 rounded-lg">
            <div class="flex items-center gap-2 text-red-700 text-sm">
              <i class="bi bi-exclamation-triangle"></i>
              <span x-text="error"></span>
            </div>
          </div>
        </template>

        <template x-if="!loading && !error && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-box-seam text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">No hay productos a\u00fan</p>
            <p class="text-sm text-gray-400 mb-6">Agrega tu primer producto para empezar a vender</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Agregar primero
            </button>
          </div>
        </template>

        <template x-if="!loading && items.length > 0">
          <div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              <template x-for="(item, idx) in paginated" :key="item.id">
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 cursor-pointer"
                     @click="abrirForm(item)">
                  <div class="h-40 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                    <template x-if="item.imagen">
                      <img :src="item.imagen" :alt="item.nombre" class="w-full h-full object-cover" />
                    </template>
                    <template x-if="!item.imagen">
                      <i class="bi bi-image text-4xl text-gray-300"></i>
                    </template>
                  </div>
                  <div class="p-4">
                    <div class="flex items-start justify-between gap-2 mb-1">
                      <h3 class="font-semibold text-gray-900 text-sm leading-tight" x-text="item.nombre"></h3>
                      <span class="text-sm font-bold text-indigo-600 whitespace-nowrap" x-text="formatearMoneda(item.precio)"></span>
                    </div>
                    <div class="flex items-center gap-2 mb-2">
                      <span class="text-xs text-gray-400" x-text="item.categoria || 'Sin categor\u00eda'"></span>
                      <span class="text-gray-300">\u00b7</span>
                      <span class="text-xs text-gray-400" x-text="item.sku || 'Sin SKU'"></span>
                    </div>
                    <div class="flex items-center gap-2">
                      <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                            :class="stockClass(item.stock)"
                            x-text="stockLabel(item.stock)"></span>
                      <span class="text-xs text-gray-400" x-text="item.stock + ' uds'"></span>
                    </div>
                  </div>
                </div>
              </template>
            </div>

            <div class="flex justify-between items-center mt-6" x-show="totalPages > 1">
              <span class="text-sm text-gray-500">
                P\u00e1gina <span class="font-medium text-gray-700" x-text="page"></span> de <span class="font-medium text-gray-700" x-text="totalPages"></span>
              </span>
              <div class="flex gap-2">
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === 1" @click="page--;">
                  <i class="bi bi-chevron-left"></i>
                </button>
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === totalPages" @click="page++;">
                  <i class="bi bi-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              <template x-for="i in 8" :key="i">
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                  <div class="h-40 bg-gray-200 animate-pulse"></div>
                  <div class="p-4 space-y-3">
                    <div class="h-4 bg-gray-200 rounded animate-pulse w-3/4"></div>
                    <div class="h-3 bg-gray-200 rounded animate-pulse w-1/2"></div>
                    <div class="h-5 bg-gray-200 rounded animate-pulse w-1/4"></div>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.item = null;
    this.searchQuery = '';
    this.filtroCategoria = '';
    this.loading = true;
    this.error = null;
    this.page = 1;
    this.kpis = { total: 0, bajoStock: 0, sinStock: 0, valorTotal: 0 };
  },

  formatearFecha(fecha) {
    if (!fecha) return '';
    try {
      return new Date(fecha).toLocaleDateString('es-MX', {
        year: 'numeric', month: 'short', day: 'numeric'
      });
    } catch { return fecha; }
  },

  formatearMoneda(valor) {
    if (valor == null || isNaN(valor)) return '$0.00';
    return '$' + Number(valor).toLocaleString('es-MX', {
      minimumFractionDigits: 2, maximumFractionDigits: 2
    });
  },

  stockClass(stock) {
    if (!stock || stock <= 0) return 'bg-red-100 text-red-700';
    if (stock <= 5) return 'bg-amber-100 text-amber-700';
    return 'bg-green-100 text-green-700';
  },

  stockLabel(stock) {
    if (!stock || stock <= 0) return 'Agotado';
    if (stock <= 5) return 'Stock bajo';
    return 'Disponible';
  },

  get paginated() {
    const start = (this.page - 1) * this.pageSize;
    return this.items.slice(start, start + this.pageSize);
  },

  _cifrarSensibles(obj) {
    if (!APP_CONFIG?.cifrado?.camposSensibles) return obj;
    for (const campo of APP_CONFIG.cifrado.camposSensibles) {
      if (obj[campo] && typeof obj[campo] === 'string' && !obj[campo].startsWith('U2FsdGVkX1')) {
        obj[campo] = cryptoHelpers.encrypt(obj[campo]);
      }
    }
    return obj;
  },

  _descifrarSensibles(obj) {
    if (!APP_CONFIG?.cifrado?.camposSensibles) return obj;
    for (const campo of APP_CONFIG.cifrado.camposSensibles) {
      if (obj[campo]) obj[campo] = cryptoHelpers.decrypt(obj[campo]);
    }
    return obj;
  },

  recalcularKPIs() {
    const total = this.items.length;
    let bajoStock = 0;
    let sinStock = 0;
    let valorTotal = 0;
    for (const item of this.items) {
      const stock = item.stock || 0;
      const precio = item.precio || 0;
      if (stock <= 0) sinStock++;
      else if (stock <= 5) bajoStock++;
      valorTotal += stock * precio;
    }
    this.kpis = { total, bajoStock, sinStock, valorTotal };
  },

  extraerCategorias() {
    const cats = new Set();
    for (const item of this.items) {
      if (item.categoria) cats.add(item.categoria);
    }
    this.categorias = [...cats].sort();
  },

  async cargarDatos() {
    try {
      this.loading = true;
      this.error = null;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.productos.orderBy('createdAt').reverse().toArray();
      if (filtro) {
        datos = datos.filter(i =>
          (i.nombre || '').toLowerCase().includes(filtro) ||
          (i.sku || '').toLowerCase().includes(filtro) ||
          (i.categoria || '').toLowerCase().includes(filtro)
        );
      }
      if (this.filtroCategoria) {
        datos = datos.filter(i => i.categoria === this.filtroCategoria);
      }
      this.items = datos;
      this.recalcularKPIs();
      this.extraerCategorias();
      this.totalPages = Math.max(1, Math.ceil(this.items.length / this.pageSize));
      if (this.page > this.totalPages) this.page = this.totalPages;
    } catch (e) {
      console.error('Error cargando datos:', e);
      this.error = 'Error al cargar datos';
      UI.toast('Error al cargar datos', 'error');
    } finally {
      this.loading = false;
    }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const descifrado = item ? this._descifrarSensibles({ ...item }) : {};
    const html = `
      <div class="space-y-4">
        <div class="grid grid-cols-2 gap-4">
          <div class="col-span-2">
            <label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>
            <input type="text" x-model="form.nombre"
                   class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                   :class="errors.nombre ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500'" />
            <template x-if="errors.nombre">
              <p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p>
            </template>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Precio <span class="text-red-500">*</span></label>
            <input type="number" step="0.01" min="0" x-model="form.precio"
                   class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                   :class="errors.precio ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500'" />
            <template x-if="errors.precio">
              <p class="mt-1 text-sm text-red-500" x-text="errors.precio"></p>
            </template>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Stock <span class="text-red-500">*</span></label>
            <input type="number" min="0" x-model="form.stock"
                   class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                   :class="errors.stock ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500'" />
            <template x-if="errors.stock">
              <p class="mt-1 text-sm text-red-500" x-text="errors.stock"></p>
            </template>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Categor\u00eda</label>
            <input type="text" x-model="form.categoria" list="cat-list"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow" />
            <datalist id="cat-list">
              <template x-for="cat in categorias" :key="cat">
                <option :value="cat"></option>
              </template>
            </datalist>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">SKU</label>
            <input type="text" x-model="form.sku"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow" />
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Descripci\u00f3n</label>
          <textarea x-model="form.descripcion"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow" rows="2"></textarea>
        </div>
      </div>`;
    await UI.modalForm(
      editando ? 'Editar Producto' : 'Nuevo Producto',
      html,
      async (data) => {
        if (editando) await this.actualizar(descifrado.id, data);
        else await this.guardar(data);
        await this.cargarDatos();
      },
      descifrado
    );
  },

  validarForm(datos) {
    this.errors = {};
    if (!datos.nombre || !datos.nombre.trim()) {
      this.errors.nombre = 'El nombre es obligatorio';
    }
    if (datos.precio == null || datos.precio === '' || Number(datos.precio) < 0) {
      this.errors.precio = 'Ingresa un precio v\u00e1lido';
    }
    if (datos.stock == null || datos.stock === '' || Number(datos.stock) < 0) {
      this.errors.stock = 'Ingresa un stock v\u00e1lido';
    }
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const registro = this._cifrarSensibles({
        id: uuid(),
        nombre: datos.nombre.trim(),
        descripcion: datos.descripcion?.trim() || '',
        precio: parseFloat(datos.precio) || 0,
        stock: parseInt(datos.stock) || 0,
        categoria: datos.categoria?.trim() || '',
        sku: datos.sku?.trim() || '',
        imagen: datos.imagen || '',
        estado: 'activo',
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      await db.productos.put(registro);
      UI.toast('Producto guardado correctamente', 'success');
    } catch (e) {
      console.error('Error al guardar:', e);
      UI.toast('Error al guardar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const existente = await db.productos.get(id);
      if (!existente) {
        UI.toast('Producto no encontrado', 'error');
        return;
      }
      const actualizado = this._cifrarSensibles({
        ...existente,
        nombre: datos.nombre.trim(),
        descripcion: datos.descripcion?.trim() || '',
        precio: parseFloat(datos.precio) || 0,
        stock: parseInt(datos.stock) || 0,
        categoria: datos.categoria?.trim() || '',
        sku: datos.sku?.trim() || '',
        imagen: datos.imagen || '',
        updatedAt: new Date().toISOString()
      });
      await db.productos.put(actualizado);
      UI.toast('Producto actualizado correctamente', 'success');
    } catch (e) {
      console.error('Error al actualizar:', e);
      UI.toast('Error al actualizar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar ' + (item.nombre || 'este producto') + '?');
    if (!ok) return;
    try {
      await db.productos.delete(item.id);
      UI.toast('Producto eliminado correctamente', 'success');
      await this.cargarDatos();
    } catch (e) {
      console.error('Error al eliminar:', e);
      UI.toast(e.message, 'error');
    }
  },

  async buscar() {
    this.page = 1;
    await this.cargarDatos();
  },

  async limpiarBusqueda() {
    this.searchQuery = '';
    this.filtroCategoria = '';
    this.page = 1;
    await this.cargarDatos();
  },

  async exportarCSV() {
    if (!this.items.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const XLSX = window.XLSX;
      if (XLSX) {
        const ws = XLSX.utils.json_to_sheet(this.items.map(i => ({
          Nombre: i.nombre || '',
          SKU: i.sku || '',
          Categoria: i.categoria || '',
          Precio: i.precio || 0,
          Stock: i.stock || 0,
          Estado: i.estado || 'activo'
        })));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Productos');
        XLSX.writeFile(wb, 'productos.xlsx');
        UI.toast('Excel exportado', 'success');
      } else {
        const cabeceras = ['Nombre', 'SKU', 'Categoria', 'Precio', 'Stock', 'Estado'];
        const filas = this.items.map(i => [
          i.nombre || '', i.sku || '', i.categoria || '',
          i.precio || 0, i.stock || 0, i.estado || 'activo'
        ]);
        let csv = cabeceras.join(',') + '\n';
        for (const fila of filas) {
          csv += fila.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',') + '\n';
        }
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'productos.csv';
        a.click();
        URL.revokeObjectURL(url);
        UI.toast('CSV exportado', 'success');
      }
    } catch (e) {
      console.error('Error exportando:', e);
      UI.toast('Error al exportar', 'error');
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['pos-productos'] = ModuloPOSProductos;

document.addEventListener('alpine:init', () => {
  Alpine.data('posProductosData', () => ModuloPOSProductos);
});
