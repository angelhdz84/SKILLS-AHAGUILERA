﻿const ModuloCitasCalendario = {
  id: 'citas-calendario',
  titulo: 'Calendario',
  icono: 'bi bi-calendar-month',

  year: new Date().getFullYear(),
  month: new Date().getMonth(),
  citas: [],
  clientes: [],
  servicios: [],
  profesionales: [],
  diaSeleccionado: null,
  loading: true,
  kpis: { totalMes: 0, profesionalesActivos: 0 },

  async init() {
    await Promise.all([this.cargarCatalogos(), this.cargarCitasMes()]);
  },

  render() {
    return `
      <div x-data="citasCalendarioData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-pink-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-calendar-month text-pink-600"></i> Calendario
          </h2>
        </div>

        <div class="grid grid-cols-3 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Citas del mes</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.totalMes"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Promedio x d\u00eda</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.porDia || '0'"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Profesionales activos</p>
            <p class="text-2xl font-bold text-green-600" x-text="kpis.profesionalesActivos"></p>
          </div>
        </div>

        <div class="flex items-center gap-3 mb-6">
          <button class="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors" @click="navegarMes(-1)">
            <i class="bi bi-chevron-left"></i>
          </button>
          <h3 class="text-lg font-bold text-gray-900 flex-1" x-text="nombreMes() + ' ' + year"></h3>
          <button class="px-3 py-1.5 text-xs text-pink-600 hover:text-pink-700 font-medium border border-pink-200 rounded-lg" @click="irHoy()">Hoy</button>
          <button class="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors" @click="navegarMes(1)">
            <i class="bi bi-chevron-right"></i>
          </button>
        </div>

        <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div class="grid grid-cols-7 border-b border-gray-100 bg-gray-50/50">
            <template x-for="d in ['Dom','Lun','Mar','Mi\u00e9','Jue','Vie','S\u00e1b']" :key="d">
              <div class="px-3 py-2 text-center text-xs font-semibold uppercase tracking-wider text-gray-500" x-text="d"></div>
            </template>
          </div>
          <div class="grid grid-cols-7">
            <template x-for="(semana, si) in grid" :key="si">
              <template x-for="(dia, di) in semana" :key="si + '-' + di">
                <div class="min-h-[90px] border-r border-b border-gray-100 p-1.5 cursor-pointer transition-colors hover:bg-pink-50/50 relative"
                     :class="esHoy(dia) ? 'bg-pink-50' : ''"
                     :style="diaSeleccionado && diaSeleccionado === dia ? 'background: #fdf2f8;' : ''"
                     @click="seleccionarDia(dia)">
                  <template x-if="dia > 0">
                    <div>
                      <span class="text-sm font-medium"
                            :class="esHoy(dia) ? 'text-pink-600 bg-pink-100 w-7 h-7 flex items-center justify-center rounded-full' : 'text-gray-700'"
                            x-text="dia"></span>
                      <template x-if="citasPorDia(dia) > 0">
                        <div class="mt-1">
                          <div class="flex items-center gap-0.5">
                            <span class="w-2 h-2 rounded-full bg-pink-500"></span>
                            <span class="text-xs text-gray-500" x-text="citasPorDia(dia) + ' cita' + (citasPorDia(dia) !== 1 ? 's' : '')"></span>
                          </div>
                        </div>
                      </template>
                    </div>
                  </template>
                </div>
              </template>
            </template>
          </div>
        </div>

        <template x-if="diaSeleccionado">
          <div class="mt-6">
            <h3 class="text-base font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <i class="bi bi-calendar-day text-pink-600"></i>
              Citas del <span x-text="fechaDiaSeleccionado()"></span>
            </h3>
            <template x-if="citasDelDia().length === 0">
              <div class="flex flex-col items-center justify-center py-8 text-gray-400">
                <i class="bi bi-calendar-x text-4xl mb-2"></i>
                <p class="text-sm">Sin citas este d\u00eda</p>
              </div>
            </template>
            <div class="space-y-2" x-show="citasDelDia().length > 0">
              <template x-for="c in citasDelDia()" :key="c.id">
                <div class="flex items-center gap-3 bg-white rounded-lg border border-gray-200 p-3 hover:shadow-sm transition-shadow">
                  <div class="w-12 text-center shrink-0">
                    <span class="block text-sm font-bold text-gray-900" x-text="c.horaInicio ? c.horaInicio.substring(0,5) : '--'"></span>
                  </div>
                  <div class="w-2 h-2 rounded-full shrink-0"
                       :class="c.estado === 'completada' ? 'bg-green-500' : c.estado === 'cancelada' ? 'bg-red-400' : 'bg-amber-400'"></div>
                  <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-900 truncate" x-text="nombreCliente(c.clienteId)"></p>
                    <p class="text-xs text-gray-400 truncate">
                      <span x-text="nombreServicio(c.servicioId)"></span>
                      <span class="mx-1">\u00b7</span>
                      <span x-text="nombreProfesional(c.profesionalId)"></span>
                    </p>
                  </div>
                  <span class="text-sm font-semibold text-pink-600" x-text="formatearMoneda(precioServicio(c.servicioId))"></span>
                  <span class="text-xs px-2 py-0.5 rounded-full font-medium"
                        :class="c.estado === 'completada' ? 'bg-green-100 text-green-700' : c.estado === 'cancelada' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-700'"
                        x-text="c.estado === 'completada' ? 'Hecha' : c.estado === 'cancelada' ? 'Cancelada' : 'Pend.'"></span>
                </div>
              </template>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div>
            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div class="grid grid-cols-7 gap-px bg-gray-100">
                <template x-for="i in 35" :key="i">
                  <div class="bg-white min-h-[90px] p-2">
                    <div class="w-7 h-7 bg-gray-200 rounded-full animate-pulse mb-2"></div>
                    <div class="h-3 bg-gray-200 rounded animate-pulse w-3/4"></div>
                  </div>
                </template>
              </div>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.citas = [];
    this.clientes = [];
    this.servicios = [];
    this.profesionales = [];
    this.diaSeleccionado = null;
    this.loading = true;
    this.kpis = { totalMes: 0, profesionalesActivos: 0 };
  },

  get grid() {
    const primerDia = new Date(this.year, this.month, 1);
    const ultimoDia = new Date(this.year, this.month + 1, 0);
    const inicioSemana = (primerDia.getDay() + 6) % 7;
    const totalDias = ultimoDia.getDate();
    const grid = [];
    let semana = [];
    for (let i = 0; i < inicioSemana; i++) semana.push(0);
    for (let d = 1; d <= totalDias; d++) {
      semana.push(d);
      if (semana.length === 7) { grid.push(semana); semana = []; }
    }
    if (semana.length > 0) { while (semana.length < 7) semana.push(0); grid.push(semana); }
    return grid;
  },

  nombreMes() {
    const meses = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    return meses[this.month];
  },

  esHoy(dia) {
    if (!dia) return false;
    const h = new Date();
    return dia === h.getDate() && this.month === h.getMonth() && this.year === h.getFullYear();
  },

  irHoy() {
    const h = new Date();
    this.year = h.getFullYear();
    this.month = h.getMonth();
    this.diaSeleccionado = h.getDate();
    this.cargarCitasMes();
  },

  navegarMes(delta) {
    this.month += delta;
    if (this.month > 11) { this.month = 0; this.year++; }
    if (this.month < 0) { this.month = 11; this.year--; }
    this.diaSeleccionado = null;
    this.cargarCitasMes();
  },

  fechaStr(dia) {
    return this.year + '-' + String(this.month + 1).padStart(2, '0') + '-' + String(dia).padStart(2, '0');
  },

  citasPorDia(dia) {
    if (!dia) return 0;
    const f = this.fechaStr(dia);
    return this.citas.filter(c => c.fecha === f).length;
  },

  citasDelDia() {
    if (!this.diaSeleccionado) return [];
    const f = this.fechaStr(this.diaSeleccionado);
    return this.citas.filter(c => c.fecha === f).sort((a, b) => (a.horaInicio || '00:00').localeCompare(b.horaInicio || '00:00'));
  },

  seleccionarDia(dia) {
    if (!dia) return;
    this.diaSeleccionado = dia;
  },

  formatearMoneda(v) {
    if (v == null || isNaN(v)) return '$0.00';
    return '$' + Number(v).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  fechaDiaSeleccionado() {
    if (!this.diaSeleccionado) return '';
    try {
      return new Date(this.fechaStr(this.diaSeleccionado) + 'T12:00:00').toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric' });
    } catch { return this.fechaStr(this.diaSeleccionado); }
  },

  nombreCliente(id) {
    const c = this.clientes.find(x => x.id === id); return c ? c.nombre : '—';
  },
  nombreServicio(id) {
    const s = this.servicios.find(x => x.id === id); return s ? s.nombre : '—';
  },
  nombreProfesional(id) {
    const p = this.profesionales.find(x => x.id === id); return p ? p.nombre : '—';
  },
  precioServicio(id) {
    const s = this.servicios.find(x => x.id === id); return s ? (s.precio || 0) : 0;
  },

  async cargarCatalogos() {
    try {
      [this.clientes, this.servicios, this.profesionales] = await Promise.all([
        db.clientes.orderBy('nombre').toArray(),
        db.servicios.orderBy('nombre').toArray(),
        db.profesionales.orderBy('nombre').toArray()
      ]);
    } catch (e) { console.error('Error cargando catalogos:', e); }
  },

  async cargarCitasMes() {
    try {
      this.loading = true;
      const inicio = this.year + '-' + String(this.month + 1).padStart(2, '0') + '-01';
      const ultimoDia = new Date(this.year, this.month + 1, 0).getDate();
      const fin = this.year + '-' + String(this.month + 1).padStart(2, '0') + '-' + String(ultimoDia).padStart(2, '0');
      this.citas = await db.citas
        .where('fecha')
        .between(inicio, fin, true, true)
        .toArray();

      const profSet = new Set();
      for (const c of this.citas) if (c.profesionalId) profSet.add(c.profesionalId);
      const diasHabiles = this.grid.flat().filter(d => d > 0).length;
      this.kpis = {
        totalMes: this.citas.length,
        porDia: diasHabiles > 0 ? (this.citas.length / diasHabiles).toFixed(1) : '0',
        profesionalesActivos: profSet.size
      };
    } catch (e) {
      console.error('Error cargando citas del mes:', e);
      UI.toast('Error al cargar calendario', 'error');
    } finally {
      this.loading = false;
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['citas-calendario'] = ModuloCitasCalendario;

document.addEventListener('alpine:init', () => {
  Alpine.data('citasCalendarioData', () => ModuloCitasCalendario);
});
