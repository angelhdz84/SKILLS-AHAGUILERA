const ModuloCRMCotizaciones = {
  id: 'crm-cotizaciones',
  titulo: 'Cotizaciones',
  icono: 'bi bi-file-text',

  items: [],
  deals: [],
  loading: true,

  async init() {
    const [cots, dls] = await Promise.all([
      db.cotizaciones?.orderBy('createdAt').reverse().toArray() || [],
      db.deals?.orderBy('nombre').toArray() || []
    ]);
    this.items = cots;
    this.deals = dls;
    this.loading = false;
  },

  render() {
    return `
      <div x-data="crmCotizacionesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-blue-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-file-text text-blue-600"></i> Cotizaciones
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Cotizaci\u00f3n</button>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-file-text text-6xl mb-4"></i><p class="text-lg text-gray-500 mb-2">Sin cotizaciones</p></div>
        </template>

        <template x-if="items.length > 0">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="c in items" :key="c.id">
              <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow cursor-pointer" @click="verDetalle(c)">
                <div class="flex items-center justify-between mb-2">
                  <span class="text-sm font-bold text-blue-600" x-text="'Cotizaci\u00f3n #' + c.id.slice(0, 6)"></span>
                  <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                        :class="c.estado === 'aprobada' ? 'bg-green-100 text-green-700' : c.estado === 'rechazada' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'"
                        x-text="c.estado || 'pendiente'"></span>
                </div>
                <p class="text-sm font-medium text-gray-900 truncate" x-text="'$' + Number(c.total || 0).toLocaleString('es-MX')"></p>
                <p class="text-xs text-gray-400 mt-1" x-text="formatearFecha(c.createdAt)"></p>
              </div>
            </template>
          </div>
        </template>

        <template x-if="loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"><template x-for="i in 6" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-4 w-32 bg-gray-200 rounded animate-pulse mb-3"></div><div class="h-5 w-20 bg-gray-200 rounded animate-pulse"></div></div></template></div>
        </template>
      </div>
    `;
  },

  destroy() { this.items = []; this.deals = []; this.loading = true; },
  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX'); } catch { return f; } },

  async abrirForm() {
    const dls = this.deals;
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Deal relacionado</label><select x-model="form.dealId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow bg-white"><option value="">Seleccionar...</option>' + (dls || []).map(d => '<option value="' + d.id + '">' + d.nombre + ' ($' + Number(d.monto || 0).toLocaleString() + ')</option>').join('') + '</select></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Items (uno por l\u00ednea)</label><textarea x-model="form.items" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" placeholder="Concepto | Cantidad | Precio&#10;Ej: Consultor\u00eda | 1 | 5000"></textarea></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Total</label><input type="number" step="0.01" x-model="form.total" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div></div>';
    await UI.modalForm('Nueva Cotizaci\u00f3n', html, async (data) => {
      await db.cotizaciones.put({ id: window.uuid(), dealId: data.dealId || '', items: data.items || '', total: parseFloat(data.total) || 0, estado: 'pendiente', createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      UI.toast('Cotizaci\u00f3n creada', 'success');
      const [cots] = await Promise.all([db.cotizaciones.orderBy('createdAt').reverse().toArray()]);
      this.items = cots;
    }, { dealId: '', items: '', total: 0 });
  },

  async verDetalle(item) {
    const items = (item.items || '').split('\n').filter(l => l.trim()).map(l => { const p = l.split('|').map(s => s.trim()); return { concepto: p[0] || '', cantidad: parseInt(p[1]) || 1, precio: parseFloat(p[2]) || 0 }; });
    const html = [
      '<div class="space-y-3"><p class="text-xs text-gray-400">ID: ' + item.id.slice(0, 8) + '</p>',
      '<div class="border-t border-gray-200 pt-2"><h4 class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">Items</h4>',
      items.length === 0 ? '<p class="text-gray-400 text-sm">Sin items</p>' : items.map(i => '<div class="flex justify-between text-sm py-1 border-b border-gray-100"><span>' + i.cantidad + 'x ' + i.concepto + '</span><span class="font-mono">$' + i.precio.toLocaleString() + '</span></div>').join(''),
      '<div class="flex justify-between font-bold text-blue-600 pt-2"><span>Total</span><span class="font-mono">$' + Number(item.total || 0).toLocaleString('es-MX') + '</span></div>',
      '</div></div>'
    ].join('\n');
    UI.modalHtml('Cotizaci\u00f3n #' + item.id.slice(0, 6), html);
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['crm-cotizaciones'] = ModuloCRMCotizaciones;

document.addEventListener('alpine:init', () => {
  Alpine.data('crmCotizacionesData', () => ModuloCRMCotizaciones);
});
