# AHA Gastos — Spec Técnica

## Identidad
- **App:** AHA Gastos
- **Perfil:** Lite
- **Target:** Micro-pymes, emprendedores, freelancers
- **Tagline:** Control de gastos offline para micro-negocios
- **Color primario:** #059669 (emerald-600)
- **Descripción:** Lleva el control de ingresos y egresos diarios. Sin internet. Categoriza, reporta en PDF, visualiza flujo de caja.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  movimientos: 'id, tipo, *categoria, monto, *fecha, *nota, *createdBy, createdAt',
  categorias: 'id, nombre, tipo, *createdBy, createdAt, updatedAt',
  _sync_log: 'id, *tabla, *operacion, *idRegistro, *estado, *fecha, *createdBy, createdAt',
  _ia_chats: 'id, *titulo, *modelo, *createdBy, createdAt, updatedAt',
  _ia_messages: 'id, *chatId, *rol, contenido, *createdBy, createdAt'
});
```

Categorías predefinidas: renta, luz, mercancía, nómina, transporte, alimentos, servicios, otros

## Entry point
`core/main.js` (app shell central)

## Módulos

### dashboard
- Saldo actual del mes
- Gráfico donut ingresos vs egresos (Chart.js)
- Últimos 5 movimientos
- Componentes: saldo-card, grafico-donut, ultimos-movimientos

### movimientos
- CRUD: tipo (ingreso/egreso), categoría (select), monto, fecha, nota
- Lista filtrable por mes, categoría, tipo
- Modal para crear/editar

### categorias
- Grid de tarjetas
- CRUD con edición inline o modal
- Predefinidas + personalizables

### reportes
- Selector de mes
- Gráfico barras flujo de caja (Chart.js)
- Export PDF del reporte mensual
- Tabla filtrable exportable CSV

## IA integrada
- **Estadísticas Lite:** FlexSearch sobre mensajes predefinidos
- **Stats:** "Este mes gastaste X% más que el anterior"
- **Predicción:** "Saldo proyectado al cierre: $X"

## Estructura de archivos

```
aha-gastos/
├── index.html
├── manifest.json
├── sw.js
├── project.config.js
├── .gitignore
├── README.md
├── core/
│   ├── main.js
│   ├── app.js
│   ├── db.js
│   ├── crypto.js
│   ├── theme.js
│   ├── ui.js
│   ├── env.js
│   ├── network.js
│   ├── sync.js
│   └── seed.js
├── modules/
│   ├── dashboard/
│   │   ├── module.html
│   │   └── module.js
│   ├── movimientos/
│   │   ├── module.html
│   │   └── module.js
│   ├── categorias/
│   │   ├── module.html
│   │   └── module.js
│   └── reportes/
│       ├── module.html
│       └── module.js
├── assets/
│   ├── js/libs/ (alpine, dexie, chart, crypto-js, pako)
│   ├── css/ (daisyui, tailwind.play, bootstrap-icons, animate.min)
│   └── icons/ (icon-192, icon-512)
└── data/defaults/ (avatar.svg, placeholder.svg)
```

## Estilo
- DaisyUI 4 + Tailwind Play CDN
- Tema emerald (color primary: #059669)
- Chart.js para gráficos
- ES5 estricto en todo .js
