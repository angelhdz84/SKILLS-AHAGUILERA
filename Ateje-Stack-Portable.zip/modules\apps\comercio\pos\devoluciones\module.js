const ModuloPOSDevoluciones = {
  id: 'pos-devoluciones',
  titulo: 'Devoluciones',
  icono: 'bi bi-arrow-return-left',

  items: [],
  errors: {},
  searchQuery: '',
  filtroEstado: '',
  cargando: true,
  error: null,
  kpis: { devolucionesHoy: 0, reembolsadoHoy: 0, pendientes: 0 },

  async init() {
    await this.cargarDatos();
  },

  render(params = {}) {
    return `
      <div x-data="posDevolucionesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-indigo-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-arrow-return-left text-indigo-600"></i> Devoluciones
          </h2>
        </div>

        <div class="grid grid-cols-3 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Dev. hoy</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.devolucionesHoy"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Reembolsado hoy</p>
            <p class="text-2xl font-bold text-red-600" x-text="formatearMoneda(kpis.reembolsadoHoy)"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Pendientes</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.pendientes"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Nueva devoluci\u00f3n
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="buscar" placeholder="Buscar por folio de venta..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow" />
          </div>
          <select x-model="filtroEstado" @change="buscar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow">
            <option value="">Todos</option>
            <option value="completada">Completadas</option>
            <option value="pendiente">Pendientes</option>
            <option value="rechazada">Rechazadas</option>
          </select>
        </div>

        <template x-if="error">
          <div class="p-4 mb-4 bg-red-50 border border-red-200 rounded-lg">
            <div class="flex items-center gap-2 text-red-700 text-sm">
              <i class="bi bi-exclamation-triangle"></i>
              <span x-text="error"></span>
            </div>
          </div>
        </template>

        <template x-if="!cargando && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-arrow-return-left text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-4">No hay devoluciones</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Nueva devoluci\u00f3n
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="overflow-x-auto rounded-lg border border-gray-200">
            <table class="w-full text-sm">
              <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Folio venta</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Motivo</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Art\u00edculos</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Reembolso</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Estado</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Fecha</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Acciones</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-100">
                <template x-for="(item, idx) in items" :key="item.id">
                  <tr class="hover:bg-gray-50 transition-colors" :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'">
                    <td class="px-4 py-3 font-medium text-gray-900" x-text="'#' + item.folioVenta"></td>
                    <td class="px-4 py-3 text-gray-600 max-w-[200px] truncate" x-text="item.motivo"></td>
                    <td class="px-4 py-3 text-right text-gray-900" x-text="(item.items || []).length"></td>
                    <td class="px-4 py-3 text-right font-medium text-gray-900" x-text="formatearMoneda(item.totalReembolso)"></td>
                    <td class="px-4 py-3">
                      <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                            :class="estadoClass(item.estado)"
                            x-text="estadoLabel(item.estado)"></span>
                    </td>
                    <td class="px-4 py-3 text-gray-500" x-text="formatearFecha(item.createdAt)"></td>
                    <td class="px-4 py-3 text-right">
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" @click="eliminar(item)" title="Eliminar">
                        <i class="bi bi-trash"></i>
                      </button>
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
        </template>

        <template x-if="cargando">
          <div class="space-y-3">
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.searchQuery = '';
    this.filtroEstado = '';
    this.cargando = true;
    this.error = null;
  },

  formatearFecha(fecha) {
    if (!fecha) return '';
    try {
      return new Date(fecha).toLocaleDateString('es-MX', {
        year: 'numeric', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit'
      });
    } catch { return fecha; }
  },

  formatearMoneda(valor) {
    if (valor == null || isNaN(valor)) return '$0.00';
    return '$' + Number(valor).toLocaleString('es-MX', {
      minimumFractionDigits: 2, maximumFractionDigits: 2
    });
  },

  estadoClass(estado) {
    if (estado === 'completada') return 'bg-green-100 text-green-700';
    if (estado === 'rechazada') return 'bg-red-100 text-red-700';
    return 'bg-amber-100 text-amber-700';
  },

  estadoLabel(estado) {
    if (estado === 'completada') return 'Completada';
    if (estado === 'rechazada') return 'Rechazada';
    return 'Pendiente';
  },

  esHoy(fecha) {
    const d = new Date(fecha);
    const h = new Date();
    return d.getFullYear() === h.getFullYear() &&
           d.getMonth() === h.getMonth() &&
           d.getDate() === h.getDate();
  },

  async cargarDatos() {
    try {
      this.cargando = true;
      this.error = null;
      const q = this.searchQuery.trim().toLowerCase();
      let datos = await db.devoluciones.orderBy('createdAt').reverse().toArray();
      if (q) datos = datos.filter(i => (i.folioVenta || '').toLowerCase().includes(q));
      if (this.filtroEstado) datos = datos.filter(i => i.estado === this.filtroEstado);
      this.items = datos;
      let hoyCount = 0;
      let hoyMonto = 0;
      let pendientes = 0;
      for (const d of datos) {
        if (this.esHoy(d.createdAt)) {
          hoyCount++;
          hoyMonto += d.totalReembolso || 0;
        }
        if (d.estado === 'pendiente') pendientes++;
      }
      this.kpis = { devolucionesHoy: hoyCount, reembolsadoHoy: hoyMonto, pendientes };
    } catch (e) {
      console.error('Error cargando devoluciones:', e);
      this.error = 'Error al cargar datos';
      UI.toast('Error al cargar datos', 'error');
    } finally {
      this.cargando = false;
    }
  },

  async abrirForm() {
    let ventasHoy = [];
    try {
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0);
      const hoyStr = hoy.toISOString();
      const manana = new Date(hoy);
      manana.setDate(manana.getDate() + 1);
      const mananaStr = manana.toISOString();
      ventasHoy = await db.ventas
        .where('createdAt')
        .between(hoyStr, mananaStr)
        .toArray();
    } catch (e) {
      ventasHoy = [];
    }
    const ventasOptions = ventasHoy.map(v =>
      '<option value="' + v.id + '">#' + (v.folio || '') + ' — ' + this.formatearMoneda(v.total) + '</option>'
    ).join('');

    const html = `
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Venta <span class="text-red-500">*</span></label>
          <select x-model="form.ventaId" @change="form.items = []; form.totalReembolso = 0"
                  class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                  :class="errors.ventaId ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500'">
            <option value="">Seleccionar venta...</option>
            ${ventasOptions}
          </select>
          <template x-if="errors.ventaId">
            <p class="mt-1 text-sm text-red-500" x-text="errors.ventaId"></p>
          </template>
        </div>
        <template x-if="form.ventaId">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Productos a devolver</label>
            <div class="space-y-2 max-h-48 overflow-y-auto border border-gray-200 rounded-lg p-3">
              <template x-for="(prod, i) in ventaItems" :key="prod.id">
                <label class="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" :value="prod.id" x-model="form.productosSeleccionados"
                         class="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500" />
                  <span class="flex-1 text-sm text-gray-700" x-text="prod.nombre + ' (x' + prod.cantidad + ')'"></span>
                  <span class="text-sm font-medium text-gray-900" x-text="formatearMoneda(prod.subtotal)"></span>
                </label>
              </template>
            </div>
          </div>
        </template>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Motivo <span class="text-red-500">*</span></label>
          <select x-model="form.motivo"
                  class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                  :class="errors.motivo ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500'">
            <option value="">Seleccionar motivo...</option>
            <option value="Producto defectuoso">Producto defectuoso</option>
            <option value="Cliente insatisfecho">Cliente insatisfecho</option>
            <option value="Error en venta">Error en venta</option>
            <option value="Producto equivocado">Producto equivocado</option>
            <option value="Cambio de producto">Cambio de producto</option>
            <option value="Otro">Otro</option>
          </select>
          <template x-if="errors.motivo">
            <p class="mt-1 text-sm text-red-500" x-text="errors.motivo"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Total reembolso <span class="text-red-500">*</span></label>
          <input type="number" step="0.01" min="0" x-model="form.totalReembolso"
                 class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                 :class="errors.totalReembolso ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500'" />
          <template x-if="errors.totalReembolso">
            <p class="mt-1 text-sm text-red-500" x-text="errors.totalReembolso"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Comentarios</label>
          <textarea x-model="form.comentarios" rows="2"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"></textarea>
        </div>
      </div>`;
    await UI.modalForm(
      'Nueva devoluci\u00f3n',
      html,
      async (data) => {
        await this.guardar(data, ventasHoy);
        await this.cargarDatos();
      },
      { ventaId: '', productosSeleccionados: [], items: [], motivo: '', totalReembolso: 0, comentarios: '' }
    );
  },

  validarForm(datos) {
    this.errors = {};
    if (!datos.ventaId) this.errors.ventaId = 'Selecciona una venta';
    if (!datos.motivo) this.errors.motivo = 'Selecciona un motivo';
    if (!datos.totalReembolso || Number(datos.totalReembolso) <= 0) {
      this.errors.totalReembolso = 'Ingresa un monto v\u00e1lido';
    }
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos, ventas) {
    if (!this.validarForm(datos)) return;
    const venta = ventas.find(v => v.id === datos.ventaId);
    if (!venta) {
      UI.toast('Venta no encontrada', 'error');
      return;
    }
    const itemsDevueltos = (venta.items || []).filter(i => (datos.productosSeleccionados || []).includes(i.id));
    try {
      for (const item of itemsDevueltos) {
        const prod = await db.productos.get(item.id);
        if (prod) {
          prod.stock = (prod.stock || 0) + item.cantidad;
          prod.updatedAt = new Date().toISOString();
          await db.productos.put(prod);
        }
      }
      const devolucion = {
        id: uuid(),
        folioVenta: venta.folio || '',
        ventaId: datos.ventaId,
        items: itemsDevueltos,
        totalReembolso: parseFloat(datos.totalReembolso) || 0,
        motivo: datos.motivo,
        comentarios: datos.comentarios?.trim() || '',
        estado: 'completada',
        procesadoPor: APP_CONFIG?.usuarioActual || 'anon',
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      await db.devoluciones.put(devolucion);
      UI.toast('Devoluci\u00f3n procesada exitosamente', 'success');
    } catch (e) {
      console.error('Error al guardar devoluci\u00f3n:', e);
      UI.toast('Error al procesar devoluci\u00f3n: ' + e.message, 'error');
    }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar devoluci\u00f3n de #' + (item.folioVenta || '') + '?');
    if (!ok) return;
    try {
      await db.devoluciones.delete(item.id);
      UI.toast('Devoluci\u00f3n eliminada', 'success');
      await this.cargarDatos();
    } catch (e) {
      console.error('Error al eliminar:', e);
      UI.toast(e.message, 'error');
    }
  },

  async buscar() {
    await this.cargarDatos();
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['pos-devoluciones'] = ModuloPOSDevoluciones;

document.addEventListener('alpine:init', () => {
  Alpine.data('posDevolucionesData', () => ModuloPOSDevoluciones);
});
