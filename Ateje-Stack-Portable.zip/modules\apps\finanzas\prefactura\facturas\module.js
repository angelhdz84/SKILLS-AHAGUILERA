const ModuloPFFacturas = {
  id: 'pf-facturas',
  titulo: 'Facturas',
  icono: 'bi bi-file-earmark-text',

  tab: 'crear',
  items: [],
  clientes: [],
  productos: [],
  loading: true,
  form: {},
  lineas: [],
  editandoFactura: null,

  async init() {
    const [facturas, clientes, productos] = await Promise.all([
      db.facturas.orderBy('createdAt').reverse().toArray(),
      db.clientes_fiscales.orderBy('nombre').toArray(),
      db.productos_fiscales.orderBy('nombre').toArray()
    ]);
    this.items = facturas;
    this.clientes = clientes;
    this.productos = productos;
    this.loading = false;
    if (this.tab === 'crear') this.nueva();
  },

  render() {
    return `
      <div x-data="pfFacturasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-sky-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-file-earmark-text text-sky-600"></i> Facturas
          </h2>
        </div>

        <div class="flex gap-1 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'crear' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'crear'; nueva()"><i class="bi bi-plus-circle"></i> Crear</button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'historial' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'historial'; cargarHistorial()"><i class="bi bi-clock-history"></i> Historial</button>
        </div>

        <template x-if="tab === 'crear'">
          <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 space-y-4">
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Cliente</h3>
                <select x-model="form.clienteId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow bg-white">
                  <option value="">Seleccionar cliente...</option>
                  <template x-for="c in clientes" :key="c.id"><option :value="c.id" x-text="c.nombre + ' (' + c.rfc + ')'"></option></template>
                </select>
              </div>

              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Conceptos</h3>
                <template x-if="lineas.length === 0">
                  <p class="text-gray-400 text-sm py-4 text-center">Agrega productos o servicios a la factura</p>
                </template>
                <template x-for="(l, i) in lineas" :key="i">
                  <div class="flex items-center gap-2 mb-2 p-2 bg-gray-50 rounded-lg">
                    <div class="flex-1 min-w-0">
                      <p class="text-sm font-medium text-gray-900 truncate" x-text="l.nombre"></p>
                      <p class="text-xs text-gray-500" x-text="l.cantidad + ' x $' + Number(l.precioUnitario).toLocaleString('es-MX')"></p>
                    </div>
                    <span class="text-sm font-bold text-gray-900 shrink-0" x-text="'$' + Number(l.importe).toLocaleString('es-MX')"></span>
                    <button class="text-gray-300 hover:text-red-500 transition-colors p-1" @click="lineas.splice(i, 1); calcularTotales()"><i class="bi bi-x-lg"></i></button>
                  </div>
                </template>
                <button class="inline-flex items-center gap-1 text-sm text-sky-600 hover:text-sky-700 font-medium mt-2" @click="agregarLinea()">
                  <i class="bi bi-plus-circle"></i> Agregar concepto
                </button>
              </div>
            </div>

            <div class="space-y-4">
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Resumen</h3>
                <div class="space-y-2">
                  <div class="flex justify-between text-sm"><span class="text-gray-500">Subtotal</span><span class="font-mono" x-text="'$' + Number(form.subtotal || 0).toLocaleString('es-MX')"></span></div>
                  <div class="flex justify-between text-sm"><span class="text-gray-500">IVA</span><span class="font-mono" x-text="'$' + Number(form.iva || 0).toLocaleString('es-MX')"></span></div>
                  <div class="border-t border-gray-200 pt-2 flex justify-between font-bold"><span>Total</span><span class="text-sky-600 font-mono" x-text="'$' + Number(form.total || 0).toLocaleString('es-MX')"></span></div>
                </div>
                <div class="mt-4 flex gap-2">
                  <button class="flex-1 px-4 py-2 bg-sky-600 text-white text-sm font-medium rounded-lg hover:bg-sky-700 transition-colors shadow-sm disabled:opacity-50" :disabled="!form.clienteId || lineas.length === 0" @click="guardarFactura()">
                    <i class="bi bi-save"></i> Emitir
                  </button>
                  <button class="px-4 py-2 border border-gray-300 text-gray-600 text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors" @click="nueva()">
                    <i class="bi bi-arrow-counterclockwise"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </template>

        <template x-if="tab === 'historial'">
          <div>
            <template x-if="loading">
              <div class="space-y-3"><template x-for="i in 5" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-4 w-48 bg-gray-200 rounded animate-pulse"></div></div></template></div>
            </template>
            <template x-if="!loading && items.length === 0">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-file-earmark-text text-6xl mb-4"></i><p class="text-lg text-gray-500">Sin facturas emitidas</p></div>
            </template>
            <template x-if="items.length > 0">
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <template x-for="f in items" :key="f.id">
                  <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow cursor-pointer" @click="verDetalle(f)">
                    <div class="flex items-center justify-between mb-2">
                      <span class="text-sm font-mono font-bold text-sky-600" x-text="f.folio || 'S/F'"></span>
                      <span class="text-xs text-gray-400" x-text="formatearFecha(f.createdAt)"></span>
                    </div>
                    <p class="text-sm font-medium text-gray-900 truncate" x-text="nombreCliente(f.clienteId)"></p>
                    <div class="flex items-center justify-between mt-2">
                      <span class="text-sm font-bold text-gray-900" x-text="'$' + Number(f.total || 0).toLocaleString('es-MX')"></span>
                      <button class="text-xs text-sky-600 hover:text-sky-700 font-medium" @click.stop="descargarXML(f)">XML</button>
                    </div>
                  </div>
                </template>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() { this.tab = 'crear'; this.items = []; this.clientes = []; this.productos = []; this.lineas = []; this.editandoFactura = null; this.loading = true; },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return f; } },
  nombreCliente(id) { const c = this.clientes.find(x => x.id === id); return c ? c.nombre : '\u2014'; },

  nueva() {
    this.editandoFactura = null;
    this.form = { clienteId: '', subtotal: 0, iva: 0, total: 0, serie: 'F' };
    this.lineas = [];
  },

  agregarLinea() {
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Producto / Servicio</label>',
      '<select x-model="form.productoId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow bg-white">',
      '<option value="">Seleccionar...</option>',
      '<template x-for="p in productos" :key="p.id"><option :value="p.id" x-text="p.nombre + \' ($\' + Number(p.precioUnitario).toLocaleString() + \')\'"></option></template>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Cantidad</label>',
      '<input type="number" min="1" x-model="form.cantidad" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" /></div>',
      '</div>'
    ].join('\n');
    UI.modalForm('Agregar concepto', html, async (data) => {
      if (!data.productoId) { UI.toast('Selecciona un producto', 'error'); return; }
      const p = this.productos.find(x => x.id === data.productoId);
      if (!p) return;
      const cant = parseInt(data.cantidad) || 1;
      this.lineas.push({ productoId: p.id, nombre: p.nombre, cantidad: cant, precioUnitario: p.precioUnitario, iva: p.iva, importe: cant * p.precioUnitario });
      this.calcularTotales();
    }, { productoId: '', cantidad: 1 });
  },

  calcularTotales() {
    let sub = 0, iva = 0;
    for (const l of this.lineas) {
      sub += l.importe;
      if (l.iva > 0) iva += l.importe * l.iva;
    }
    this.form.subtotal = Math.round(sub * 100) / 100;
    this.form.iva = Math.round(iva * 100) / 100;
    this.form.total = Math.round((sub + iva) * 100) / 100;
  },

  async guardarFactura() {
    try {
      const todas = await db.facturas.toArray();
      const nums = todas.map(f => parseInt((f.folio || 'F-0').replace(/^F-/, ''))).filter(n => !isNaN(n));
      const sig = nums.length > 0 ? Math.max(...nums) + 1 : 1;
      const folio = 'F-' + String(sig).padStart(3, '0');
      const factura = {
        id: window.uuid(), folio, serie: 'F', clienteId: this.form.clienteId,
        subtotal: this.form.subtotal, iva: this.form.iva, total: this.form.total,
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      };
      await db.facturas.put(factura);
      for (const l of this.lineas) {
        await db.facturas_items.put({
          id: window.uuid(), facturaId: factura.id, productoId: l.productoId,
          cantidad: l.cantidad, precioUnitario: l.precioUnitario, importe: l.importe
        });
      }
      const cliente = this.clientes.find(c => c.id === this.form.clienteId);
      const xml = this.generarXML(factura, this.lineas, cliente);
      const blob = new Blob([xml], { type: 'application/xml;charset=utf-8' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = folio + '.xml';
      link.click();
      URL.revokeObjectURL(link.href);
      UI.toast('Factura ' + folio + ' emitida', 'success');
      this.nueva();
      this.items.unshift(factura);
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  generarXML(factura, lineas, cliente) {
    const hoy = new Date().toISOString().slice(0, 10);
    const rfc = cliente?.rfc || 'XAXX010101000';
    const nom = cliente?.nombre || 'P\u00fablico en General';
    let conceptos = '';
    for (const l of lineas) {
      conceptos += '    <Concepto ClaveProdServ="' + (l.clave?.padStart(8, '0') || '01010101') + '" NoIdentificacion="" Cantidad="' + l.cantidad + '" ClaveUnidad="H87" Unidad="Pieza" Descripcion="' + l.nombre.replace(/"/g, '&quot;') + '" ValorUnitario="' + l.precioUnitario.toFixed(2) + '" Importe="' + l.importe.toFixed(2) + '" ObjetoImp="02">\n      <Impuestos>\n        <Traslados>\n          <Traslado Base="' + l.importe.toFixed(2) + '" Impuesto="002" TipoFactor="Tasa" TasaOCuota="' + ((l.iva || 0.16) * 100).toFixed(2) + '" Importe="' + (l.importe * (l.iva || 0.16)).toFixed(2) + '" />\n        </Traslados>\n      </Impuestos>\n    </Concepto>\n';
    }
    return '<?xml version="1.0" encoding="utf-8"?>\n<cfdi:Comprobante xmlns:cfdi="http://www.sat.gob.mx/cfd/4" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" Version="4.0" Serie="' + factura.serie + '" Folio="' + factura.folio + '" Fecha="' + hoy + '" SubTotal="' + factura.subtotal.toFixed(2) + '" Total="' + factura.total.toFixed(2) + '" Moneda="MXN" TipoDeComprobante="I" Exportacion="01" LugarExpedicion="00000" xsi:schemaLocation="http://www.sat.gob.mx/cfd/4 http://www.sat.gob.mx/sitio_internet/cfd/4/cfdv40.xsd">\n  <cfdi:Emisor Rfc="AAAA010101AAA" Nombre="MI EMPRESA" RegimenFiscal="601" />\n  <cfdi:Receptor Rfc="' + rfc + '" Nombre="' + nom.replace(/"/g, '&quot;') + '" DomicilioFiscalReceptor="00000" RegimenFiscalReceptor="612" UsoCFDI="G03" />\n  <cfdi:Conceptos>\n' + conceptos + '  </cfdi:Conceptos>\n  <cfdi:Impuestos TotalImpuestosTrasladados="' + factura.iva.toFixed(2) + '">\n    <cfdi:Traslados>\n      <cfdi:Traslado Base="' + factura.subtotal.toFixed(2) + '" Impuesto="002" TipoFactor="Tasa" TasaOCuota="0.160000" Importe="' + factura.iva.toFixed(2) + '" />\n    </cfdi:Traslados>\n  </cfdi:Impuestos>\n</cfdi:Comprobante>\n';
  },

  async cargarHistorial() {
    try {
      this.loading = true;
      this.items = await db.facturas.orderBy('createdAt').reverse().toArray();
    } catch (e) { console.error(e); }
    finally { this.loading = false; }
  },

  async verDetalle(f) {
    const cliente = this.clientes.find(c => c.id === f.clienteId);
    const items = await db.facturas_items.where('facturaId').equals(f.id).toArray();
    const html = [
      '<div class="space-y-3">',
      '<div class="flex justify-between"><span class="text-sm font-mono font-bold text-sky-600" x-text="\'Folio \' + folio"></span><span class="text-xs text-gray-400" x-text="fecha"></span></div>',
      '<p class="text-sm" x-text="cliente"></p>',
      '<div class="border-t border-gray-200 pt-2"><template x-for="l in lineas"><div class="flex justify-between text-sm py-0.5"><span x-text="l.cantidad + \'x \' + l.nombre"></span><span class="font-mono" x-text="\'$\' + Number(l.importe).toLocaleString()"></span></div></template></div>',
      '<div class="border-t border-gray-200 pt-2 space-y-1">',
      '<div class="flex justify-between text-sm"><span>Subtotal</span><span class="font-mono" x-text="\'$\' + Number(sub).toLocaleString()"></span></div>',
      '<div class="flex justify-between text-sm"><span>IVA</span><span class="font-mono" x-text="\'$\' + Number(iv).toLocaleString()"></span></div>',
      '<div class="flex justify-between font-bold text-sky-600"><span>Total</span><span class="font-mono" x-text="\'$\' + Number(tot).toLocaleString()"></span></div>',
      '</div></div>'
    ].join('\n');
    const total = (this.formatearFecha(f.createdAt));
    UI.modalHtml('Factura ' + f.folio, html.replace('folio', f.folio).replace('fecha', total)
      .replace('cliente', cliente?.nombre || '\u2014')
      .replace('lineas', JSON.stringify(items.map(i => ({ nombre: this.productos.find(p => p.id === i.productoId)?.nombre || i.productoId, cantidad: i.cantidad, importe: i.importe }))))
      .replace('sub', f.subtotal || 0).replace('iv', f.iva || 0).replace('tot', f.total || 0));
  },

  async descargarXML(f) {
    try {
      const items = await db.facturas_items.where('facturaId').equals(f.id).toArray();
      const cliente = this.clientes.find(c => c.id === f.clienteId);
      const prods = this.productos;
      const lineas = items.map(i => ({ ...i, nombre: prods.find(p => p.id === i.productoId)?.nombre || i.productoId, clave: prods.find(p => p.id === i.productoId)?.clave || '', iva: prods.find(p => p.id === i.productoId)?.iva || 0.16 }));
      const xml = this.generarXML(f, lineas, cliente);
      const blob = new Blob([xml], { type: 'application/xml;charset=utf-8' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = (f.folio || 'factura') + '.xml';
      link.click();
      URL.revokeObjectURL(link.href);
      UI.toast('XML descargado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['pf-facturas'] = ModuloPFFacturas;

document.addEventListener('alpine:init', () => {
  Alpine.data('pfFacturasData', () => ModuloPFFacturas);
});
