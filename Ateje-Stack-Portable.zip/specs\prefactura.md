# AHA PreFactura — Spec Técnica

## Identidad
- **App:** AHA PreFactura
- **Perfil:** Lite
- **Target:** Freelancers, profesionistas independientes, pequeños negocios
- **Tagline:** Prefacturación offline para freelancers
- **Color primario:** #0891b2 (cyan-600)
- **Descripción:** Genera facturas con folio automático, exporta PDF, control de clientes con RFC.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  clientes_fiscales: 'id, nombre, *rfc, *regimen, direccion, email, *telefono, createdAt, updatedAt',
  productos_fiscales: 'id, *clave, nombre, precioUnitario, *iva, *categoria, createdAt, updatedAt',
  facturas: 'id, *folio, *serie, *clienteId, subtotal, iva, total, *createdBy, createdAt, updatedAt',
  facturas_items: 'id, *facturaId, *productoId, cantidad, precioUnitario, importe',
  _sync_log, _ia_chats, _ia_messages
});
```

## Entry point
`core/main.js`

## Módulos (5)

### clientes_fiscales
- CRUD: nombre/razón social, RFC, régimen fiscal, dirección, email, teléfono
- Búsqueda instantánea por nombre o RFC
- Validación básica de RFC (formato)

### productos_fiscales
- CRUD: clave, nombre, precio unitario, IVA aplicable (sí/no)
- Clasificación por categoría fiscal
- Búsqueda por clave o nombre

### facturas
- Crear factura: seleccionar cliente + agregar productos (items)
- Folio automático serie F-001, F-002...
- Cálculo: subtotal, IVA, total
- Generación PDF con formato fiscal
- Modal multi-paso (cliente → items → resumen)

### historial
- Lista facturas emitidas con filtros por fecha, cliente, folio
- Vista detalle: ver PDF, descargar XML, reimprimir

### reportes
- Dashboard: total facturado mes, facturas emitidas, clientes registrados
- Gráfico ingresos por mes (Chart.js barras)
- Export CSV

## Estructura
```
aha-prefactura/
├── index.html, manifest.json, sw.js, project.config.js, .gitignore, README.md
├── core/ (main, app, db, crypto, theme, ui, env, network, sync, seed, search-palette, file-store, license)
├── modules/
│   ├── clientes_fiscales/module.html + module.js
│   ├── productos_fiscales/module.html + module.js
│   ├── facturas/module.html + module.js
│   ├── historial/module.html + module.js
│   └── reportes/module.html + module.js
├── assets/
└── data/
```

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema cyan (primary: #0891b2)
- Chart.js para gráficos
- ES5 estricto
