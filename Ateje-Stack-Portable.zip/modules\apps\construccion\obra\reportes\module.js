﻿const ModuloObraReportes = {
  id: 'obra-reportes',
  titulo: 'Reportes',
  icono: 'bi bi-file-earmark-bar-graph',
  items: [],
  loading: true,
  obraSeleccionada: null,
  obras: [],
  reportes: [],

  async init() {
    await this.cargarObras();
    await this.generar();
  },

  async cargarObras() {
    try {
      this.obras = await db.obras.toArray();
    } catch (e) {
      this.obras = [];
    }
  },

  async generar() {
    this.loading = true;
    try {
      let obras = this.obras;
      if (this.obraSeleccionada) {
        obras = obras.filter(o => o.id === this.obraSeleccionada);
      }
      const reportes = [];
      for (const obra of obras) {
        const etapas = await db.etapas.where('obraId').equals(obra.id).toArray();
        const materiales = await db.materiales.where('obraId').equals(obra.id).toArray();
        const gastos = await db.gastos_obra.where('obraId').equals(obra.id).toArray();
        const totalGastos = gastos.reduce((s, g) => s + (Number(g.monto) || 0), 0);
        const totalMateriales = materiales.reduce((s, m) => s + ((Number(m.cantidad) || 0) * (Number(m.precioUnitario) || 0)), 0);
        const presupuesto = Number(obra.presupuestoTotal) || 0;
        const ejercido = totalGastos + totalMateriales;
        const avancePromedio = etapas.length > 0
          ? Math.round(etapas.reduce((s, e) => s + (Number(e.avance) || 0), 0) / etapas.length)
          : 0;
        const completadas = etapas.filter(e => e.estado === 'completada').length;
        reportes.push({
          obraId: obra.id,
          obraNombre: obra.nombre,
          obraDireccion: obra.direccion,
          obraTipo: obra.tipo,
          obraEstado: obra.estado,
          presupuesto,
          ejercido,
          saldo: presupuesto - ejercido,
          totalEtapas: etapas.length,
          etapasCompletadas: completadas,
          avance: avancePromedio,
          totalMateriales,
          totalGastos,
          gastosPorCategoria: this.agruparCategorias(gastos)
        });
      }
      this.reportes = reportes;
      this.items = [];
    } catch (e) {
      console.error('Error generando reportes:', e);
    } finally {
      this.loading = false;
    }
  },

  agruparCategorias(gastos) {
    const grupos = {};
    const labels = { mano_obra: 'Mano de obra', subcontrato: 'Subcontrato', viaticos: 'Viáticos', equipo: 'Equipo', transporte: 'Transporte', alimentacion: 'Alimentación', otro: 'Otro' };
    gastos.forEach(g => {
      const cat = g.categoria || 'otro';
      grupos[cat] = grupos[cat] || { label: labels[cat] || cat, total: 0, count: 0 };
      grupos[cat].total += Number(g.monto) || 0;
      grupos[cat].count++;
    });
    return Object.entries(grupos).map(([k, v]) => ({ categoria: k, ...v }));
  },

  render() {
    if (this.loading) return this.renderSkeleton();
    const totalPresupuesto = this.reportes.reduce((s, r) => s + r.presupuesto, 0);
    const totalEjercido = this.reportes.reduce((s, r) => s + r.ejercido, 0);
    return \
      <div class="space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <h2 class="text-2xl font-bold flex items-center gap-2">
            <i class="bi bi-file-earmark-bar-graph text-blue-500"></i> Reportes
          </h2>
          <div class="flex gap-2">
            <select x-model="obraReportesData.obraSeleccionada" @change="obraReportesData.generar()" class="select select-bordered select-sm">
              <option value="">Todas las obras</option>
              <template x-for="obra in obraReportesData.obras" :key="obra.id">
                <option :value="obra.id" x-text="obra.nombre"></option>
              </template>
            </select>
            <button @click="obraReportesData.exportar()" class="btn btn-primary btn-sm gap-1">
              <i class="bi bi-download"></i> Exportar
            </button>
          </div>
        </div>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div class="stat bg-base-100 rounded-2xl shadow-sm border border-base-200 p-4">
            <div class="stat-figure text-blue-500"><i class="bi bi-cash-coin text-2xl"></i></div>
            <div class="stat-title text-xs">Presupuesto Total</div>
            <div class="stat-value text-2xl font-bold" x-text="obraReportesData.fmt(obraReportesData.reportes.reduce((s,r) => s + r.presupuesto, 0))"></div>
          </div>
          <div class="stat bg-base-100 rounded-2xl shadow-sm border border-base-200 p-4">
            <div class="stat-figure text-warning"><i class="bi bi-cart-check text-2xl"></i></div>
            <div class="stat-title text-xs">Total Ejercido</div>
            <div class="stat-value text-2xl font-bold text-warning" x-text="obraReportesData.fmt(obraReportesData.reportes.reduce((s,r) => s + r.ejercido, 0))"></div>
          </div>
          <div class="stat bg-base-100 rounded-2xl shadow-sm border border-base-200 p-4">
            <div class="stat-figure text-success"><i class="bi bi-piggy-bank text-2xl"></i></div>
            <div class="stat-title text-xs">Saldo Disponible</div>
            <div class="stat-value text-2xl font-bold text-success" x-text="obraReportesData.fmt(obraReportesData.reportes.reduce((s,r) => s + r.saldo, 0))"></div>
          </div>
          <div class="stat bg-base-100 rounded-2xl shadow-sm border border-base-200 p-4">
            <div class="stat-figure text-info"><i class="bi bi-check2-circle text-2xl"></i></div>
            <div class="stat-title text-xs">Etapas Completadas</div>
            <div class="stat-value text-2xl font-bold" x-text="obraReportesData.reportes.reduce((s,r) => s + r.etapasCompletadas, 0) + '/' + obraReportesData.reportes.reduce((s,r) => s + r.totalEtapas, 0)"></div>
          </div>
        </div>
        <div x-show="obraReportesData.reportes.length === 0" class="empty-state">
          <div class="empty-state-icon bg-blue-50"><i class="bi bi-file-earmark-bar-graph text-blue-400"></i></div>
          <div class="empty-state-title">Sin datos</div>
          <div class="empty-state-desc">No hay obras registradas para generar reportes</div>
        </div>
        <template x-for="(rpt, idx) in obraReportesData.reportes" :key="rpt.obraId">
          <div class="bg-base-100 rounded-2xl shadow-sm border border-base-200 p-5 stagger-item" :style="'animation-delay: ' + (idx * 0.08) + 's'">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
              <div>
                <h3 class="font-bold text-lg" x-text="rpt.obraNombre"></h3>
                <p class="text-sm text-base-content/50" x-text="rpt.obraDireccion || rpt.obraTipo || ''"></p>
              </div>
              <span :class="'badge ' + (rpt.obraEstado === 'activa' || rpt.obraEstado === 'en_progreso' ? 'badge-success' : rpt.obraEstado === 'completada' ? 'badge-info' : 'badge-ghost')" x-text="rpt.obraEstado || 'sin estado'"></span>
            </div>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
              <div><span class="text-xs text-base-content/50 block">Presupuesto</span><span class="font-semibold" x-text="obraReportesData.fmt(rpt.presupuesto)"></span></div>
              <div><span class="text-xs text-base-content/50 block">Ejercido</span><span class="font-semibold" x-text="obraReportesData.fmt(rpt.ejercido)"></span></div>
              <div><span class="text-xs text-base-content/50 block">Saldo</span><span :class="'font-semibold ' + (rpt.saldo < 0 ? 'text-error' : 'text-success')" x-text="obraReportesData.fmt(rpt.saldo)"></span></div>
              <div><span class="text-xs text-base-content/50 block">Avance</span><span class="font-semibold" x-text="rpt.avance + '%'"></span></div>
            </div>
            <div class="mb-3">
              <div class="flex justify-between text-xs mb-1">
                <span>Avance general</span>
                <span x-text="rpt.avance + '%'"></span>
              </div>
              <progress class="progress progress-primary w-full" :value="rpt.avance" max="100"></progress>
            </div>
            <div class="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span class="text-base-content/50 text-xs block">Materiales</span>
                <span x-text="obraReportesData.fmt(rpt.totalMateriales)"></span>
              </div>
              <div>
                <span class="text-base-content/50 text-xs block">Gastos</span>
                <span x-text="obraReportesData.fmt(rpt.totalGastos)"></span>
              </div>
            </div>
            <template x-if="rpt.gastosPorCategoria.length > 0">
              <div class="mt-3 pt-3 border-t border-base-200">
                <span class="text-xs text-base-content/50 block mb-1">Gastos por categoría</span>
                <div class="flex flex-wrap gap-1">
                  <template x-for="g in rpt.gastosPorCategoria" :key="g.categoria">
                    <span class="badge badge-sm badge-outline" x-text="g.label + ': ' + obraReportesData.fmt(g.total)"></span>
                  </template>
                </div>
              </div>
            </template>
          </div>
        </template>
      </div>
    \;
  },

  renderSkeleton() {
    return \
      <div class="space-y-6">
        <div class="sk-heading w-32"></div>
        <div class="grid grid-cols-4 gap-4">\</div>
        \
      </div>
    \;
  },

  fmt(n) {
    const v = Number(n) || 0;
    return '$' + v.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  async exportar() {
    if (this.reportes.length === 0) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const csv = ['Obra,Presupuesto,Ejercido,Saldo,Etapas,Completadas,Avance,Materiales,Gastos'];
      this.reportes.forEach(r => {
        csv.push(\"\","\","\","\","\","\","\","\","\","\"\);
      });
      const blob = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'reporte-obras-' + new Date().toISOString().slice(0, 10) + '.csv';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);
      UI.toast('Reporte exportado', 'success');
    } catch (e) {
      UI.toast('Error al exportar: ' + e.message, 'error');
    }
  },

  destroy() {
    this.items = [];
    this.loading = true;
    this.reportes = [];
    this.obraSeleccionada = null;
  }
};

window.MODULES = window.MODULES || {};
window.MODULES[ModuloObraReportes.id] = ModuloObraReportes;

document.addEventListener('alpine:init', () => {
  Alpine.data('obraReportesData', () => ModuloObraReportes);
});
