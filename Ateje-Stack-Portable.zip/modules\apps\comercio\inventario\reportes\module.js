﻿const ModuloInvReportes = {
  id: 'inv-reportes',
  titulo: 'Reportes',
  icono: 'bi bi-graph-up',

  loading: true,
  resumen: { total: 0, bajoStock: 0, sinStock: 0, valorStock: 0, movSemana: 0, top: [] },
  productos: [],
  movimientos: [],
  categorias: [],
  chartInstance: null,

  async init() {
    await this.cargarDatos();
    this.$nextTick(() => {
      const el = this.$el?.querySelector('#chartReportes');
      if (el) this.renderChart(el);
    });
  },

  render() {
    return `
      <div x-data="invReportesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-emerald-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-graph-up text-emerald-600"></i> Reportes
          </h2>
        </div>

        <template x-if="loading">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <template x-for="i in 4" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-3 w-16 bg-gray-200 rounded animate-pulse mb-2"></div><div class="h-7 w-24 bg-gray-200 rounded animate-pulse"></div></div>
            </template>
          </div>
        </template>

        <template x-if="!loading">
          <div>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Productos</p><p class="text-2xl font-bold text-gray-900" x-text="resumen.total"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Valor en stock</p><p class="text-2xl font-bold text-emerald-600" x-text="formatearMoneda(resumen.valorStock)"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Stock bajo</p><p class="text-2xl font-bold text-amber-600" x-text="resumen.bajoStock"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Mov. esta semana</p><p class="text-2xl font-bold text-blue-600" x-text="resumen.movSemana"></p></div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm flex items-center gap-2"><i class="bi bi-bar-chart text-emerald-600"></i> Movimientos por tipo</h3>
                <canvas id="chartReportes" class="max-h-64"></canvas>
              </div>
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm flex items-center gap-2"><i class="bi bi-trophy text-amber-600"></i> Top productos con m\u00e1s valor</h3>
                <template x-if="resumen.top.length === 0">
                  <p class="text-gray-400 text-sm py-8 text-center">Sin productos</p>
                </template>
                <template x-if="resumen.top.length > 0">
                  <div class="space-y-2">
                    <template x-for="(p, i) in resumen.top" :key="p.id">
                      <div class="flex items-center justify-between">
                        <div class="flex items-center gap-2 min-w-0">
                          <span class="text-xs font-bold text-gray-400 w-5 shrink-0" x-text="'#' + (i+1)"></span>
                          <span class="text-sm text-gray-900 truncate" x-text="p.nombre"></span>
                        </div>
                        <span class="text-sm font-bold text-emerald-600 shrink-0" x-text="formatearMoneda(p.valor)"></span>
                      </div>
                    </template>
                  </div>
                </template>
              </div>
            </div>

            <div class="flex gap-2">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors shadow-sm" @click="exportarCSV">
                <i class="bi bi-download"></i> Exportar CSV
              </button>
              <button class="inline-flex items-center gap-1.5 px-4 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors" @click="recalcular">
                <i class="bi bi-arrow-clockwise"></i> Recalcular
              </button>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.loading = true; this.resumen = { total: 0, bajoStock: 0, sinStock: 0, valorStock: 0, movSemana: 0, top: [] };
    this.productos = []; this.movimientos = []; this.categorias = [];
    if (this.chartInstance) { this.chartInstance.destroy(); this.chartInstance = null; }
  },

  formatearMoneda(v) { if (v == null || isNaN(v)) return '$0.00'; return '$' + Number(v).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); },

  async cargarDatos() {
    try {
      this.loading = true;
      const [prods, movs, cats] = await Promise.all([
        db.productos.toArray(),
        db.movimientos.toArray(),
        db.categorias.toArray()
      ]);
      this.productos = prods;
      this.movimientos = movs;
      this.categorias = cats;

      const total = prods.length;
      let bajoStock = 0, sinStock = 0, valorStock = 0;
      for (const p of prods) {
        const c = p.cantidad || 0;
        if (c <= 0) sinStock++; else if (c <= (p.umbralMinimo || 5)) bajoStock++;
        valorStock += c * (p.precio || 0);
      }
      const ahora = new Date();
      const semanaPasada = new Date(ahora.getTime() - 7 * 24 * 60 * 60 * 1000);
      const movSemana = movs.filter(m => new Date(m.createdAt) >= semanaPasada).length;
      const top = prods.filter(p => (p.cantidad || 0) > 0 && (p.precio || 0) > 0)
        .map(p => ({ id: p.id, nombre: p.nombre, valor: (p.cantidad || 0) * (p.precio || 0) }))
        .sort((a, b) => b.valor - a.valor).slice(0, 5);

      this.resumen = { total, bajoStock, sinStock, valorStock, movSemana, top };
    } catch (e) { console.error(e); UI.toast('Error al cargar datos', 'error'); }
    finally { this.loading = false; }
  },

  renderChart(el) {
    if (this.chartInstance) { this.chartInstance.destroy(); }
    const tipos = ['entrada', 'salida', 'ajuste', 'merma', 'transferencia'];
    const labels = ['Entradas', 'Salidas', 'Ajustes', 'Mermas', 'Transferencias'];
    const colores = ['#10b981', '#ef4444', '#3b82f6', '#f59e0b', '#8b5cf6'];
    const datos = tipos.map(t => this.movimientos.filter(m => m.tipo === t).length);
    if (datos.every(d => d === 0)) { datos.fill(1); labels.forEach((_, i) => labels[i] += ' (0)'); }
    try {
      this.chartInstance = new Chart(el, {
        type: 'doughnut',
        data: { labels, datasets: [{ data: datos, backgroundColor: colores, borderWidth: 0 }] },
        options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'bottom', labels: { font: { size: 11 }, boxWidth: 12, padding: 12 } } } }
      });
    } catch (e) { console.error('Chart error:', e); }
  },

  async exportarCSV() {
    try {
      const prods = await db.productos.toArray();
      let csv = '\uFEFFNombre,SKU,Categoria,Precio,Cantidad,Umbral Minimo,Valor\n';
      for (const p of prods) {
        const cat = this.categorias.find(c => c.id === p.categoriaId);
        const nomCat = cat ? cat.nombre : '';
        csv += (p.nombre || '') + ',' + (p.sku || '') + ',' + nomCat + ','
          + (p.precio || 0) + ',' + (p.cantidad || 0) + ',' + (p.umbralMinimo || 5) + ','
          + ((p.cantidad || 0) * (p.precio || 0)) + '\n';
      }
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'inventario_' + new Date().toISOString().slice(0, 10) + '.csv';
      link.click();
      URL.revokeObjectURL(link.href);
      UI.toast('CSV exportado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async recalcular() {
    await this.cargarDatos();
    const el = this.$el?.querySelector('#chartReportes') || document.querySelector('#chartReportes');
    if (el) this.renderChart(el);
    UI.toast('Datos recalculados', 'success');
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['inv-reportes'] = ModuloInvReportes;

document.addEventListener('alpine:init', () => {
  Alpine.data('invReportesData', () => ModuloInvReportes);
});
