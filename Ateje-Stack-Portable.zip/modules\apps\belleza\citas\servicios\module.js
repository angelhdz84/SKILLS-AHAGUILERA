﻿const ModuloCitasServicios = {
  id: 'citas-servicios',
  titulo: 'Servicios',
  icono: 'bi bi-scissors',

  tab: 'servicios',
  items: [],
  profesionales: [],
  categorias: [],
  errors: {},
  searchQuery: '',
  loading: true,
  error: null,
  saving: false,
  kpis: { totalServicios: 0, totalProfesionales: 0, categorias: 0 },

  async init() {
    await Promise.all([this.cargarServicios(), this.cargarProfesionales(), this.cargarCategorias()]);
  },

  render() {
    return `
      <div x-data="citasServiciosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-pink-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-scissors text-pink-600"></i> Servicios
          </h2>
        </div>

        <div class="grid grid-cols-3 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Servicios</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.totalServicios"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Profesionales</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.totalProfesionales"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Categor\u00edas</p>
            <p class="text-2xl font-bold text-green-600" x-text="kpis.categorias"></p>
          </div>
        </div>

        <div class="flex gap-1 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'servicios' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'servicios'">
            <i class="bi bi-scissors"></i> Servicios
          </button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'profesionales' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'profesionales'">
            <i class="bi bi-person-badge"></i> Profesionales
          </button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'categorias' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'categorias'">
            <i class="bi bi-tags"></i> Categor\u00edas
          </button>
        </div>

        <!-- TAB: SERVICIOS -->
        <template x-if="tab === 'servicios'">
          <div>
            <div class="flex flex-wrap gap-2 mb-4">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-pink-600 text-white text-sm font-medium rounded-lg hover:bg-pink-700 transition-colors shadow-sm" @click="abrirFormServicio()">
                <i class="bi bi-plus-lg"></i> Servicio
              </button>
              <div class="relative flex-1 min-w-[200px]">
                <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                <input type="search" x-model="searchQuery" @input.debounce="cargarServicios" placeholder="Buscar servicios..."
                       class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none transition-shadow" />
              </div>
            </div>
            <template x-if="items.length === 0 && !loading">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                <i class="bi bi-scissors text-6xl mb-4"></i>
                <p class="text-lg text-gray-500 mb-2">No hay servicios a\u00fan</p>
                <p class="text-sm text-gray-400 mb-6">Agrega tu primer servicio</p>
                <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-pink-600 text-white text-sm font-medium rounded-lg hover:bg-pink-700 transition-colors" @click="abrirFormServicio()">
                  <i class="bi bi-plus-lg"></i> Agregar primero
                </button>
              </div>
            </template>
            <template x-if="items.length > 0">
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <template x-for="s in items" :key="s.id">
                  <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow cursor-pointer" @click="abrirFormServicio(s)">
                    <div class="flex items-start justify-between mb-2">
                      <h3 class="font-semibold text-gray-900" x-text="s.nombre"></h3>
                      <span class="text-lg font-bold text-pink-600" x-text="formatearMoneda(s.precio)"></span>
                    </div>
                    <div class="flex items-center gap-3 text-xs text-gray-500 mb-2">
                      <span class="inline-flex items-center gap-1"><i class="bi bi-clock"></i> <span x-text="s.duracion || 0 + ' min'"></span></span>
                      <span class="inline-flex items-center gap-1"><i class="bi bi-tag"></i> <span x-text="nombreCategoria(s.categoriaId)"></span></span>
                    </div>
                    <div class="flex flex-wrap gap-1">
                      <template x-for="pId in s.profesionales || []" :key="pId">
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 bg-pink-50 text-pink-700 text-xs rounded-full">
                          <span class="w-1.5 h-1.5 rounded-full bg-pink-500"></span>
                          <span x-text="nombreProfesional(pId)"></span>
                        </span>
                      </template>
                    </div>
                  </div>
                </template>
              </div>
            </template>
          </div>
        </template>

        <!-- TAB: PROFESIONALES -->
        <template x-if="tab === 'profesionales'">
          <div>
            <div class="flex flex-wrap gap-2 mb-4">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition-colors shadow-sm" @click="abrirFormProfesional()">
                <i class="bi bi-plus-lg"></i> Profesional
              </button>
            </div>
            <template x-if="profesionales.length === 0 && !loading">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                <i class="bi bi-person-badge text-6xl mb-4"></i>
                <p class="text-lg text-gray-500 mb-2">No hay profesionales</p>
                <p class="text-sm text-gray-400 mb-6">Agrega un profesional</p>
                <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition-colors" @click="abrirFormProfesional()">
                  <i class="bi bi-plus-lg"></i> Agregar primero
                </button>
              </div>
            </template>
            <template x-if="profesionales.length > 0">
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <template x-for="p in profesionales" :key="p.id">
                  <div class="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-md transition-shadow cursor-pointer" @click="abrirFormProfesional(p)">
                    <div class="h-2" :style="'background:' + (p.color || '#ec4899')"></div>
                    <div class="p-4">
                      <div class="flex items-center gap-3 mb-3">
                        <div class="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0"
                             :style="'background:' + (p.color || '#ec4899')"
                             x-text="(p.nombre || '?').charAt(0).toUpperCase()"></div>
                        <div>
                          <h3 class="font-semibold text-gray-900" x-text="p.nombre"></h3>
                          <p class="text-xs text-gray-400" x-text="p.horarioInicio + ' - ' + p.horarioFin"></p>
                        </div>
                      </div>
                      <div class="flex flex-wrap gap-1">
                        <template x-for="d in p.diasDescanso || []" :key="d">
                          <span class="px-2 py-0.5 bg-red-50 text-red-500 text-xs rounded-full">Sin <span x-text="d"></span></span>
                        </template>
                      </div>
                    </div>
                  </div>
                </template>
              </div>
            </template>
          </div>
        </template>

        <!-- TAB: CATEGORIAS -->
        <template x-if="tab === 'categorias'">
          <div>
            <div class="flex flex-wrap gap-2 mb-4">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors shadow-sm" @click="abrirFormCategoria()">
                <i class="bi bi-plus-lg"></i> Categor\u00eda
              </button>
            </div>
            <template x-if="categorias.length === 0 && !loading">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                <i class="bi bi-tags text-6xl mb-4"></i>
                <p class="text-lg text-gray-500 mb-2">No hay categor\u00edas</p>
                <p class="text-sm text-gray-400 mb-6">Crea categor\u00edas para organizar servicios</p>
                <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors" @click="abrirFormCategoria()">
                  <i class="bi bi-plus-lg"></i> Crear primero
                </button>
              </div>
            </template>
            <template x-if="categorias.length > 0">
              <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div class="overflow-x-auto">
                  <table class="w-full text-sm">
                    <thead>
                      <tr class="border-b border-gray-100 bg-gray-50/50">
                        <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Nombre</th>
                        <th class="text-center px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Servicios</th>
                        <th class="text-right px-4 py-3 w-20"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <template x-for="c in categorias" :key="c.id">
                        <tr class="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                          <td class="px-4 py-3 font-medium text-gray-900" x-text="c.nombre"></td>
                          <td class="px-4 py-3 text-center text-gray-500" x-text="items.filter(s => s.categoriaId === c.id).length"></td>
                          <td class="px-4 py-3 text-right">
                            <button class="text-gray-300 hover:text-red-500 transition-colors p-1" @click.stop="eliminarCategoria(c)">
                              <i class="bi bi-trash"></i>
                            </button>
                          </td>
                        </tr>
                      </template>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>
          </div>
        </template>

        <template x-if="loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="i in 6" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
                <div class="h-5 bg-gray-200 rounded animate-pulse w-2/3"></div>
                <div class="h-4 bg-gray-200 rounded animate-pulse w-1/3"></div>
                <div class="h-4 bg-gray-200 rounded animate-pulse w-1/2"></div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.tab = 'servicios';
    this.items = [];
    this.profesionales = [];
    this.categorias = [];
    this.searchQuery = '';
    this.loading = true;
    this.error = null;
    this.kpis = { totalServicios: 0, totalProfesionales: 0, categorias: 0 };
  },

  formatearMoneda(v) {
    if (v == null || isNaN(v)) return '$0.00';
    return '$' + Number(v).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  formatearFecha(f) {
    if (!f) return '';
    try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); }
    catch { return f; }
  },

  nombreProfesional(id) {
    const p = this.profesionales.find(x => x.id === id);
    return p ? p.nombre : '—';
  },

  nombreCategoria(id) {
    const c = this.categorias.find(x => x.id === id);
    return c ? c.nombre : '—';
  },

  async cargarServicios() {
    try {
      this.loading = true;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.servicios.orderBy('createdAt').reverse().toArray();
      if (filtro) datos = datos.filter(s => (s.nombre || '').toLowerCase().includes(filtro));
      this.items = datos;
      this.kpis.totalServicios = datos.length;
    } catch (e) {
      console.error('Error cargando servicios:', e);
      UI.toast('Error al cargar servicios', 'error');
    } finally {
      this.loading = false;
    }
  },

  async cargarProfesionales() {
    try {
      this.profesionales = await db.profesionales.orderBy('createdAt').reverse().toArray();
      this.kpis.totalProfesionales = this.profesionales.length;
    } catch (e) {
      console.error('Error cargando profesionales:', e);
    }
  },

  async cargarCategorias() {
    try {
      this.categorias = await db.categorias_servicios.orderBy('nombre').toArray();
      this.kpis.categorias = this.categorias.length;
    } catch (e) {
      console.error('Error cargando categorias:', e);
    }
  },

  // --- SERVICIOS ---
  async abrirFormServicio(item = null) {
    const editando = !!item;
    const html = `
      <div class="space-y-4">
        <div class="grid grid-cols-2 gap-4">
          <div class="col-span-2">
            <label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>
            <input type="text" x-model="form.nombre"
                   class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                   :class="errors.nombre ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-pink-500 focus:border-pink-500'" />
            <template x-if="errors.nombre"><p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p></template>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Duraci\u00f3n (min)</label>
            <input type="number" min="5" step="5" x-model="form.duracion"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-shadow" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Precio <span class="text-red-500">*</span></label>
            <input type="number" step="0.01" min="0" x-model="form.precio"
                   class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                   :class="errors.precio ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-pink-500 focus:border-pink-500'" />
            <template x-if="errors.precio"><p class="mt-1 text-sm text-red-500" x-text="errors.precio"></p></template>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Categor\u00eda</label>
            <select x-model="form.categoriaId"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-shadow bg-white">
              <option value="">Sin categor\u00eda</option>
              <template x-for="c in categorias" :key="c.id">
                <option :value="c.id" x-text="c.nombre"></option>
              </template>
            </select>
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Profesionales habilitados</label>
          <div class="space-y-1.5">
            <template x-for="p in profesionales" :key="p.id">
              <label class="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" :value="p.id" x-model="form.profesionales"
                       class="rounded border-gray-300 text-pink-600 focus:ring-pink-500" />
                <span class="text-sm text-gray-700" x-text="p.nombre"></span>
              </label>
            </template>
            <template x-if="profesionales.length === 0">
              <p class="text-xs text-gray-400">No hay profesionales. Cr\u00e9alos en la pesta\u00f1a Profesionales.</p>
            </template>
          </div>
        </div>
      </div>`;
    await UI.modalForm(
      editando ? 'Editar Servicio' : 'Nuevo Servicio',
      html,
      async (data) => {
        data.profesionales = data.profesionales || [];
        if (editando) await this.actualizarServicio(item.id, data);
        else await this.guardarServicio(data);
        await this.cargarServicios();
      },
      item ? { ...item, profesionales: item.profesionales || [] } : { profesionales: [] }
    );
  },

  validarServicio(d) {
    this.errors = {};
    if (!d.nombre || !d.nombre.trim()) this.errors.nombre = 'El nombre es obligatorio';
    if (d.precio == null || d.precio === '' || Number(d.precio) < 0) this.errors.precio = 'Ingresa un precio v\u00e1lido';
    return Object.keys(this.errors).length === 0;
  },

  async guardarServicio(datos) {
    if (!this.validarServicio(datos)) return;
    this.saving = true;
    try {
      await db.servicios.put({
        id: uuid(),
        nombre: datos.nombre.trim(),
        duracion: parseInt(datos.duracion) || 30,
        precio: parseFloat(datos.precio) || 0,
        categoriaId: datos.categoriaId || '',
        profesionales: datos.profesionales || [],
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      UI.toast('Servicio guardado', 'success');
    } catch (e) {
      UI.toast('Error: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async actualizarServicio(id, datos) {
    if (!this.validarServicio(datos)) return;
    this.saving = true;
    try {
      const existente = await db.servicios.get(id);
      if (!existente) { UI.toast('Servicio no encontrado', 'error'); return; }
      await db.servicios.put({
        ...existente,
        nombre: datos.nombre.trim(),
        duracion: parseInt(datos.duracion) || 30,
        precio: parseFloat(datos.precio) || 0,
        categoriaId: datos.categoriaId || '',
        profesionales: datos.profesionales || [],
        updatedAt: new Date().toISOString()
      });
      UI.toast('Servicio actualizado', 'success');
    } catch (e) {
      UI.toast('Error: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async eliminarServicio(item) {
    const ok = await UI.confirm('Eliminar ' + (item.nombre || 'este servicio') + '?');
    if (!ok) return;
    try {
      await db.servicios.delete(item.id);
      UI.toast('Servicio eliminado', 'success');
      await this.cargarServicios();
    } catch (e) {
      UI.toast(e.message, 'error');
    }
  },

  // --- PROFESIONALES ---
  async abrirFormProfesional(item = null) {
    const editando = !!item;
    const html = `
      <div class="space-y-4">
        <div class="grid grid-cols-2 gap-4">
          <div class="col-span-2">
            <label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>
            <input type="text" x-model="form.nombre"
                   class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                   :class="errors.nombre ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500'" />
            <template x-if="errors.nombre"><p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p></template>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Tel\u00e9fono</label>
            <input type="tel" x-model="form.telefono"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-shadow" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" x-model="form.email"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-shadow" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Color</label>
            <input type="color" x-model="form.color"
                   class="w-full h-9 px-1 border border-gray-300 rounded-lg cursor-pointer" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Horario inicio</label>
            <input type="time" x-model="form.horarioInicio"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-shadow" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Horario fin</label>
            <input type="time" x-model="form.horarioFin"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-shadow" />
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">D\u00edas de descanso</label>
          <div class="flex flex-wrap gap-3">
            <template x-for="d in ['Lunes','Martes','Mi\u00e9rcoles','Jueves','Viernes','S\u00e1bado','Domingo']" :key="d">
              <label class="flex items-center gap-1.5 cursor-pointer">
                <input type="checkbox" :value="d" x-model="form.diasDescanso"
                       class="rounded border-gray-300 text-amber-600 focus:ring-amber-500" />
                <span class="text-sm text-gray-700" x-text="d"></span>
              </label>
            </template>
          </div>
        </div>
      </div>`;
    await UI.modalForm(
      editando ? 'Editar Profesional' : 'Nuevo Profesional',
      html,
      async (data) => {
        data.diasDescanso = data.diasDescanso || [];
        if (editando) await this.actualizarProfesional(item.id, data);
        else await this.guardarProfesional(data);
        await this.cargarProfesionales();
      },
      item ? { ...item, diasDescanso: item.diasDescanso || [] } : { color: '#ec4899', horarioInicio: '09:00', horarioFin: '18:00', diasDescanso: ['Domingo'] }
    );
  },

  validarProfesional(d) {
    this.errors = {};
    if (!d.nombre || !d.nombre.trim()) this.errors.nombre = 'El nombre es obligatorio';
    return Object.keys(this.errors).length === 0;
  },

  async guardarProfesional(datos) {
    if (!this.validarProfesional(datos)) return;
    this.saving = true;
    try {
      await db.profesionales.put({
        id: uuid(),
        nombre: datos.nombre.trim(),
        telefono: datos.telefono?.trim() || '',
        email: datos.email?.trim() || '',
        color: datos.color || '#ec4899',
        horarioInicio: datos.horarioInicio || '09:00',
        horarioFin: datos.horarioFin || '18:00',
        diasDescanso: datos.diasDescanso || [],
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      UI.toast('Profesional guardado', 'success');
    } catch (e) {
      UI.toast('Error: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async actualizarProfesional(id, datos) {
    if (!this.validarProfesional(datos)) return;
    this.saving = true;
    try {
      const existente = await db.profesionales.get(id);
      if (!existente) { UI.toast('Profesional no encontrado', 'error'); return; }
      await db.profesionales.put({
        ...existente,
        nombre: datos.nombre.trim(),
        telefono: datos.telefono?.trim() || '',
        email: datos.email?.trim() || '',
        color: datos.color || '#ec4899',
        horarioInicio: datos.horarioInicio || '09:00',
        horarioFin: datos.horarioFin || '18:00',
        diasDescanso: datos.diasDescanso || [],
        updatedAt: new Date().toISOString()
      });
      UI.toast('Profesional actualizado', 'success');
    } catch (e) {
      UI.toast('Error: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async eliminarProfesional(item) {
    const ok = await UI.confirm('Eliminar a ' + (item.nombre || 'este profesional') + '?');
    if (!ok) return;
    try {
      await db.profesionales.delete(item.id);
      UI.toast('Profesional eliminado', 'success');
      await this.cargarProfesionales();
    } catch (e) {
      UI.toast(e.message, 'error');
    }
  },

  // --- CATEGORIAS ---
  async abrirFormCategoria(item = null) {
    const editando = !!item;
    const html = `
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>
        <input type="text" x-model="form.nombre"
               class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
               :class="errors.nombre ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-green-500'" />
        <template x-if="errors.nombre"><p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p></template>
      </div>`;
    await UI.modalForm(
      editando ? 'Editar Categor\u00eda' : 'Nueva Categor\u00eda',
      html,
      async (data) => {
        if (editando) {
          const e = await db.categorias_servicios.get(item.id);
          if (e) { e.nombre = data.nombre.trim(); e.updatedAt = new Date().toISOString(); await db.categorias_servicios.put(e); }
        } else {
          await db.categorias_servicios.put({
            id: uuid(), nombre: data.nombre.trim(),
            createdBy: APP_CONFIG?.usuarioActual || 'anon',
            createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
          });
        }
        UI.toast('Categor\u00eda guardada', 'success');
        await this.cargarCategorias();
      },
      item || {}
    );
  },

  async eliminarCategoria(item) {
    const enUso = this.items.filter(s => s.categoriaId === item.id).length;
    const msg = enUso > 0 ? 'Eliminar ' + (item.nombre || 'esta categor\u00eda') + '? ' + enUso + ' servicio(s) se quedar\u00e1n sin categor\u00eda.' : 'Eliminar ' + (item.nombre || 'esta categor\u00eda') + '?';
    const ok = await UI.confirm(msg);
    if (!ok) return;
    try {
      await db.categorias_servicios.delete(item.id);
      UI.toast('Categor\u00eda eliminada', 'success');
      await this.cargarCategorias();
    } catch (e) {
      UI.toast(e.message, 'error');
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['citas-servicios'] = ModuloCitasServicios;

document.addEventListener('alpine:init', () => {
  Alpine.data('citasServiciosData', () => ModuloCitasServicios);
});
