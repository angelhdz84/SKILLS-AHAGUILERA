const ModuloComandaMesas = {
  id: 'com-mesas', titulo: 'Mesas', icono: 'bi bi-grid-3x3-gap',
  items: [], loading: true,

  async init() {
    await this.cargar();
    if (this.items.length === 0) await this.sembrar();
  },

  render() {
    return `
      <div x-data="comMesasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-red-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2"><i class="bi bi-grid-3x3-gap text-red-600"></i> Mesas</h2>
        </div>
        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 shadow-sm" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Mesa</button>
        </div>
        <template x-if="!loading && items.length > 0">
          <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <template x-for="m in items" :key="m.id">
              <div class="rounded-xl border-2 p-5 text-center cursor-pointer transition-all hover:shadow-lg hover:-translate-y-1"
                   :style="'border-color:' + (m.estado === 'disponible' ? '#22c55e' : m.estado === 'ocupada' ? '#ef4444' : '#f59e0b') + '; background:' + (m.estado === 'disponible' ? '#f0fdf4' : m.estado === 'ocupada' ? '#fef2f2' : '#fffbeb')"
                   @click="cambiarEstado(m)">
                <i class="text-3xl mb-2" :class="m.estado === 'disponible' ? 'bi bi-circle-fill text-green-500' : m.estado === 'ocupada' ? 'bi bi-circle-fill text-red-500' : 'bi bi-circle-fill text-amber-500'"></i>
                <p class="font-bold text-lg text-gray-900" x-text="m.nombre"></p>
                <p class="text-xs mt-1 font-medium capitalize" :class="m.estado === 'disponible' ? 'text-green-600' : m.estado === 'ocupada' ? 'text-red-600' : 'text-amber-600'" x-text="m.estado"></p>
                <p class="text-xs text-gray-400 mt-1" x-text="m.capacidad + ' pers'"></p>
              </div>
            </template>
          </div>
        </template>
        <template x-if="loading"><div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4"><template x-for="i in 8" :key="i"><div class="rounded-xl border-2 border-gray-200 p-5"><div class="w-8 h-8 bg-gray-200 rounded-full animate-pulse mx-auto mb-2"></div><div class="h-4 w-12 bg-gray-200 rounded animate-pulse mx-auto"></div></div></template></div></template>
        <template x-if="!loading && items.length === 0"><div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-grid-3x3-gap text-6xl mb-4"></i><p class="text-lg text-gray-500">Sin mesas</p></div></template>
      </div>
    `;
  },

  destroy() { this.items = []; this.loading = true; },

  async cargar() {
    try { this.loading = true; this.items = await db.mesas.orderBy('nombre').toArray(); }
    catch (e) { console.error(e); UI.toast('Error', 'error'); }
    finally { this.loading = false; }
  },

  async sembrar() {
    const nombres = ['Mesa 1','Mesa 2','Mesa 3','Mesa 4','Mesa 5','Mesa 6','Barra 1','Barra 2'];
    try {
      for (const n of nombres) await db.mesas.put({ id: window.uuid(), nombre: n, capacidad: 4, estado: 'disponible', createdBy: 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      await this.cargar();
    } catch (e) { console.error(e); }
  },

  async cambiarEstado(item) {
    const html = '<div class="space-y-3"><label class="block text-sm font-medium text-gray-700">Estado de ' + item.nombre + '</label><select x-model="form.estado" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500 bg-white"><option value="disponible">Disponible</option><option value="ocupada">Ocupada</option><option value="cuenta">Cuenta solicitada</option></select></div>';
    await UI.modalForm(item.nombre, html, async (data) => {
      const e = await db.mesas.get(item.id);
      if (!e) return;
      await db.mesas.put({ ...e, estado: data.estado, updatedAt: new Date().toISOString() });
      UI.toast('Mesa ' + data.estado, 'success');
      await this.cargar();
    }, { estado: item.estado });
  },

  async abrirForm() {
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre</label><input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Capacidad</label><input type="number" min="1" x-model="form.capacidad" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500" /></div></div>';
    await UI.modalForm('Nueva Mesa', html, async (data) => {
      if (!data.nombre?.trim()) { UI.toast('Nombre requerido', 'error'); return; }
      await db.mesas.put({ id: window.uuid(), nombre: data.nombre.trim(), capacidad: parseInt(data.capacidad) || 4, estado: 'disponible', createdBy: 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      UI.toast('Mesa creada', 'success'); await this.cargar();
    }, { nombre: '', capacidad: 4 });
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['com-mesas'] = ModuloComandaMesas;
document.addEventListener('alpine:init', () => { Alpine.data('comMesasData', () => ModuloComandaMesas); });
