const ModuloFlotaMantenimiento = {
  id: 'flota-mantenimiento',
  titulo: 'Mantenimiento',
  icono: 'bi bi-tools',

  items: [],
  vehiculos: [],
  loading: true,
  errors: {},
  filtroVehiculo: '',
  filtroTipo: '',
  kpis: { total: 0, costoTotal: 0, proximos: 0, preventivos: 0 },

  tipos: ['Preventivo', 'Correctivo', 'Llantas', 'Frenos', 'Aceite', 'Transmisión', 'Suspensión', 'Eléctrico', 'Otro'],

  async init() {
    await Promise.all([this.cargar(), this.cargarVehiculos()]);
  },

  render() {
    return `
      <div x-data="flotaMantenimientoData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-green-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-tools text-green-600"></i> Mantenimiento
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Servicios</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Costo total</p>
            <p class="text-2xl font-bold text-green-600" x-text="'$' + kpis.costoTotal.toLocaleString('es-MX', {minimumFractionDigits:2})"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Próximos vencimiento</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.proximos"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Preventivos</p>
            <p class="text-2xl font-bold text-green-600" x-text="kpis.preventivos"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Servicio
          </button>
          <select x-model="filtroVehiculo" @change="cargar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-green-500 outline-none transition-shadow">
            <option value="">Todos los vehículos</option>
            <template x-for="v in vehiculos" :key="v.id">
              <option :value="v.id" x-text="v.placas + ' - ' + (v.marca || '')"></option>
            </template>
          </select>
          <select x-model="filtroTipo" @change="cargar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-green-500 outline-none transition-shadow">
            <option value="">Todos los tipos</option>
            <template x-for="t in tipos" :key="t">
              <option :value="t" x-text="t"></option>
            </template>
          </select>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-tools text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">Sin servicios registrados</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Registrar primero
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Fecha</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Vehículo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Tipo</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Costo</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Km</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Taller</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Próximo</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Acciones</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <template x-for="m in items" :key="m.id">
                    <tr class="hover:bg-gray-50 transition-colors cursor-pointer" @click="abrirForm(m)">
                      <td class="px-4 py-3 text-gray-500 text-xs whitespace-nowrap" x-text="formatearFecha(m.createdAt)"></td>
                      <td class="px-4 py-3 font-medium text-gray-900" x-text="nombreVehiculo(m.vehiculoId)"></td>
                      <td class="px-4 py-3">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium" :class="tipoClass(m.tipo)" x-text="m.tipo || 'Otro'"></span>
                      </td>
                      <td class="px-4 py-3 text-right font-mono font-medium text-gray-900" x-text="'$' + (m.costo || 0).toLocaleString('es-MX', {minimumFractionDigits:2})"></td>
                      <td class="px-4 py-3 text-right text-gray-500" x-text="m.kilometraje ? m.kilometraje.toLocaleString() + ' km' : '—'"></td>
                      <td class="px-4 py-3 text-gray-600" x-text="m.taller || '—'"></td>
                      <td class="px-4 py-3">
                        <template x-if="m.proximoKm">
                          <span class="font-mono text-xs" :class="proximoClass(m)">⏰ <span x-text="m.proximoKm.toLocaleString() + ' km'"></span></span>
                        </template>
                        <template x-if="!m.proximoKm">
                          <span class="text-gray-400">—</span>
                        </template>
                      </td>
                      <td class="px-4 py-3 text-right">
                        <button class="text-gray-400 hover:text-red-500 transition-colors p-1" @click.stop="eliminar(m)">
                          <i class="bi bi-trash"></i>
                        </button>
                      </td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-4">
                <div class="h-4 w-20 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-28 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-16 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-16 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-24 bg-gray-200 rounded animate-pulse ml-auto"></div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.vehiculos = [];
    this.filtroVehiculo = '';
    this.filtroTipo = '';
    this.loading = true;
    this.kpis = { total: 0, costoTotal: 0, proximos: 0, preventivos: 0 };
  },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch { return f; } },
  nombreVehiculo(id) { const v = this.vehiculos.find(x => x.id === id); return v ? (v.placas || v.numeroEconomico || '—') : '—'; },
  tipoClass(t) {
    const m = { 'Preventivo': 'bg-green-100 text-green-700', 'Correctivo': 'bg-red-100 text-red-700', 'Llantas': 'bg-blue-100 text-blue-700', 'Frenos': 'bg-amber-100 text-amber-700', 'Aceite': 'bg-sky-100 text-sky-700', 'Transmisión': 'bg-purple-100 text-purple-700', 'Suspensión': 'bg-indigo-100 text-indigo-700', 'Eléctrico': 'bg-yellow-100 text-yellow-700' };
    return m[t] || 'bg-gray-100 text-gray-700';
  },
  proximoClass(m) {
    if (!m.kilometraje || !m.proximoKm) return 'text-gray-400';
    const diff = m.proximoKm - (m.kilometraje || 0);
    if (diff <= 0) return 'text-red-600 font-bold';
    if (diff <= 1000) return 'text-amber-600';
    return 'text-gray-500';
  },

  async cargar() {
    try {
      this.loading = true;
      let datos = await db.mantenimientos.orderBy('createdAt').reverse().toArray();
      if (this.filtroVehiculo) datos = datos.filter(m => m.vehiculoId === this.filtroVehiculo);
      if (this.filtroTipo) datos = datos.filter(m => m.tipo === this.filtroTipo);
      this.items = datos;
      const costo = datos.reduce((s, m) => s + (m.costo || 0), 0);
      const prox = datos.filter(m => {
        if (!m.kilometraje || !m.proximoKm) return false;
        return (m.proximoKm - m.kilometraje) <= 1000;
      });
      this.kpis = { total: datos.length, costoTotal: costo, proximos: prox.length, preventivos: datos.filter(m => m.tipo === 'Preventivo').length };
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarVehiculos() {
    try { this.vehiculos = await db.vehiculos.orderBy('placas').toArray(); }
    catch (e) { console.error(e); }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div class="grid grid-cols-2 gap-4">',
      '<div class="col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Vehículo <span class="text-red-500">*</span></label>',
      '<select x-model="form.vehiculoId" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow bg-white"',
      ':class="errors.vehiculoId ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-green-500\'">',
      '<option value="">Seleccionar...</option>',
      '<template x-for="v in vehiculos" :key="v.id"><option :value="v.id" x-text="v.placas + \' - \' + (v.marca || \'\') + \' \' + (v.modelo || \'\')"></option></template>',
      '</select><template x-if="errors.vehiculoId"><p class="mt-1 text-sm text-red-500" x-text="errors.vehiculoId"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Tipo <span class="text-red-500">*</span></label>',
      '<select x-model="form.tipo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-green-500 transition-shadow bg-white">',
      '<template x-for="t in tipos" :key="t"><option :value="t" x-text="t"></option></template>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Costo <span class="text-red-500">*</span></label>',
      '<input type="number" step="0.01" min="0" x-model="form.costo" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.costo ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-green-500\'" />',
      '<template x-if="errors.costo"><p class="mt-1 text-sm text-red-500" x-text="errors.costo"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Kilometraje</label>',
      '<input type="number" min="0" x-model="form.kilometraje" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-green-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Taller</label>',
      '<input type="text" x-model="form.taller" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-green-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Próximo km</label>',
      '<input type="number" min="0" x-model="form.proximoKm" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-green-500 transition-shadow" placeholder="Kilometraje para próximo servicio" /></div>',
      '</div></div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Servicio' : 'Nuevo Servicio de Mantenimiento', html,
      async (data) => {
        this.errors = {};
        if (!data.vehiculoId) { this.errors.vehiculoId = 'Selecciona un vehículo'; return; }
        if (!data.tipo) { this.errors.tipo = 'Selecciona un tipo'; return; }
        if (data.costo == null || parseFloat(data.costo) < 0) { this.errors.costo = 'Costo válido requerido'; return; }
        if (editando) await this.actualizar(item.id, data);
        else await this.guardar(data);
        await this.cargar();
      }, item || { tipo: 'Preventivo' }
    );
  },

  async guardar(datos) {
    try {
      await db.mantenimientos.put({
        id: uuid(), vehiculoId: datos.vehiculoId, tipo: datos.tipo,
        costo: parseFloat(datos.costo), kilometraje: parseInt(datos.kilometraje) || null,
        taller: datos.taller?.trim() || '', proximoKm: parseInt(datos.proximoKm) || null,
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString()
      });
      UI.toast('Servicio registrado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async actualizar(id, datos) {
    try {
      const e = await db.mantenimientos.get(id);
      if (!e) { UI.toast('No encontrado', 'error'); return; }
      await db.mantenimientos.put({ ...e, vehiculoId: datos.vehiculoId, tipo: datos.tipo,
        costo: parseFloat(datos.costo), kilometraje: parseInt(datos.kilometraje) || null,
        taller: datos.taller?.trim() || '', proximoKm: parseInt(datos.proximoKm) || null });
      UI.toast('Servicio actualizado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar este servicio de mantenimiento?');
    if (!ok) return;
    try { await db.mantenimientos.delete(item.id); UI.toast('Eliminado', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['flota-mantenimiento'] = ModuloFlotaMantenimiento;

document.addEventListener('alpine:init', () => {
  Alpine.data('flotaMantenimientoData', () => ModuloFlotaMantenimiento);
});
