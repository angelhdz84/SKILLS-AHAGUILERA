# AHA POS — Punto de venta offline para pequeños comercios

## Perfil
lite

## IA Jutia
lite

## Módulos
- **productos** (CRUD: nombre, código barras, precio, categoría, stock, imagen, búsqueda instantánea)
- **ventas** (carrito: agregar por búsqueda, cantidad, descuento por item, subtotal tiempo real, formas de pago: efectivo/tarjeta/transferencia, ticket imprimible)
- **corte** (arqueo por denominación billetes/monedas, gastos menores con concepto, cierre de turno, historial de cortes)
- **devoluciones** (seleccionar venta del historial, elegir productos, motivo, reembolso parcial/total, afecta inventario)
- **reportes** (dashboard ventas hoy, productos top, ventas por día/semana/mes con Chart.js, export CSV)

## Tablas Dexie
```javascript
db.version(3).stores({
  productos: 'id, nombre, *codigoBarras, *categoriaId, precio, stock, *imagen, createdAt, updatedAt',
  categorias: 'id, nombre, color, createdAt, updatedAt',
  ventas: 'id, *folio, total, *metodoPago, items, *createdBy, createdAt, updatedAt',
  cortes: 'id, *folio, apertura, cierre, totalEsperado, totalReal, *createdBy, createdAt, updatedAt',
  devoluciones: 'id, *ventaId, *productoId, cantidad, *motivo, reembolso, createdAt',
  gastosMenores: 'id, *corteId, *concepto, monto, *hora, *createdBy, createdAt',
  _sync_log: 'id, *tabla, *operacion, *idRegistro, *estado, *fecha, *createdBy, createdAt'
});
```

Nota: `ventas_items` están embebidos como array en `ventas.items`.

## Campos sensibles
ninguno

## UI
- Carrito de compras con sidebar o modal: items, cantidades, descuentos, subtotal
- Toolbar con búsqueda y botón acción
- Tablas responsive
- Modal para formularios
- Empty state + loading skeleton
- Dashboard con stats y Chart.js
- Ticket de venta imprimible (window.print)

## Librerías adicionales
chart.js

## project.config.js
```javascript
window.APP_CONFIG = {
  app: { id: 'aha-pos', nombre: 'AHA POS', version: '1.0.0' },
  perfil: 'lite',
  iaJutia: { perfil: 'lite' },
  modulosActivos: ['ventas', 'productos', 'corte', 'devoluciones', 'reportes'],
  modulos: {
    ventas: { titulo: 'Ventas', icono: 'bi bi-cart3', activo: true },
    productos: { titulo: 'Productos', icono: 'bi bi-box', activo: true },
    corte: { titulo: 'Corte', icono: 'bi bi-cash-stack', activo: true },
    devoluciones: { titulo: 'Devoluciones', icono: 'bi bi-arrow-return-left', activo: true },
    reportes: { titulo: 'Reportes', icono: 'bi bi-graph-up', activo: true }
  },
  tema: { modo: 'light', colores: { primary: '#059669', secondary: '#78716c', accent: '#f59e0b' } },
  cifrado: { camposSensibles: [] },
  ui: { formsMode: 'modal', alerts: 'toast', confirmDelete: true, avatars: false },
  data: { dir: 'data/', maxFileSize: 10485760 },
  sync: { primaryFormat: 'json', encrypt: true }
};
```

## Component library
daisyui
