# Módulo Plantilla — Guía de uso

Esta plantilla implementa un CRUD completo con los 12 patrones del stack AHA:

| # | Patrón | Implementación |
|---|--------|----------------|
| 1 | CRUD completo | `abrirForm()` → modal → `guardar()` (create/update) + `eliminar()` con confirm |
| 2 | Validación | `validarForm()` con `errors{}` reactivo y clase `border-red-500` |
| 3 | Estados visuales | Skeleton (carga) / Empty-state (sin datos) / Tabla (con datos) / Error (fallo) |
| 4 | Búsqueda | `buscar()` con filtro Dexie + `@input.debounce` |
| 5 | Paginación | `page`, `pageSize`, `totalPages` + navegación anterior/siguiente |
| 6 | Exportación | PDF (jsPDF) y CSV/Excel (SheetJS + fallback manual) desde toolbar |
| 7 | Confirmaciones | `UI.confirm()` antes de eliminar |
| 8 | Manejo de errores | `try/catch` + `UI.toast()` en cada operación + estado `error` en UI |
| 9 | Timestamps | `createdAt`, `updatedAt` automáticos en create/update |
| 10 | Badges de estado | Clase dinámica `bg-green-100 text-green-800` / `bg-gray-100 text-gray-600` según `estado` |
| 11 | Atajo Cmd+K | `id: '_template'`, `titulo: 'Plantilla'` para search-palette |
| 12 | Ciclo de vida | `init()` → `render()` → `destroy()` con limpieza |

## Cómo usar

1. **Copiar** `modules/_template/` → `modules/mi-modulo/`
2. **Editar `module.js`:**
   - Cambiar `id`, `titulo`, `icono`
   - Cambiar nombre de tabla Dexie (reemplazar `_template` por `mi_tabla`)
   - Adaptar esquema de tabla y campos en `guardar()`/`actualizar()`
   - Ajustar columnas de tabla y formulario
3. **Editar `module.html`:**
   - Cambiar ícono y título
   - Adaptar encabezados de columna (`<th>`)
   - Ajustar celdas de datos (`<td>`)
4. **Registrar en `project.config.js`:**
   ```js
   modulosActivos: ['mi-modulo', ...],
   modulos: {
     'mi-modulo': { titulo: 'Mi Módulo', icono: 'bi bi-icon', activo: true }
   }
   ```
5. **Verificar** que `app.js` tenga el link del módulo en sidebar

## Notas

- Esta plantilla usa **Tailwind CSS puro** (sin DaisyUI). Todos los estilos son utility classes.
- Colores primarios: `indigo-600` (botones), `indigo-700` (hover). Ajustar según DESIGN.md.
- Los campos sensibles se cifran automáticamente según `APP_CONFIG.cifrado.camposSensibles`
- La tabla Dexie se crea automáticamente al abrir la app (no requiere migración manual)
- Los skeletons usan `animate-pulse bg-gray-200 rounded-lg` — no spinners
- No uses `alert()`, `confirm()`, `prompt()` — usa `UI.toast()`, `UI.confirm()`, `UI.modalForm()`
- La exportación usa SheetJS si está disponible, con fallback a CSV manual
