const ModuloPFProductos = {
  id: 'pf-productos',
  titulo: 'Productos / Servicios',
  icono: 'bi bi-box',

  items: [],
  searchQuery: '',
  loading: true,

  async init() {
    await this.cargar();
  },

  render() {
    return `
      <div x-data="pfProductosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-sky-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-box text-sky-600"></i> Productos / Servicios
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 text-white text-sm font-medium rounded-lg hover:bg-sky-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Producto
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="filtrar" placeholder="Buscar por clave o nombre..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-sky-500 outline-none transition-shadow" />
          </div>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-box text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">Sin productos</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 text-white text-sm font-medium rounded-lg hover:bg-sky-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Agregar
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Clave</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Nombre</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Precio</th>
                    <th class="text-center px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">IVA</th>
                    <th class="text-center px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <template x-for="p in items" :key="p.id">
                    <tr class="hover:bg-gray-50 transition-colors cursor-pointer" @click="abrirForm(p)">
                      <td class="px-4 py-3 font-mono text-xs text-gray-500" x-text="p.clave || '\u2014'"></td>
                      <td class="px-4 py-3 font-medium text-gray-900" x-text="p.nombre"></td>
                      <td class="px-4 py-3 text-right font-mono font-bold text-gray-900" x-text="'$' + Number(p.precioUnitario || 0).toLocaleString('es-MX')"></td>
                      <td class="px-4 py-3 text-center">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                              :class="p.iva ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'"
                              x-text="p.iva ? (p.iva == 0.16 ? '16%' : (p.iva * 100) + '%') : 'Exento'"></span>
                      </td>
                      <td class="px-4 py-3 text-center">
                        <button class="text-gray-300 hover:text-red-500 transition-colors p-1" @click.stop="eliminar(p)"><i class="bi bi-trash"></i></button>
                      </td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-4"><div class="h-4 w-16 bg-gray-200 rounded animate-pulse"></div><div class="h-4 w-32 bg-gray-200 rounded animate-pulse"></div><div class="h-4 w-16 bg-gray-200 rounded animate-pulse ml-auto"></div></div></template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() { this.items = []; this.searchQuery = ''; this.loading = true; },

  async cargar() {
    try {
      this.loading = true;
      this.items = await db.productos_fiscales.orderBy('nombre').toArray();
    } catch (e) { console.error(e); UI.toast('Error', 'error'); }
    finally { this.loading = false; }
  },

  filtrar() {
    Promise.resolve().then(async () => {
      try {
        this.loading = true;
        let datos = await db.productos_fiscales.orderBy('nombre').toArray();
        const q = this.searchQuery.trim().toLowerCase();
        if (q) datos = datos.filter(p => (p.nombre || '').toLowerCase().includes(q) || (p.clave || '').toLowerCase().includes(q));
        this.items = datos;
      } catch (e) { console.error(e); }
      finally { this.loading = false; }
    });
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>',
      '<input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" /></div>',
      '<div class="grid grid-cols-2 gap-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Clave (SAT/Producto)</label>',
      '<input type="text" x-model="form.clave" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" placeholder="Ej: 01010101" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Precio unitario <span class="text-red-500">*</span></label>',
      '<input type="number" step="0.01" min="0" x-model="form.precioUnitario" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow" /></div>',
      '</div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">IVA</label>',
      '<select x-model="form.iva" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-sky-500 transition-shadow bg-white">',
      '<option value="0.16">16% (tasa general)</option>',
      '<option value="0">Exento</option>',
      '<option value="0.08">8% (frontera)</option>',
      '</select></div>',
      '</div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar' : 'Nuevo Producto/Servicio', html,
      async (data) => {
        if (!data.nombre?.trim()) { UI.toast('Nombre requerido', 'error'); return; }
        if (editando) {
          const e = await db.productos_fiscales.get(item.id);
          if (!e) { UI.toast('No encontrado', 'error'); return; }
          await db.productos_fiscales.put({ ...e, nombre: data.nombre.trim(), clave: data.clave || '', precioUnitario: parseFloat(data.precioUnitario) || 0, iva: parseFloat(data.iva) || 0, updatedAt: new Date().toISOString() });
        } else {
          await db.productos_fiscales.put({ id: window.uuid(), nombre: data.nombre.trim(), clave: data.clave || '', precioUnitario: parseFloat(data.precioUnitario) || 0, iva: parseFloat(data.iva) || 0, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        }
        UI.toast(editando ? 'Actualizado' : 'Guardado', 'success');
        await this.cargar();
      }, item || { nombre: '', clave: '', precioUnitario: 0, iva: 0.16 }
    );
  },

  async eliminar(item) {
    if (!await UI.confirm('Eliminar ' + item.nombre + '?')) return;
    try { await db.productos_fiscales.delete(item.id); UI.toast('Eliminado', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['pf-productos'] = ModuloPFProductos;

document.addEventListener('alpine:init', () => {
  Alpine.data('pfProductosData', () => ModuloPFProductos);
});
