const ModuloFlotaRutas = {
  id: 'flota-rutas',
  titulo: 'Incidentes',
  icono: 'bi bi-exclamation-triangle',

  items: [],
  vehiculos: [],
  loading: true,
  errors: {},
  filtroVehiculo: '',
  filtroTipo: '',
  kpis: { total: 0, costoTotal: 0, accidentes: 0, multas: 0 },

  tipos: ['Accidente', 'Multa', 'Avería', 'Robo', 'Infracción', 'Otro'],

  async init() {
    await Promise.all([this.cargar(), this.cargarVehiculos()]);
  },

  render() {
    return `
      <div x-data="flotaRutasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-red-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-exclamation-triangle text-red-600"></i> Incidentes
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total incidentes</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Costo total</p>
            <p class="text-2xl font-bold text-red-600" x-text="'$' + kpis.costoTotal.toLocaleString('es-MX', {minimumFractionDigits:2})"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Accidentes</p>
            <p class="text-2xl font-bold text-red-600" x-text="kpis.accidentes"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Multas</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.multas"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Incidente
          </button>
          <select x-model="filtroVehiculo" @change="cargar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-red-500 outline-none transition-shadow">
            <option value="">Todos los vehículos</option>
            <template x-for="v in vehiculos" :key="v.id">
              <option :value="v.id" x-text="v.placas + ' - ' + (v.marca || '')"></option>
            </template>
          </select>
          <select x-model="filtroTipo" @change="cargar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-red-500 outline-none transition-shadow">
            <option value="">Todos los tipos</option>
            <template x-for="t in tipos" :key="t">
              <option :value="t" x-text="t"></option>
            </template>
          </select>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-check-circle text-6xl mb-4 text-green-400"></i>
            <p class="text-lg text-gray-500 mb-2">Sin incidentes registrados</p>
            <p class="text-sm text-gray-400 mb-4">Todos los vehículos en orden</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Registrar incidente
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Fecha</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Vehículo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Tipo</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Costo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Descripción</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Usuario</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Acciones</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <template x-for="inc in items" :key="inc.id">
                    <tr class="hover:bg-gray-50 transition-colors cursor-pointer" @click="abrirForm(inc)">
                      <td class="px-4 py-3 text-gray-500 text-xs whitespace-nowrap" x-text="formatearFecha(inc.createdAt)"></td>
                      <td class="px-4 py-3 font-medium text-gray-900" x-text="nombreVehiculo(inc.vehiculoId)"></td>
                      <td class="px-4 py-3">
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium" :class="tipoClass(inc.tipo)">
                          <i :class="tipoIcon(inc.tipo)"></i>
                          <span x-text="inc.tipo || 'Otro'"></span>
                        </span>
                      </td>
                      <td class="px-4 py-3 text-right font-mono font-medium text-gray-900" x-text="inc.costo ? '$' + Number(inc.costo).toLocaleString('es-MX', {minimumFractionDigits:2}) : '—'"></td>
                      <td class="px-4 py-3 text-gray-500 max-w-[200px] truncate" x-text="inc.descripcion || '—'"></td>
                      <td class="px-4 py-3 text-gray-400 text-xs" x-text="inc.createdBy || '—'"></td>
                      <td class="px-4 py-3 text-right">
                        <button class="text-gray-400 hover:text-red-500 transition-colors p-1" @click.stop="eliminar(inc)">
                          <i class="bi bi-trash"></i>
                        </button>
                      </td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-4">
                <div class="h-4 w-20 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-28 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-5 w-20 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-16 bg-gray-200 rounded animate-pulse ml-auto"></div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.vehiculos = [];
    this.filtroVehiculo = '';
    this.filtroTipo = '';
    this.loading = true;
    this.kpis = { total: 0, costoTotal: 0, accidentes: 0, multas: 0 };
  },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch { return f; } },
  nombreVehiculo(id) { const v = this.vehiculos.find(x => x.id === id); return v ? (v.placas || v.numeroEconomico || '—') : '—'; },
  tipoClass(t) {
    const m = { 'Accidente': 'bg-red-100 text-red-700', 'Multa': 'bg-amber-100 text-amber-700', 'Avería': 'bg-orange-100 text-orange-700', 'Robo': 'bg-purple-100 text-purple-700', 'Infracción': 'bg-yellow-100 text-yellow-700' };
    return m[t] || 'bg-gray-100 text-gray-700';
  },
  tipoIcon(t) {
    const m = { 'Accidente': 'bi bi-car-crash', 'Multa': 'bi bi-file-earmark-text', 'Avería': 'bi bi-gear', 'Robo': 'bi bi-shield-exclamation', 'Infracción': 'bi bi-exclamation-circle' };
    return m[t] || 'bi bi-circle';
  },

  async cargar() {
    try {
      this.loading = true;
      let datos = await db.incidentes.orderBy('createdAt').reverse().toArray();
      if (this.filtroVehiculo) datos = datos.filter(i => i.vehiculoId === this.filtroVehiculo);
      if (this.filtroTipo) datos = datos.filter(i => i.tipo === this.filtroTipo);
      this.items = datos;
      this.kpis = {
        total: datos.length,
        costoTotal: datos.reduce((s, i) => s + (i.costo || 0), 0),
        accidentes: datos.filter(i => i.tipo === 'Accidente').length,
        multas: datos.filter(i => i.tipo === 'Multa' || i.tipo === 'Infracción').length
      };
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarVehiculos() {
    try { this.vehiculos = await db.vehiculos.orderBy('placas').toArray(); }
    catch (e) { console.error(e); }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div class="grid grid-cols-2 gap-4">',
      '<div class="col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Vehículo <span class="text-red-500">*</span></label>',
      '<select x-model="form.vehiculoId" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow bg-white"',
      ':class="errors.vehiculoId ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-red-500\'">',
      '<option value="">Seleccionar...</option>',
      '<template x-for="v in vehiculos" :key="v.id"><option :value="v.id" x-text="v.placas + \' - \' + (v.marca || \'\') + \' \' + (v.modelo || \'\')"></option></template>',
      '</select><template x-if="errors.vehiculoId"><p class="mt-1 text-sm text-red-500" x-text="errors.vehiculoId"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Tipo <span class="text-red-500">*</span></label>',
      '<select x-model="form.tipo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500 transition-shadow bg-white">',
      '<template x-for="t in tipos" :key="t"><option :value="t" x-text="t"></option></template>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Costo estimado</label>',
      '<input type="number" step="0.01" min="0" x-model="form.costo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500 transition-shadow" /></div>',
      '<div class="col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Descripción <span class="text-red-500">*</span></label>',
      '<textarea x-model="form.descripcion" rows="3" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.descripcion ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-red-500 focus:border-red-500\'" placeholder="Describe el incidente..."></textarea>',
      '<template x-if="errors.descripcion"><p class="mt-1 text-sm text-red-500" x-text="errors.descripcion"></p></template></div>',
      '</div></div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Incidente' : 'Nuevo Incidente', html,
      async (data) => {
        this.errors = {};
        if (!data.vehiculoId) { this.errors.vehiculoId = 'Selecciona un vehículo'; return; }
        if (!data.tipo) { this.errors.tipo = 'Selecciona un tipo'; return; }
        if (!data.descripcion || !data.descripcion.trim()) { this.errors.descripcion = 'La descripción es obligatoria'; return; }
        if (editando) await this.actualizar(item.id, data);
        else await this.guardar(data);
        await this.cargar();
      }, item || { tipo: 'Otro' }
    );
  },

  async guardar(datos) {
    try {
      await db.incidentes.put({
        id: uuid(), vehiculoId: datos.vehiculoId, tipo: datos.tipo,
        costo: parseFloat(datos.costo) || null, descripcion: datos.descripcion.trim(),
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString()
      });
      UI.toast('Incidente registrado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async actualizar(id, datos) {
    try {
      const e = await db.incidentes.get(id);
      if (!e) { UI.toast('No encontrado', 'error'); return; }
      await db.incidentes.put({ ...e, vehiculoId: datos.vehiculoId, tipo: datos.tipo,
        costo: parseFloat(datos.costo) || null, descripcion: datos.descripcion.trim() });
      UI.toast('Incidente actualizado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar este incidente?');
    if (!ok) return;
    try { await db.incidentes.delete(item.id); UI.toast('Eliminado', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['flota-rutas'] = ModuloFlotaRutas;

document.addEventListener('alpine:init', () => {
  Alpine.data('flotaRutasData', () => ModuloFlotaRutas);
});
