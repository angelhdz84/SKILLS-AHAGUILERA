const ModuloCampoCosechas = {
  id: 'campo-cosechas',
  titulo: 'Cosechas',
  icono: 'bi bi-arrow-left-right',

  items: [],
  item: null,
  formData: {},
  errors: {},
  searchQuery: '',
  loading: true,
  error: null,
  saving: false,
  page: 1,
  pageSize: 25,
  totalPages: 1,
  insumosCache: [],
  lotesCache: [],

  async init() {
    this.insumosCache = await db.insumos.toArray();
    this.lotesCache = await db.lotes.toArray();
    await this.cargarDatos();
  },

  render(params = {}) {
    return `
      <div x-data="campoCosechasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-blue-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-arrow-left-right text-blue-600"></i> Movimientos de Insumos
          </h2>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs text-gray-500 uppercase tracking-wider">Total movimientos</p>
            <p class="text-2xl font-bold text-gray-900 mt-1" x-text="items.length"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs text-gray-500 uppercase tracking-wider">Entradas</p>
            <p class="text-2xl font-bold text-green-600 mt-1" x-text="items.filter(i => i.tipo === 'entrada').length"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs text-gray-500 uppercase tracking-wider">Salidas</p>
            <p class="text-2xl font-bold text-red-600 mt-1" x-text="items.filter(i => i.tipo === 'salida').length"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Nuevo movimiento
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="buscar" placeholder="Buscar movimiento..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-shadow" />
          </div>
          <button class="inline-flex items-center gap-1.5 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors" @click="exportarPDF()" x-show="items.length">
            <i class="bi bi-file-earmark-pdf"></i> PDF
          </button>
        </div>

        <template x-if="error">
          <div class="p-4 mb-4 bg-red-50 border border-red-200 rounded-lg">
            <div class="flex items-center gap-2 text-red-700 text-sm">
              <i class="bi bi-exclamation-triangle"></i>
              <span x-text="error"></span>
            </div>
          </div>
        </template>

        <template x-if="!loading && !error && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-arrow-left-right text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-4">No hay movimientos registrados a\u00fan</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Registrar primer movimiento
            </button>
          </div>
        </template>

        <template x-if="!loading && items.length > 0">
          <div>
            <div class="overflow-x-auto rounded-lg border border-gray-200">
              <table class="w-full text-sm">
                <thead>
                  <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Insumo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Tipo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Cantidad</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Lote</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Proveedor</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Costo</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600">Acciones</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <tr x-for="(item, idx) in paginated" :key="item.id"
                      class="hover:bg-gray-50 transition-colors"
                      :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'">
                    <td class="px-4 py-3 text-gray-900 font-medium" x-text="nombreInsumo(item.insumoId)"></td>
                    <td class="px-4 py-3">
                      <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                            :class="item.tipo === 'entrada' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                            x-text="item.tipo === 'entrada' ? 'Entrada' : 'Salida'"></span>
                    </td>
                    <td class="px-4 py-3 text-gray-900 font-semibold" x-text="formatearCantidad(item)"></td>
                    <td class="px-4 py-3 text-gray-500" x-text="nombreLote(item.loteId) || '—'"></td>
                    <td class="px-4 py-3 text-gray-500" x-text="item.proveedor || '—'"></td>
                    <td class="px-4 py-3 text-gray-500" x-text="formatearCosto(item.costo)"></td>
                    <td class="px-4 py-3 text-right">
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" @click="abrirForm(item)" title="Editar">
                        <i class="bi bi-pencil"></i>
                      </button>
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" @click="eliminar(item)" title="Eliminar">
                        <i class="bi bi-trash"></i>
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div class="flex justify-between items-center mt-4" x-show="totalPages > 1">
              <span class="text-sm text-gray-500">
                P\u00e1gina <span class="font-medium text-gray-700" x-text="page"></span> de <span class="font-medium text-gray-700" x-text="totalPages"></span>
              </span>
              <div class="flex gap-2">
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === 1" @click="page--;">
                  <i class="bi bi-chevron-left"></i>
                </button>
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === totalPages" @click="page++;">
                  <i class="bi bi-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.item = null;
    this.searchQuery = '';
    this.loading = true;
    this.error = null;
    this.page = 1;
    this.insumosCache = [];
    this.lotesCache = [];
  },

  nombreInsumo(insumoId) {
    const ins = this.insumosCache.find(i => i.id === insumoId);
    return ins ? ins.nombre : 'Insumo eliminado';
  },

  nombreLote(loteId) {
    if (!loteId) return '';
    const lote = this.lotesCache.find(l => l.id === loteId);
    return lote ? lote.nombre : 'Lote eliminado';
  },

  formatearCantidad(item) {
    const ins = this.insumosCache.find(i => i.id === item.insumoId);
    const unidad = (ins && ins.unidad) || '';
    return (item.cantidad || 0) + ' ' + unidad;
  },

  formatearCosto(costo) {
    if (!costo) return '—';
    try {
      return '$' + parseFloat(costo).toFixed(2);
    } catch { return costo; }
  },

  formatearFecha(fecha) {
    if (!fecha) return '';
    try {
      return new Date(fecha).toLocaleDateString('es-MX', {
        year: 'numeric', month: 'short', day: 'numeric'
      });
    } catch { return fecha; }
  },

  get paginated() {
    const start = (this.page - 1) * this.pageSize;
    return this.items.slice(start, start + this.pageSize);
  },

  _cifrarSensibles(obj) {
    for (const campo of (APP_CONFIG.cifrado.camposSensibles || [])) {
      if (obj[campo] && typeof obj[campo] === 'string' && !obj[campo].startsWith('U2FsdGVkX1')) {
        obj[campo] = cryptoHelpers.encrypt(obj[campo]);
      }
    }
    return obj;
  },

  _descifrarSensibles(obj) {
    if (!APP_CONFIG.cifrado.camposSensibles) return obj;
    for (const campo of APP_CONFIG.cifrado.camposSensibles) {
      if (obj[campo]) obj[campo] = cryptoHelpers.decrypt(obj[campo]);
    }
    return obj;
  },

  async cargarDatos() {
    try {
      this.loading = true;
      this.error = null;
      this.insumosCache = await db.insumos.toArray();
      this.lotesCache = await db.lotes.toArray();
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.movimientos_insumo.orderBy('createdAt').reverse().toArray();
      if (filtro) {
        datos = datos.filter(i => {
          const nomIns = this.nombreInsumo(i.insumoId).toLowerCase();
          const nomLot = this.nombreLote(i.loteId).toLowerCase();
          return nomIns.includes(filtro) || nomLot.includes(filtro) || (i.proveedor || '').toLowerCase().includes(filtro);
        });
      }
      this.items = datos;
      this.totalPages = Math.max(1, Math.ceil(this.items.length / this.pageSize));
      if (this.page > this.totalPages) this.page = this.totalPages;
    } catch (e) {
      console.error('Error cargando movimientos:', e);
      this.error = 'Error al cargar movimientos';
      UI.toast('Error al cargar movimientos', 'error');
    } finally {
      this.loading = false;
    }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const descifrado = item ? this._descifrarSensibles({ ...item }) : {};
    const insumosOpts = this.insumosCache.map(i =>
      `<option value="${i.id}" ${descifrado.insumoId === i.id ? 'selected' : ''}>${i.nombre} (${i.unidad || 'pza'})</option>`
    ).join('');
    const lotesOpts = this.lotesCache.map(l =>
      `<option value="${l.id}" ${descifrado.loteId === l.id ? 'selected' : ''}>${l.nombre}</option>`
    ).join('');
    const html = `
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Insumo <span class="text-red-500">*</span></label>
          <select x-model="form.insumoId"
                  class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                  :class="errors.insumoId ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'"
                  :class="errors.insumoId ? 'focus:ring-2' : 'focus:ring-2'">
            <option value="">Seleccionar insumo...</option>
            ${insumosOpts}
          </select>
          <template x-if="errors.insumoId">
            <p class="mt-1 text-sm text-red-500" x-text="errors.insumoId"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Tipo de movimiento <span class="text-red-500">*</span></label>
          <select x-model="form.tipo"
                  class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                  :class="errors.tipo ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'"
                  :class="errors.tipo ? 'focus:ring-2' : 'focus:ring-2'">
            <option value="">Seleccionar tipo...</option>
            <option value="entrada" ${descifrado.tipo === 'entrada' ? 'selected' : ''}>Entrada (compra)</option>
            <option value="salida" ${descifrado.tipo === 'salida' ? 'selected' : ''}>Salida (aplicaci\u00f3n)</option>
          </select>
          <template x-if="errors.tipo">
            <p class="mt-1 text-sm text-red-500" x-text="errors.tipo"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Cantidad <span class="text-red-500">*</span></label>
          <input type="number" step="0.01" min="0" x-model="form.cantidad"
                 class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                 :class="errors.cantidad ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500'"
                 :class="errors.cantidad ? 'focus:ring-2' : 'focus:ring-2'" />
          <template x-if="errors.cantidad">
            <p class="mt-1 text-sm text-red-500" x-text="errors.cantidad"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Lote asociado</label>
          <select x-model="form.loteId"
                  class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow">
            <option value="">Sin lote</option>
            ${lotesOpts}
          </select>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Proveedor</label>
            <input type="text" x-model="form.proveedor" placeholder="Nombre del proveedor"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Costo</label>
            <input type="number" step="0.01" min="0" x-model="form.costo" placeholder="0.00"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow" />
          </div>
        </div>
      </div>`;
    await UI.modalForm(
      editando ? 'Editar Movimiento' : 'Nuevo Movimiento',
      html,
      async (data) => {
        if (editando) await this.actualizar(descifrado.id, data);
        else await this.guardar(data);
        await this.cargarDatos();
      },
      descifrado
    );
  },

  validarForm(datos) {
    this.errors = {};
    if (!datos.insumoId) {
      this.errors.insumoId = 'Seleccione un insumo';
    }
    if (!datos.tipo) {
      this.errors.tipo = 'Seleccione el tipo de movimiento';
    }
    if (!datos.cantidad || parseFloat(datos.cantidad) <= 0) {
      this.errors.cantidad = 'Ingrese una cantidad v\u00e1lida';
    }
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const cantidad = parseFloat(datos.cantidad) || 0;
      const tipo = datos.tipo;
      const insumoId = datos.insumoId;
      const registro = this._cifrarSensibles({
        id: uuid(),
        insumoId: insumoId,
        tipo: tipo,
        cantidad: cantidad,
        loteId: datos.loteId || null,
        animalId: null,
        proveedor: datos.proveedor?.trim() || '',
        costo: parseFloat(datos.costo) || 0,
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString()
      });
      await db.movimientos_insumo.put(registro);
      if (tipo === 'salida') {
        const insumo = await db.insumos.get(insumoId);
        if (insumo) {
          await db.insumos.update(insumoId, {
            stockActual: Math.max(0, (insumo.stockActual || 0) - cantidad),
            updatedAt: new Date().toISOString()
          });
        }
      } else {
        const insumo = await db.insumos.get(insumoId);
        if (insumo) {
          await db.insumos.update(insumoId, {
            stockActual: (insumo.stockActual || 0) + cantidad,
            updatedAt: new Date().toISOString()
          });
        }
      }
      UI.toast('Movimiento registrado correctamente', 'success');
    } catch (e) {
      console.error('Error al guardar movimiento:', e);
      UI.toast('Error al guardar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const existente = await db.movimientos_insumo.get(id);
      if (!existente) {
        UI.toast('Movimiento no encontrado', 'error');
        return;
      }
      const cantidadAnterior = existente.cantidad || 0;
      const tipoAnterior = existente.tipo;
      const insumoIdAnterior = existente.insumoId;
      const cantidad = parseFloat(datos.cantidad) || 0;
      const tipo = datos.tipo;
      const insumoId = datos.insumoId;

      const actualizado = this._cifrarSensibles({
        ...existente,
        insumoId: insumoId,
        tipo: tipo,
        cantidad: cantidad,
        loteId: datos.loteId || null,
        proveedor: datos.proveedor?.trim() || '',
        costo: parseFloat(datos.costo) || 0
      });
      await db.movimientos_insumo.put(actualizado);

      const revertirStock = async (insId, tip, cant) => {
        const ins = await db.insumos.get(insId);
        if (!ins) return;
        if (tip === 'salida') {
          await db.insumos.update(insId, {
            stockActual: (ins.stockActual || 0) + cant,
            updatedAt: new Date().toISOString()
          });
        } else {
          await db.insumos.update(insId, {
            stockActual: Math.max(0, (ins.stockActual || 0) - cant),
            updatedAt: new Date().toISOString()
          });
        }
      };
      const aplicarStock = async (insId, tip, cant) => {
        const ins = await db.insumos.get(insId);
        if (!ins) return;
        if (tip === 'salida') {
          await db.insumos.update(insId, {
            stockActual: Math.max(0, (ins.stockActual || 0) - cant),
            updatedAt: new Date().toISOString()
          });
        } else {
          await db.insumos.update(insId, {
            stockActual: (ins.stockActual || 0) + cant,
            updatedAt: new Date().toISOString()
          });
        }
      };

      if (insumoIdAnterior !== insumoId || tipoAnterior !== tipo || cantidadAnterior !== cantidad) {
        await revertirStock(insumoIdAnterior, tipoAnterior, cantidadAnterior);
        await aplicarStock(insumoId, tipo, cantidad);
      }

      UI.toast('Movimiento actualizado correctamente', 'success');
    } catch (e) {
      console.error('Error al actualizar movimiento:', e);
      UI.toast('Error al actualizar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar este movimiento?');
    if (!ok) return;
    try {
      const insumo = await db.insumos.get(item.insumoId);
      if (insumo) {
        if (item.tipo === 'entrada') {
          await db.insumos.update(item.insumoId, {
            stockActual: Math.max(0, (insumo.stockActual || 0) - (item.cantidad || 0)),
            updatedAt: new Date().toISOString()
          });
        } else {
          await db.insumos.update(item.insumoId, {
            stockActual: (insumo.stockActual || 0) + (item.cantidad || 0),
            updatedAt: new Date().toISOString()
          });
        }
      }
      await db.movimientos_insumo.delete(item.id);
      UI.toast('Movimiento eliminado correctamente', 'success');
      await this.cargarDatos();
    } catch (e) {
      console.error('Error al eliminar movimiento:', e);
      UI.toast(e.message, 'error');
    }
  },

  async buscar() {
    this.page = 1;
    await this.cargarDatos();
  },

  async limpiarBusqueda() {
    this.searchQuery = '';
    this.page = 1;
    await this.cargarDatos();
  },

  async exportarPDF() {
    if (!this.items.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const { jsPDF } = window.jspdf || {};
      if (!jsPDF) {
        UI.toast('jsPDF no disponible', 'error');
        return;
      }
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text('Movimientos de Insumos', 14, 20);
      doc.setFontSize(10);
      let y = 30;
      doc.text('Insumo', 14, y);
      doc.text('Tipo', 70, y);
      doc.text('Cantidad', 105, y);
      doc.text('Lote', 135, y);
      doc.text('Costo', 175, y);
      y += 6;
      doc.setDrawColor(200);
      doc.line(14, y, 196, y);
      y += 4;
      for (const item of this.items) {
        if (y > 280) { doc.addPage(); y = 20; }
        doc.text(this.nombreInsumo(item.insumoId), 14, y);
        doc.text(item.tipo === 'entrada' ? 'Entrada' : 'Salida', 70, y);
        doc.text(this.formatearCantidad(item), 105, y);
        doc.text(this.nombreLote(item.loteId) || '—', 135, y);
        doc.text(this.formatearCosto(item.costo), 175, y);
        y += 6;
      }
      doc.save('movimientos-insumos.pdf');
      UI.toast('PDF exportado', 'success');
    } catch (e) {
      console.error('Error exportando PDF:', e);
      UI.toast('Error al exportar PDF', 'error');
    }
  },

  async exportarCSV() {
    if (!this.items.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const XLSX = window.XLSX;
      if (XLSX) {
        const ws = XLSX.utils.json_to_sheet(this.items.map(i => ({
          Insumo: this.nombreInsumo(i.insumoId),
          Tipo: i.tipo === 'entrada' ? 'Entrada' : 'Salida',
          Cantidad: this.formatearCantidad(i),
          Lote: this.nombreLote(i.loteId) || '',
          Proveedor: i.proveedor || '',
          Costo: this.formatearCosto(i.costo)
        })));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Movimientos');
        XLSX.writeFile(wb, 'movimientos-insumos.xlsx');
        UI.toast('Excel exportado', 'success');
      } else {
        const cabeceras = ['Insumo', 'Tipo', 'Cantidad', 'Lote', 'Proveedor', 'Costo'];
        const filas = this.items.map(i => [
          this.nombreInsumo(i.insumoId),
          i.tipo === 'entrada' ? 'Entrada' : 'Salida',
          this.formatearCantidad(i),
          this.nombreLote(i.loteId) || '',
          i.proveedor || '',
          this.formatearCosto(i.costo)
        ]);
        let csv = cabeceras.join(',') + '\n';
        for (const fila of filas) {
          csv += fila.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',') + '\n';
        }
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'movimientos-insumos.csv';
        a.click();
        URL.revokeObjectURL(url);
        UI.toast('CSV exportado', 'success');
      }
    } catch (e) {
      console.error('Error exportando:', e);
      UI.toast('Error al exportar', 'error');
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['campo-cosechas'] = ModuloCampoCosechas;

document.addEventListener('alpine:init', () => {
  Alpine.data('campoCosechasData', () => ModuloCampoCosechas);
});
