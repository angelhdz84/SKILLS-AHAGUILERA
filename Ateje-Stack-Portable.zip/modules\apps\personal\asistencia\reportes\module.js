const ModuloAsisReportes = {
  id: 'asis-reportes',
  titulo: 'Reportes',
  icono: 'bi bi-file-earmark-bar-graph-fill',
  items: [],
  loading: true,
  periodo: 'semanal',
  fechaInicio: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10),
  fechaFin: new Date().toISOString().slice(0, 10),
  empleados: [],

  async init() {
    console.log('[' + this.id + '] Inicializando');
    var d = new Date();
    var inicioSemana = new Date(d);
    inicioSemana.setDate(d.getDate() - d.getDay() + 1);
    this.fechaInicio = inicioSemana.toISOString().slice(0, 10);
    this.fechaFin = d.toISOString().slice(0, 10);
    await this.cargar();
  },

  render() {
    if (this.loading) {
      return '<div class="p-4 space-y-3">' +
        '<div class="sk-el sk-heading"></div>' +
        '<div class="flex gap-2"><div class="sk-el" style="width:120px;height:32px"></div><div class="sk-el" style="width:120px;height:32px"></div></div>' +
        '<div class="sk-el sk-row"></div>' +
        '<div class="sk-el sk-row"></div>' +
        '<div class="sk-el sk-row"></div>' +
        '</div>';
    }

    var resumen = this._calcularResumen();
    var totalHoras = resumen.totalHoras;
    var totalRetardos = resumen.totalRetardos;
    var totalFaltas = resumen.totalFaltas;
    var empleadosActivos = resumen.empleadosConDatos;

    var rows = this.items.map(function(r, i) {
      var emp = this.empleados.find(function(e) { return e.id === r.empleadoId; });
      var nombreEmp = emp ? emp.nombre : 'Desconocido';
      var iniciales = (nombreEmp || '??').split(' ').map(function(s) { return s[0]; }).join('').substring(0, 2).toUpperCase();
      var horas = typeof r.totalHoras === 'number' ? r.totalHoras.toFixed(1) : (r.totalHoras || '0');
      var retardos = r.retardos || 0;
      var faltas = r.faltas || 0;
      var rendimiento = this._rendimientoBadge(horas, retardos, faltas);
      return '<tr class="stagger-item" style="animation-delay:' + (i * 0.03) + 's">' +
        '<td><div class="flex items-center gap-2"><div class="avatar placeholder"><div class="w-8 rounded-full bg-purple-100 text-purple-600 text-xs font-bold">' + iniciales + '</div></div>' + this._esc(nombreEmp) + '</div></td>' +
        '<td class="font-semibold">' + horas + 'h</td>' +
        '<td><span class="badge badge-soft badge-warning badge-sm">' + retardos + '</span></td>' +
        '<td><span class="badge badge-soft badge-error badge-sm">' + faltas + '</span></td>' +
        '<td>' + rendimiento + '</td>' +
        '</tr>';
    }.bind(this)).join('');

    return '<div class="p-4">' +
      '<div class="flex flex-wrap items-center justify-between gap-3 mb-4">' +
      '<h2 class="text-xl font-bold flex items-center gap-2"><i class="bi bi-file-earmark-bar-graph-fill text-purple-500"></i> Reportes</h2>' +
      '<div class="flex items-center gap-2">' +
      '<button class="btn btn-outline btn-sm ' + (this.periodo === 'diario' ? 'btn-active' : '') + '" onclick="ModuloAsisReportes._cambiarPeriodo(\'diario\')"><i class="bi bi-calendar-day"></i> Día</button>' +
      '<button class="btn btn-outline btn-sm ' + (this.periodo === 'semanal' ? 'btn-active' : '') + '" onclick="ModuloAsisReportes._cambiarPeriodo(\'semanal\')"><i class="bi bi-calendar-week"></i> Semana</button>' +
      '<button class="btn btn-outline btn-sm ' + (this.periodo === 'mensual' ? 'btn-active' : '') + '" onclick="ModuloAsisReportes._cambiarPeriodo(\'mensual\')"><i class="bi bi-calendar-month"></i> Mes</button>' +
      '</div>' +
      '</div>' +
      '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">' +
      '<div class="card bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 p-4 rounded-xl">' +
      '<p class="kpi-label">Horas totales</p><p class="kpi-value text-purple-600">' + totalHoras.toFixed(1) + '</p>' +
      '<p class="text-xs text-base-content/50 mt-1">' + empleadosActivos + ' empleados</p>' +
      '</div>' +
      '<div class="card bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-4 rounded-xl">' +
      '<p class="kpi-label">Retardos</p><p class="kpi-value text-amber-600">' + totalRetardos + '</p>' +
      '</div>' +
      '<div class="card bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 p-4 rounded-xl">' +
      '<p class="kpi-label">Faltas</p><p class="kpi-value text-red-600">' + totalFaltas + '</p>' +
      '</div>' +
      '</div>' +
      '<div class="flex flex-wrap items-center gap-2 mb-4">' +
      '<label class="form-control max-w-xs">' +
      '<span class="label-text text-xs">Desde</span>' +
      '<input type="date" class="input input-bordered input-sm" value="' + this.fechaInicio + '" onchange="ModuloAsisReportes.fechaInicio=this.value; ModuloAsisReportes.cargar();" />' +
      '</label>' +
      '<label class="form-control max-w-xs">' +
      '<span class="label-text text-xs">Hasta</span>' +
      '<input type="date" class="input input-bordered input-sm" value="' + this.fechaFin + '" onchange="ModuloAsisReportes.fechaFin=this.value; ModuloAsisReportes.cargar();" />' +
      '</label>' +
      '<button class="btn btn-primary btn-sm self-end" onclick="ModuloAsisReportes._exportCSV()"><i class="bi bi-download"></i> Export CSV</button>' +
      '</div>' +
      (this.items.length === 0
        ? '<div class="empty-state"><div class="empty-state-icon bg-purple-100"><i class="bi bi-file-earmark-bar-graph text-purple-500"></i></div><p class="empty-state-title">Sin datos</p><p class="empty-state-desc">No hay registros en el período seleccionado</p></div>'
        : '<div class="overflow-x-auto rounded-box border border-base-200"><table class="table table-sm"><thead><tr><th>Empleado</th><th>Horas</th><th>Retardos</th><th>Faltas</th><th>Rendimiento</th></tr></thead><tbody>' + rows + '</tbody></table></div>') +
      '</div>';
  },

  destroy() {
    this.items = [];
    this.empleados = [];
    this.loading = true;
  },

  async cargar() {
    this.loading = true;
    try {
      if (window.db) {
        this.empleados = db.empleados ? await db.empleados.orderBy('nombre').toArray() : [];
        var reportes = db.reportes ? await db.reportes.toArray() : [];
        var desde = new Date(this.fechaInicio + 'T00:00:00');
        var hasta = new Date(this.fechaFin + 'T23:59:59');
        this.items = reportes.filter(function(r) {
          var rCreated = new Date(r.createdAt);
          return rCreated >= desde && rCreated <= hasta;
        });
        this.items.sort(function(a, b) { return (b.totalHoras || 0) - (a.totalHoras || 0); });
      } else {
        this.empleados = [];
        this.items = [];
      }
    } catch (e) {
      console.error('[' + this.id + '] Error al cargar:', e.message);
      this.items = [];
    }
    this.loading = false;
  },

  _calcularResumen: function() {
    var totalHoras = 0;
    var totalRetardos = 0;
    var totalFaltas = 0;
    var empSet = {};
    this.items.forEach(function(r) {
      totalHoras += typeof r.totalHoras === 'number' ? r.totalHoras : (parseFloat(r.totalHoras) || 0);
      totalRetardos += r.retardos || 0;
      totalFaltas += r.faltas || 0;
      empSet[r.empleadoId] = true;
    });
    return {
      totalHoras: totalHoras,
      totalRetardos: totalRetardos,
      totalFaltas: totalFaltas,
      empleadosConDatos: Object.keys(empSet).length
    };
  },

  _rendimientoBadge: function(horas, retardos, faltas) {
    var h = parseFloat(horas) || 0;
    var r = retardos || 0;
    var f = faltas || 0;
    if (f > 3) return '<span class="badge badge-error badge-sm">Crítico</span>';
    if (r > 5 || f > 0) return '<span class="badge badge-warning badge-sm">Regular</span>';
    if (h >= 40) return '<span class="badge badge-success badge-sm">Óptimo</span>';
    return '<span class="badge badge-ghost badge-sm">Normal</span>';
  },

  _cambiarPeriodo: function(periodo) {
    this.periodo = periodo;
    var hoy = new Date();
    if (periodo === 'diario') {
      this.fechaInicio = hoy.toISOString().slice(0, 10);
      this.fechaFin = hoy.toISOString().slice(0, 10);
    } else if (periodo === 'semanal') {
      var inicio = new Date(hoy);
      inicio.setDate(hoy.getDate() - hoy.getDay() + 1);
      this.fechaInicio = inicio.toISOString().slice(0, 10);
      this.fechaFin = hoy.toISOString().slice(0, 10);
    } else if (periodo === 'mensual') {
      this.fechaInicio = new Date(hoy.getFullYear(), hoy.getMonth(), 1).toISOString().slice(0, 10);
      this.fechaFin = hoy.toISOString().slice(0, 10);
    }
    this.cargar();
  },

  _exportCSV: function() {
    if (this.items.length === 0) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    var csv = '\uFEFFEmpleado,Horas,Retardos,Faltas,Periodo\n';
    this.items.forEach(function(r) {
      var emp = this.empleados.find(function(e) { return e.id === r.empleadoId; });
      var nombre = emp ? emp.nombre : 'Desconocido';
      var horas = typeof r.totalHoras === 'number' ? r.totalHoras.toFixed(1) : (r.totalHoras || '0');
      csv += '"' + nombre + '",' + horas + ',' + (r.retardos || 0) + ',' + (r.faltas || 0) + ',"' + this.fechaInicio + ' - ' + this.fechaFin + '"\n';
    }.bind(this));
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'reporte-asistencia_' + this.fechaInicio + '_' + this.fechaFin + '.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
    UI.toast('CSV exportado', 'success');
  },

  _esc: function(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
};

window.MODULES = window.MODULES || {};
window.MODULES[ModuloAsisReportes.id] = ModuloAsisReportes;

document.addEventListener('alpine:init', function() {
  Alpine.data('asisReportesData', function() { return ModuloAsisReportes; });
});
