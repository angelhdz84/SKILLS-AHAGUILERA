﻿const AHA_REGISTRO = [
  {
    vertical: 'Comercio',
    icono: 'bi bi-shop',
    apps: [
      {
        app: 'POS',
        icono: 'bi bi-cash-register',
        modulos: [
          { id: 'pos-productos',     titulo: 'Productos',   icono: 'bi bi-box-seam',        dataFn: 'posProductosData',   constName: 'ModuloPOSProductos',   ruta: 'apps/comercio/pos/productos' },
          { id: 'pos-ventas',        titulo: 'Ventas',      icono: 'bi bi-cart',            dataFn: 'posVentasData',      constName: 'ModuloPOSVentas',      ruta: 'apps/comercio/pos/ventas' },
          { id: 'pos-corte',         titulo: 'Corte',       icono: 'bi bi-calculator',      dataFn: 'posCorteData',       constName: 'ModuloPOSCorte',       ruta: 'apps/comercio/pos/corte' },
          { id: 'pos-devoluciones',  titulo: 'Devoluciones',icono: 'bi bi-arrow-return-left',dataFn: 'posDevolucionesData',constName: 'ModuloPOSDevoluciones', ruta: 'apps/comercio/pos/devoluciones' },
          { id: 'pos-reportes',      titulo: 'Reportes',    icono: 'bi bi-bar-chart',       dataFn: 'posReportesData',    constName: 'ModuloPOSReportes',    ruta: 'apps/comercio/pos/reportes' },
        ]
      },
      {
        app: 'Inventario',
        icono: 'bi bi-boxes',
        modulos: [
          { id: 'inv-productos',    titulo: 'Productos',   icono: 'bi bi-box-seam',       dataFn: 'invProductosData',   constName: 'ModuloInvProductos',   ruta: 'apps/comercio/inventario/productos' },
          { id: 'inv-movimientos',  titulo: 'Movimientos', icono: 'bi bi-arrow-left-right',dataFn: 'invMovimientosData', constName: 'ModuloInvMovimientos', ruta: 'apps/comercio/inventario/movimientos' },
          { id: 'inv-reportes',     titulo: 'Reportes',    icono: 'bi bi-graph-up',       dataFn: 'invReportesData',    constName: 'ModuloInvReportes',    ruta: 'apps/comercio/inventario/reportes' },
          { id: 'inv-ajustes',      titulo: 'Alertas',     icono: 'bi bi-bell',           dataFn: 'invAjustesData',     constName: 'ModuloInvAjustes',     ruta: 'apps/comercio/inventario/ajustes' },
        ]
      }
    ]
  },
  {
    vertical: 'Belleza',
    icono: 'bi bi-scissors',
    apps: [
      {
        app: 'Citas',
        icono: 'bi bi-calendar-check',
        modulos: [
          { id: 'citas-agenda',      titulo: 'Agenda',      icono: 'bi bi-calendar-check',  dataFn: 'citasAgendaData',      constName: 'ModuloCitasAgenda',      ruta: 'apps/belleza/citas/agenda' },
          { id: 'citas-calendario',  titulo: 'Calendario',  icono: 'bi bi-calendar-month',  dataFn: 'citasCalendarioData',  constName: 'ModuloCitasCalendario',  ruta: 'apps/belleza/citas/calendario' },
          { id: 'citas-clientes',    titulo: 'Clientes',    icono: 'bi bi-people',          dataFn: 'citasClientesData',    constName: 'ModuloCitasClientes',    ruta: 'apps/belleza/citas/clientes' },
          { id: 'citas-servicios',   titulo: 'Servicios',   icono: 'bi bi-scissors',        dataFn: 'citasServiciosData',   constName: 'ModuloCitasServicios',   ruta: 'apps/belleza/citas/servicios' },
        ]
      }
    ]
  },
  {
    vertical: 'Finanzas',
    icono: 'bi bi-currency-dollar',
    apps: [
      {
        app: 'Gastos',
        icono: 'bi bi-wallet2',
        modulos: [
          { id: 'gastos-dashboard',   titulo: 'Dashboard',    icono: 'bi bi-speedometer2',       dataFn: 'gastosDashboardData',   constName: 'ModuloGastosDashboard',   ruta: 'apps/finanzas/gastos/presupuestos' },
          { id: 'gastos-movimientos', titulo: 'Movimientos',  icono: 'bi bi-arrow-left-right',    dataFn: 'gastosMovimientosData', constName: 'ModuloGastosMovimientos', ruta: 'apps/finanzas/gastos/transacciones' },
          { id: 'gastos-categorias',  titulo: 'Categor\u00edas',icono: 'bi bi-tags',              dataFn: 'gastosCategoriasData',  constName: 'ModuloGastosCategorias',  ruta: 'apps/finanzas/gastos/categorias' },
          { id: 'gastos-reportes',    titulo: 'Reportes',     icono: 'bi bi-graph-up',            dataFn: 'gastosReportesData',    constName: 'ModuloGastosReportes',    ruta: 'apps/finanzas/gastos/reportes' },
        ]
      },
      {
        app: 'PreFactura',
        icono: 'bi bi-file-earmark-text',
        modulos: [
          { id: 'pf-clientes',       titulo: 'Clientes',     icono: 'bi bi-building',            dataFn: 'pfClientesData',       constName: 'ModuloPFClientes',       ruta: 'apps/finanzas/prefactura/clientes' },
          { id: 'pf-productos',      titulo: 'Productos',    icono: 'bi bi-box',                 dataFn: 'pfProductosData',      constName: 'ModuloPFProductos',      ruta: 'apps/finanzas/prefactura/cotizaciones' },
          { id: 'pf-facturas',       titulo: 'Facturas',     icono: 'bi bi-file-earmark-text',    dataFn: 'pfFacturasData',       constName: 'ModuloPFFacturas',       ruta: 'apps/finanzas/prefactura/facturas' },
          { id: 'pf-reportes',       titulo: 'Reportes',     icono: 'bi bi-graph-up',            dataFn: 'pfReportesData',       constName: 'ModuloPFReportes',       ruta: 'apps/finanzas/prefactura/plantillas' },
        ]
      }
    ]
  },
  {
    vertical: 'Oficina',
    icono: 'bi bi-briefcase',
    apps: [
      {
        app: 'Contactos',
        icono: 'bi bi-person-lines-fill',
        modulos: [
          { id: 'ctc-directorio',   titulo: 'Directorio',    icono: 'bi bi-person-lines-fill', dataFn: 'ctcDirectorioData',   constName: 'ModuloContactosDirectorio',   ruta: 'apps/oficina/contactos/directorio' },
          { id: 'ctc-etiquetas',    titulo: 'Plantillas',    icono: 'bi bi-chat-dots',         dataFn: 'ctcEtiquetasData',    constName: 'ModuloContactosEtiquetas',    ruta: 'apps/oficina/contactos/etiquetas' },
          { id: 'ctc-grupos',       titulo: 'Recordatorios', icono: 'bi bi-alarm',             dataFn: 'ctcGruposData',       constName: 'ModuloContactosGrupos',       ruta: 'apps/oficina/contactos/grupos' },
        ]
      },
      {
        app: 'CRM',
        icono: 'bi bi-kanban',
        modulos: [
          { id: 'crm-contactos',     titulo: 'Contactos',     icono: 'bi bi-people',            dataFn: 'crmContactosData',    constName: 'ModuloCRMContactos',    ruta: 'apps/oficina/crm/contactos' },
          { id: 'crm-pipeline',      titulo: 'Pipeline',      icono: 'bi bi-kanban',            dataFn: 'crmPipelineData',     constName: 'ModuloCRMPipeline',     ruta: 'apps/oficina/crm/pipeline' },
          { id: 'crm-cotizaciones',  titulo: 'Cotizaciones',  icono: 'bi bi-file-text',         dataFn: 'crmCotizacionesData', constName: 'ModuloCRMCotizaciones', ruta: 'apps/oficina/crm/cotizaciones' },
          { id: 'crm-facturacion',   titulo: 'Facturaci\u00f3n', icono: 'bi bi-receipt',         dataFn: 'crmFacturacionData',  constName: 'ModuloCRMFacturacion',  ruta: 'apps/oficina/crm/facturacion' },
        ]
      }
    ]
  },
  {
    vertical: 'Gastronom\u00eda',
    icono: 'bi bi-cup-hot',
    apps: [
      {
        app: 'Comanda',
        icono: 'bi bi-receipt',
        modulos: [
          { id: 'com-mesas',      titulo: 'Mesas',      icono: 'bi bi-grid-3x3-gap',      dataFn: 'comMesasData',      constName: 'ModuloComandaMesas',      ruta: 'apps/gastronomia/comanda/mesas' },
          { id: 'com-pedidos',    titulo: 'Pedidos',    icono: 'bi bi-basket',             dataFn: 'comPedidosData',    constName: 'ModuloComandaPedidos',    ruta: 'apps/gastronomia/comanda/pedidos' },
          { id: 'com-menu',       titulo: 'Men\u00fa', icono: 'bi bi-book',               dataFn: 'comMenuData',       constName: 'ModuloComandaMenu',       ruta: 'apps/gastronomia/comanda/menu' },
          { id: 'com-cuentas',    titulo: 'Cuentas',    icono: 'bi bi-calculator',         dataFn: 'comCuentasData',    constName: 'ModuloComandaCuentas',    ruta: 'apps/gastronomia/comanda/cuentas' },
        ]
      }
    ]
  },
  {
    vertical: 'Salud',
    icono: 'bi bi-heart-pulse',
    apps: [
      {
        app: 'Rx',
        icono: 'bi bi-file-earmark-text',
        modulos: [
          { id: 'rx-pacientes',    titulo: 'Pacientes',   icono: 'bi bi-people',              dataFn: 'rxPacientesData',    constName: 'ModuloRxPacientes',    ruta: 'apps/salud/rx/pacientes' },
          { id: 'rx-medicamentos', titulo: 'Medicamentos', icono: 'bi bi-capsule',             dataFn: 'rxMedicamentosData', constName: 'ModuloRxMedicamentos', ruta: 'apps/salud/rx/medicamentos' },
          { id: 'rx-recetas',      titulo: 'Recetas',      icono: 'bi bi-file-text',           dataFn: 'rxRecetasData',      constName: 'ModuloRxRecetas',      ruta: 'apps/salud/rx/recetas' },
          { id: 'rx-historial',    titulo: 'Historial',    icono: 'bi bi-clock-history',       dataFn: 'rxHistorialData',    constName: 'ModuloRxHistorial',    ruta: 'apps/salud/rx/historial' },
        ]
      }
    ]
  },
  {
    vertical: 'Campo',
    icono: 'bi bi-tree',
    apps: [
      {
        app: 'Campo',
        icono: 'bi bi-flower1',
        modulos: [
          { id: 'campo-lotes',     titulo: 'Lotes',       icono: 'bi bi-grid-3x3-gap',        dataFn: 'campoLotesData',     constName: 'ModuloCampoLotes',     ruta: 'apps/campo/campo-app/lotes' },
          { id: 'campo-cultivos',  titulo: 'Cultivos',    icono: 'bi bi-flower1',             dataFn: 'campoCultivosData',  constName: 'ModuloCampoCultivos',  ruta: 'apps/campo/campo-app/cultivos' },
          { id: 'campo-insumos',   titulo: 'Insumos',     icono: 'bi bi-box-seam',            dataFn: 'campoInsumosData',   constName: 'ModuloCampoInsumos',   ruta: 'apps/campo/campo-app/insumos' },
          { id: 'campo-cosechas',  titulo: 'Cosechas',    icono: 'bi bi-basket3',             dataFn: 'campoCosechasData',  constName: 'ModuloCampoCosechas',  ruta: 'apps/campo/campo-app/cosechas' },
        ]
      }
    ]
  },
  {
    vertical: 'Construcci\u00f3n',
    icono: 'bi bi-building',
    apps: [
      {
        app: 'Checklist',
        icono: 'bi bi-check2-square',
        modulos: [
          { id: 'chk-plantillas',  titulo: 'Plantillas',  icono: 'bi bi-file-earmark',       dataFn: 'chkPlantillasData',  constName: 'ModuloChkPlantillas',  ruta: 'apps/construccion/checklist/plantillas' },
          { id: 'chk-listas',      titulo: 'Ubicaciones', icono: 'bi bi-geo-alt',             dataFn: 'chkListasData',      constName: 'ModuloChkListas',      ruta: 'apps/construccion/checklist/listas' },
          { id: 'chk-items',       titulo: 'Equipos',     icono: 'bi bi-tools',               dataFn: 'chkItemsData',       constName: 'ModuloChkItems',       ruta: 'apps/construccion/checklist/items' },
          { id: 'chk-reportes',    titulo: 'Reportes',    icono: 'bi bi-bar-chart',           dataFn: 'chkReportesData',    constName: 'ModuloChkReportes',    ruta: 'apps/construccion/checklist/reportes' },
        ]
      },
      {
        app: 'Obra',
        icono: 'bi bi-cone-striped',
        modulos: [
          { id: 'obra-dashboard',  titulo: 'Dashboard',   icono: 'bi bi-speedometer2',        dataFn: 'obraDashboardData',  constName: 'ModuloObraDashboard',  ruta: 'apps/construccion/obra/dashboard-obra' },
          { id: 'obra-etapas',     titulo: 'Etapas',      icono: 'bi bi-layers',             dataFn: 'obraEtapasData',     constName: 'ModuloObraEtapas',     ruta: 'apps/construccion/obra/etapas' },
          { id: 'obra-materiales', titulo: 'Materiales',  icono: 'bi bi-boxes',               dataFn: 'obraMaterialesData', constName: 'ModuloObraMateriales', ruta: 'apps/construccion/obra/materiales' },
          { id: 'obra-personal',   titulo: 'Personal',    icono: 'bi bi-people',              dataFn: 'obraPersonalData',   constName: 'ModuloObraPersonal',   ruta: 'apps/construccion/obra/personal' },
          { id: 'obra-reportes',   titulo: 'Reportes',    icono: 'bi bi-graph-up',            dataFn: 'obraReportesData',   constName: 'ModuloObraReportes',   ruta: 'apps/construccion/obra/reportes' },
        ]
      }
    ]
  },
  {
    vertical: 'Log\u00edstica',
    icono: 'bi bi-truck',
    apps: [
      {
        app: 'Flota',
        icono: 'bi bi-truck',
        modulos: [
          { id: 'flota-vehiculos',     titulo: 'Veh\u00edculos',   icono: 'bi bi-truck',             dataFn: 'flotaVehiculosData',     constName: 'ModuloFlotaVehiculos',     ruta: 'apps/logistica/flota/vehiculos' },
          { id: 'flota-combustible',   titulo: 'Combustible',      icono: 'bi bi-fuel-pump',         dataFn: 'flotaCombustibleData',   constName: 'ModuloFlotaCombustible',   ruta: 'apps/logistica/flota/combustible' },
          { id: 'flota-mantenimiento', titulo: 'Mantenimiento',    icono: 'bi bi-wrench',            dataFn: 'flotaMantenimientoData', constName: 'ModuloFlotaMantenimiento', ruta: 'apps/logistica/flota/mantenimiento' },
          { id: 'flota-rutas',         titulo: 'Incidentes',       icono: 'bi bi-exclamation-triangle',dataFn: 'flotaRutasData',       constName: 'ModuloFlotaRutas',         ruta: 'apps/logistica/flota/rutas' },
        ]
      }
    ]
  },
  {
    vertical: 'Personal',
    icono: 'bi bi-person-badge',
    apps: [
      {
        app: 'Asistencia',
        icono: 'bi bi-clock',
        modulos: [
          { id: 'asis-personal',  titulo: 'Empleados',  icono: 'bi bi-people',             dataFn: 'asisPersonalData',  constName: 'ModuloAsisPersonal',  ruta: 'apps/personal/asistencia/personal' },
          { id: 'asis-checkin',   titulo: 'Marcaje',    icono: 'bi bi-fingerprint',        dataFn: 'asisCheckinData',   constName: 'ModuloAsisCheckin',   ruta: 'apps/personal/asistencia/checkin' },
          { id: 'asis-reportes',  titulo: 'Reportes',   icono: 'bi bi-graph-up',           dataFn: 'asisReportesData',  constName: 'ModuloAsisReportes',  ruta: 'apps/personal/asistencia/reportes' },
        ]
      }
    ]
  },
  {
    vertical: 'IA',
    icono: 'bi bi-robot',
    apps: [
      {
        app: 'Jutia',
        icono: 'bi bi-cpu',
        modulos: [
          { id: 'ia-busqueda',  titulo: 'B\u00fasqueda', icono: 'bi bi-search',              dataFn: 'iaBusquedaData',  constName: 'ModuloIaBusqueda',  ruta: 'apps/ia/ia-jutia/busqueda' },
          { id: 'ia-chat',      titulo: 'Chat IA',       icono: 'bi bi-chat-dots',           dataFn: 'iaChatData',      constName: 'ModuloIaChat',      ruta: 'apps/ia/ia-jutia/chat' },
          { id: 'ia-ocr',       titulo: 'OCR',           icono: 'bi bi-file-earmark-image', dataFn: 'iaOcrData',       constName: 'ModuloIaOcr',       ruta: 'apps/ia/ia-jutia/ocr' },
        ]
      }
    ]
  }
];
