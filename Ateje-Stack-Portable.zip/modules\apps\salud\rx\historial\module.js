const ModuloRxHistorial = {
  id: 'rx-historial',
  titulo: 'Historial',
  icono: 'bi bi-clock-history',

  items: [],
  loading: true,
  pacienteSeleccionado: null,
  pacientes: [],

  async init() {
    await this.cargarPacientes();
    await this.cargar();
  },

  render() {
    return `
      <div x-data="rxHistorialData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-blue-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-clock-history text-blue-600"></i> Historial Clínico
          </h2>
        </div>
        <div class="mb-4">
          <label class="block text-sm font-medium text-gray-700 mb-1">Seleccionar paciente</label>
          <select x-model="pacienteSeleccionado" @change="cargar()" class="w-full max-w-md px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">— Todos los pacientes —</option>
            <template x-for="p in pacientes" :key="p.id">
              <option :value="p.id" x-text="p.nombre"></option>
            </template>
          </select>
        </div>
        <template x-if="loading">
          <div class="space-y-3"><template x-for="i in 4" :key="i"><div class="h-24 bg-gray-100 rounded-lg animate-pulse"></div></template></div>
        </template>
        <template x-if="!loading && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-clock-history text-6xl mb-4"></i>
            <p class="text-lg text-gray-500">Sin historial</p>
            <p class="text-sm text-gray-400 mt-1">No hay recetas registradas para este paciente</p>
          </div>
        </template>
        <template x-if="!loading && items.length > 0">
          <div class="relative">
            <div class="absolute left-4 top-2 bottom-2 w-0.5 bg-blue-200 rounded-full"></div>
            <div class="space-y-6">
              <template x-for="(item, idx) in items" :key="item.id">
                <div class="relative pl-10">
                  <div class="absolute left-2.5 top-1.5 w-3 h-3 rounded-full border-2"
                       :class="idx === 0 ? 'bg-blue-500 border-blue-500' : 'bg-white border-blue-400'">
                  </div>
                  <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow">
                    <div class="flex items-start justify-between gap-3 mb-2">
                      <div>
                        <h3 class="font-semibold text-gray-900" x-text="item.pacienteNombre"></h3>
                        <p class="text-xs text-gray-400" x-text="new Date(item.createdAt).toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })"></p>
                      </div>
                      <button class="text-gray-400 hover:text-blue-600 p-1" @click="verDetalle(item)" title="Ver detalle"><i class="bi bi-eye"></i></button>
                    </div>
                    <p x-show="item.diagnostico" class="text-sm text-gray-600 mb-2">
                      <span class="font-medium text-gray-700">Diagnóstico:</span> <span x-text="item.diagnostico"></span>
                    </p>
                    <div class="flex flex-wrap gap-1.5 mb-1">
                      <template x-for="m in (item.medicamentos || [])" :key="m.id">
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded-full">
                          <i class="bi bi-capsule"></i>
                          <span x-text="m.nombreMedicamento || '—'"></span>
                          <span x-show="m.dosis" class="text-blue-400" x-text="m.dosis"></span>
                        </span>
                      </template>
                    </div>
                    <p x-show="item.indicaciones" class="text-xs text-gray-400 italic mt-1" x-text="'Indicaciones: ' + item.indicaciones"></p>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </template>
      </div>`;
  },

  destroy() { this.items = []; this.loading = true; this.pacienteSeleccionado = null; this.pacientes = []; },

  async cargarPacientes() {
    try {
      this.pacientes = await db.pacientes.orderBy('nombre').toArray();
    } catch (e) {
      console.error(e);
    }
  },

  async cargar() {
    try {
      this.loading = true;
      let recetas;
      if (this.pacienteSeleccionado) {
        recetas = await db.recetas.where('pacienteId').equals(this.pacienteSeleccionado).reverse().sortBy('createdAt');
      } else {
        recetas = await db.recetas.orderBy('createdAt').reverse().toArray();
      }
      const pacientes = await db.pacientes.toArray();
      const mapaPacientes = {};
      pacientes.forEach(p => { mapaPacientes[p.id] = p; });
      const medicamentos = await db.medicamentos.toArray();
      const mapaMeds = {};
      medicamentos.forEach(m => { mapaMeds[m.id] = m; });
      this.items = [];
      for (const r of recetas) {
        const items = await db.recetas_items.where('recetaId').equals(r.id).toArray();
        this.items.push({
          ...r,
          pacienteNombre: mapaPacientes[r.pacienteId]?.nombre || '—',
          medicamentos: items.map(i => ({
            ...i,
            nombreMedicamento: mapaMeds[i.medicamentoId]?.nombre || '—',
            presentacion: mapaMeds[i.medicamentoId]?.presentacion || ''
          }))
        });
      }
    } catch (e) {
      console.error(e);
      UI.toast('Error al cargar historial', 'error');
    } finally {
      this.loading = false;
    }
  },

  async verDetalle(item) {
    const paciente = await db.pacientes.get(item.pacienteId);
    const meds = item.medicamentos || [];

    let medsHtml = '';
    meds.forEach(m => {
      medsHtml += '<div class="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-lg">' +
        '<div><span class="font-medium text-gray-800">' + (m.nombreMedicamento || '—') + '</span>' +
        (m.presentacion ? '<span class="text-xs text-gray-400 ml-2">' + m.presentacion + '</span>' : '') +
        '</div>' +
        '<div class="text-right"><span class="text-sm font-medium text-blue-700">' + (m.dosis || '—') + '</span>' +
        (m.indicacion ? '<p class="text-xs text-gray-500">' + m.indicacion + '</p>' : '') +
        '</div></div>';
    });

    const html = '<div class="space-y-4">' +
      '<div class="grid grid-cols-2 gap-4"><div><span class="text-xs text-gray-400 uppercase tracking-wider">Paciente</span><p class="font-semibold text-gray-900">' + (paciente?.nombre || '—') + '</p></div>' +
      '<div><span class="text-xs text-gray-400 uppercase tracking-wider">Fecha</span><p class="font-semibold text-gray-900">' + (item.createdAt ? new Date(item.createdAt).toLocaleDateString() : '—') + '</p></div></div>' +
      (item.diagnostico ? '<div><span class="text-xs text-gray-400 uppercase tracking-wider">Diagnóstico</span><p class="text-gray-700">' + item.diagnostico + '</p></div>' : '') +
      (item.indicaciones ? '<div><span class="text-xs text-gray-400 uppercase tracking-wider">Indicaciones</span><p class="text-gray-700">' + item.indicaciones + '</p></div>' : '') +
      (item.proximaCita ? '<div><span class="text-xs text-gray-400 uppercase tracking-wider">Próxima cita</span><p class="font-medium text-blue-700">' + new Date(item.proximaCita).toLocaleDateString() + '</p></div>' : '') +
      (medsHtml ? '<div><span class="text-xs text-gray-400 uppercase tracking-wider mb-2 block">Medicamentos recetados</span><div class="space-y-2">' + medsHtml + '</div></div>' : '') +
      '</div>';

    await UI.modalForm('Detalle de Consulta', html, async () => {});
  }
};
window.MODULES = window.MODULES || {};
window.MODULES[ModuloRxHistorial.id] = ModuloRxHistorial;
document.addEventListener('alpine:init', () => { Alpine.data('rxHistorialData', () => ModuloRxHistorial); });
