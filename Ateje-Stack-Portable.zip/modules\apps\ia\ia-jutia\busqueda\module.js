// modules/apps/ia/ia-jutia/busqueda/module.js — Búsqueda IA
// Barra de búsqueda + resultados agrupados + historial de consultas
// Dependencias: window.db, window.ia (FlexSearch), Alpine.js

;(function () {
  'use strict';

  var HISTORIAL_KEY = 'ia-busqueda-historial';
  var MAX_HISTORIAL = 10;
  var COLOR_INDIGO = 'indigo';

  function getHistorial() {
    try {
      return JSON.parse(localStorage.getItem(HISTORIAL_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function guardarHistorial(h) {
    try {
      localStorage.setItem(HISTORIAL_KEY, JSON.stringify(h.slice(0, MAX_HISTORIAL)));
    } catch (e) {}
  }

  var ModuloIaBusqueda = {
    id: 'ia-busqueda',
    titulo: 'Búsqueda IA',
    icono: 'bi bi-search',
    color: COLOR_INDIGO,

    items: [],
    loading: false,
    query: '',
    resultados: [],
    buscando: false,
    historial: [],
    tablaFiltro: '',
    tablasDisponibles: [],

    async init() {
      this.historial = getHistorial();
      this.tablasDisponibles = await this._detectarTablas();
      this.loading = false;
    },

    async _detectarTablas() {
      if (!window.db) return [];
      return Object.keys(window.db).filter(function (k) {
        return !k.startsWith('_') && typeof window.db[k].toArray === 'function';
      });
    },

    async buscar() {
      var q = this.query.trim();
      if (!q) return;
      this.buscando = true;
      this.resultados = [];

      try {
        if (window.ia && window.ia._flex) {
          var flexResults = await window.ia.search(q, { limit: 30 });
          this.resultados = this._agrupar(flexResults);
        } else {
          this.resultados = await this._busquedaLocal(q);
        }

        this._agregarHistorial(q);
      } catch (e) {
        console.warn('[ia-busqueda] Error:', e);
        this.resultados = [];
      } finally {
        this.buscando = false;
      }
    },

    _agrupar(results) {
      var grupos = {};
      for (var i = 0; i < results.length; i++) {
        var r = results[i];
        var t = r.tabla || 'general';
        if (this.tablaFiltro && t !== this.tablaFiltro) continue;
        if (!grupos[t]) grupos[t] = [];
        grupos[t].push(r);
      }
      var arr = [];
      for (var key in grupos) {
        arr.push({ tabla: key, items: grupos[key] });
      }
      arr.sort(function (a, b) { return b.items.length - a.items.length; });
      return arr;
    },

    async _busquedaLocal(q) {
      if (!window.db) return [];
      var lower = q.toLowerCase();
      var tablas = this.tablaFiltro
        ? [this.tablaFiltro]
        : this.tablasDisponibles;
      var results = [];

      for (var t = 0; t < tablas.length; t++) {
        var nombre = tablas[t];
        try {
          var rows = await window.db[nombre].toArray();
          for (var r = 0; r < rows.length; r++) {
            var row = rows[r];
            var texto = JSON.stringify(row).toLowerCase();
            if (texto.includes(lower)) {
              results.push({
                id: nombre + '-' + (row.id || r),
                nombre: row.nombre || row.titulo || row.name || '',
                descripcion: row.descripcion || row.desc || '',
                tabla: nombre,
                item: row
              });
            }
          }
        } catch (e) {}
      }
      return this._agrupar(results);
    },

    _agregarHistorial(q) {
      this.historial = this.historial.filter(function (h) { return h !== q; });
      this.historial.unshift(q);
      if (this.historial.length > MAX_HISTORIAL) this.historial.length = MAX_HISTORIAL;
      guardarHistorial(this.historial);
    },

    limpiarHistorial() {
      this.historial = [];
      localStorage.removeItem(HISTORIAL_KEY);
    },

    seleccionarHistorial(q) {
      this.query = q;
      this.buscar();
    },

    limpiar() {
      this.query = '';
      this.resultados = [];
    },

    render() {
      return '<div x-data="iaBusquedaData" class="p-4 max-w-4xl mx-auto">' +
        '<div class="flex items-center gap-3 mb-6">' +
          '<div class="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400">' +
            '<i class="bi bi-search text-lg"></i>' +
          '</div>' +
          '<div>' +
            '<h2 class="text-xl font-bold">Búsqueda IA</h2>' +
            '<p class="text-sm text-base-content/60">Busca en todos los datos de la app</p>' +
          '</div>' +
        '</div>' +

        '<div class="card bg-base-100 shadow-sm border border-base-200 mb-4">' +
          '<div class="card-body p-4">' +
            '<div class="flex flex-col sm:flex-row gap-3">' +
              '<div class="join flex-1">' +
                '<input type="search" x-model="query" @keydown.enter="buscar()" placeholder="Escribe tu búsqueda..." ' +
                  'class="input input-bordered join-item flex-1" />' +
                '<button class="btn btn-primary join-item" @click="buscar()" :disabled="!query.trim() || buscando">' +
                  '<template x-if="!buscando"><i class="bi bi-search"></i></template>' +
                  '<template x-if="buscando"><span class="loading loading-spinner loading-sm"></span></template>' +
                  ' Buscar' +
                '</button>' +
              '</div>' +
              '<button class="btn btn-ghost btn-sm" @click="limpiar()" x-show="query || resultados.length" title="Limpiar">' +
                '<i class="bi bi-x-lg"></i>' +
              '</button>' +
            '</div>' +

            '<div class="flex flex-wrap gap-2 mt-3" x-show="tablasDisponibles.length > 0">' +
              '<button class="btn btn-xs" :class="tablaFiltro === \'\' ? \'btn-primary\' : \'btn-ghost\'" @click="tablaFiltro = \'\'; limpiar()">Todas</button>' +
              '<template x-for="t in tablasDisponibles" :key="t">' +
                '<button class="btn btn-xs" :class="tablaFiltro === t ? \'btn-primary\' : \'btn-ghost\'" ' +
                  '@click="tablaFiltro = t; limpiar()" x-text="t"></button>' +
              '</template>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<template x-if="buscando">' +
          '<div class="flex items-center justify-center py-12">' +
            '<span class="loading loading-spinner loading-lg text-indigo-500"></span>' +
          '</div>' +
        '</template>' +

        '<template x-if="!buscando && resultados.length > 0">' +
          '<div class="space-y-4">' +
            '<template x-for="grupo in resultados" :key="grupo.tabla">' +
              '<div class="card bg-base-100 shadow-sm border border-base-200">' +
                '<div class="card-body p-4">' +
                  '<h3 class="font-semibold text-sm uppercase tracking-wider text-base-content/60 mb-2" x-text="grupo.tabla"></h3>' +
                  '<div class="divide-y divide-base-200">' +
                    '<template x-for="item in grupo.items" :key="item.id">' +
                      '<div class="py-2 flex items-start gap-3 hover:bg-base-200/50 rounded-lg px-2 -mx-2 transition-colors">' +
                        '<i class="bi bi-file-text text-base-content/40 mt-1"></i>' +
                        '<div class="min-w-0 flex-1">' +
                          '<p class="font-medium text-sm truncate" x-text="item.nombre || \'(sin nombre)\'"></p>' +
                          '<p class="text-xs text-base-content/50 truncate" x-show="item.descripcion" x-text="item.descripcion"></p>' +
                        '</div>' +
                      '</div>' +
                    '</template>' +
                  '</div>' +
                '</div>' +
              '</div>' +
            '</template>' +
          '</div>' +
        '</template>' +

        '<template x-if="!buscando && query && resultados.length === 0">' +
          '<div class="flex flex-col items-center justify-center py-16 text-base-content/40">' +
            '<i class="bi bi-search text-5xl mb-3"></i>' +
            '<p class="text-lg font-medium">Sin resultados</p>' +
            '<p class="text-sm">No se encontraron datos para "<span x-text="query"></span>"</p>' +
          '</div>' +
        '</template>' +

        '<template x-if="!buscando && !query">' +
          '<div class="mt-4">' +
            '<div class="flex items-center justify-between mb-3">' +
              '<h3 class="text-sm font-semibold uppercase tracking-wider text-base-content/50">Historial de búsquedas</h3>' +
              '<button class="btn btn-ghost btn-xs text-error" @click="limpiarHistorial()" x-show="historial.length > 0">' +
                '<i class="bi bi-trash3"></i> Limpiar' +
              '</button>' +
            '</div>' +
            '<template x-if="historial.length === 0">' +
              '<p class="text-sm text-base-content/40 py-8 text-center">Aún no has realizado búsquedas</p>' +
            '</template>' +
            '<template x-for="h in historial" :key="h">' +
              '<button class="btn btn-ghost btn-sm w-full justify-start text-left mb-1 normal-case font-normal" @click="seleccionarHistorial(h)">' +
                '<i class="bi bi-clock-history text-base-content/40 mr-2"></i> <span x-text="h"></span>' +
              '</button>' +
            '</template>' +
          '</div>' +
        '</template>' +
      '</div>';
    },

    destroy() {
      this.items = [];
      this.resultados = [];
      this.loading = true;
      this.query = '';
      this.buscando = false;
    }
  };

  window.MODULES = window.MODULES || {};
  window.MODULES[ModuloIaBusqueda.id] = ModuloIaBusqueda;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      if (typeof Alpine !== 'undefined') {
        Alpine.data('iaBusquedaData', function () { return ModuloIaBusqueda; });
      }
    });
  } else {
    if (typeof Alpine !== 'undefined') {
      Alpine.data('iaBusquedaData', function () { return ModuloIaBusqueda; });
    }
  }
})();
