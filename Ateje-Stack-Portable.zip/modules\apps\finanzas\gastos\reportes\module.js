const ModuloGastosReportes = {
  id: 'gastos-reportes',
  titulo: 'Reportes',
  icono: 'bi bi-graph-up',

  loading: true,
  periodos: [],
  resumen: { totalIngresos: 0, totalEgresos: 0, promedioMes: 0 },
  chartInstance: null,

  async init() {
    await this.cargar();
    this.$nextTick(() => {
      const el = this.$el?.querySelector('#chartFlujo');
      if (el) setTimeout(() => this.renderChart(el), 100);
    });
  },

  render() {
    return `
      <div x-data="gastosReportesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-violet-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-graph-up text-violet-600"></i> Reportes
          </h2>
        </div>

        <template x-if="loading">
          <div class="space-y-4">
            <div class="grid grid-cols-3 gap-4"><template x-for="i in 3" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-3 w-16 bg-gray-200 animate-pulse mb-2"></div><div class="h-7 w-24 bg-gray-200 animate-pulse"></div></div></template></div>
            <div class="bg-white rounded-xl border border-gray-200 p-4 h-64"><div class="h-full bg-gray-200 rounded animate-pulse"></div></div>
          </div>
        </template>

        <template x-if="!loading">
          <div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total ingresos</p><p class="text-2xl font-bold text-green-600" x-text="formatearMoneda(resumen.totalIngresos)"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total egresos</p><p class="text-2xl font-bold text-red-600" x-text="formatearMoneda(resumen.totalEgresos)"></p></div>
              <div class="bg-white rounded-xl border border-gray-200 p-4"><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Promedio mensual</p><p class="text-2xl font-bold text-violet-600" x-text="formatearMoneda(resumen.promedioMes)"></p></div>
            </div>

            <div class="bg-white rounded-xl border border-gray-200 p-4 mb-6">
              <h3 class="font-semibold text-gray-900 mb-3 text-sm flex items-center gap-2"><i class="bi bi-bar-chart-fill text-violet-600"></i> Flujo de caja por mes</h3>
              <canvas id="chartFlujo" class="max-h-72"></canvas>
            </div>

            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden mb-6">
              <div class="overflow-x-auto">
                <table class="w-full text-sm">
                  <thead class="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Mes</th>
                      <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Ingresos</th>
                      <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Egresos</th>
                      <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Saldo</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-gray-100">
                    <template x-for="p in periodos" :key="p.mes">
                      <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-4 py-3 font-medium text-gray-900" x-text="p.mes"></td>
                        <td class="px-4 py-3 text-right text-green-600 font-mono" x-text="formatearMoneda(p.ingresos)"></td>
                        <td class="px-4 py-3 text-right text-red-600 font-mono" x-text="formatearMoneda(p.egresos)"></td>
                        <td class="px-4 py-3 text-right font-mono font-bold" :class="p.saldo >= 0 ? 'text-violet-600' : 'text-red-600'" x-text="formatearMoneda(p.saldo)"></td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="flex gap-2">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-violet-600 text-white text-sm font-medium rounded-lg hover:bg-violet-700 transition-colors shadow-sm" @click="exportarCSV">
                <i class="bi bi-download"></i> Exportar CSV
              </button>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.loading = true; this.periodos = []; this.resumen = { totalIngresos: 0, totalEgresos: 0, promedioMes: 0 };
    if (this.chartInstance) { this.chartInstance.destroy(); this.chartInstance = null; }
  },

  formatearMoneda(v) { if (v == null || isNaN(v)) return '$0.00'; return '$' + Number(v).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); },

  async cargar() {
    try {
      this.loading = true;
      const movs = await db.movimientos.toArray();
      const mapa = {};
      let ti = 0, te = 0;
      for (const m of movs) {
        const monto = Number(m.monto || 0);
        const fecha = m.fecha || m.createdAt || '';
        const mes = fecha.slice(0, 7);
        if (!mes) continue;
        if (!mapa[mes]) mapa[mes] = { mes, ingresos: 0, egresos: 0, saldo: 0, count: 0 };
        if (m.tipo === 'ingreso') { mapa[mes].ingresos += monto; ti += monto; }
        else { mapa[mes].egresos += monto; te += monto; }
        mapa[mes].count++;
      }
      const periodos = Object.values(mapa).sort((a, b) => a.mes.localeCompare(b.mes));
      for (const p of periodos) p.saldo = p.ingresos - p.egresos;
      const meses = Object.keys(mapa).length || 1;
      this.periodos = periodos;
      this.resumen = { totalIngresos: ti, totalEgresos: te, promedioMes: Math.abs(ti - te) / meses };
    } catch (e) { console.error(e); UI.toast('Error', 'error'); }
    finally { this.loading = false; }
  },

  renderChart(el) {
    if (this.chartInstance) { this.chartInstance.destroy(); }
    const labels = this.periodos.map(p => { const [a, b] = p.mes.split('-'); const meses = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic']; return meses[parseInt(b) - 1] + ' ' + a; });
    const ingresos = this.periodos.map(p => p.ingresos);
    const egresos = this.periodos.map(p => p.egresos);
    try {
      this.chartInstance = new Chart(el, {
        type: 'bar',
        data: {
          labels,
          datasets: [
            { label: 'Ingresos', data: ingresos, backgroundColor: '#16a34a', borderRadius: 6 },
            { label: 'Egresos', data: egresos, backgroundColor: '#dc2626', borderRadius: 6 }
          ]
        },
        options: {
          responsive: true, maintainAspectRatio: true,
          scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: '#f3f4f6' } } },
          plugins: { legend: { position: 'bottom', labels: { font: { size: 11 }, boxWidth: 12, padding: 12 } } }
        }
      });
    } catch (e) { console.error('Chart:', e); }
  },

  async exportarCSV() {
    try {
      const movs = await db.movimientos.orderBy('fecha').reverse().toArray();
      let csv = '\uFEFFFecha,Tipo,Categoria,Concepto,Monto\n';
      for (const m of movs) csv += (m.fecha || m.createdAt || '') + ',' + (m.tipo || '') + ',' + (m.categoria || '') + ',' + (m.nota || '').replace(/,/g, ' ') + ',' + (m.monto || 0) + '\n';
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'gastos_' + new Date().toISOString().slice(0, 10) + '.csv';
      link.click();
      URL.revokeObjectURL(link.href);
      UI.toast('CSV exportado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['gastos-reportes'] = ModuloGastosReportes;

document.addEventListener('alpine:init', () => {
  Alpine.data('gastosReportesData', () => ModuloGastosReportes);
});
