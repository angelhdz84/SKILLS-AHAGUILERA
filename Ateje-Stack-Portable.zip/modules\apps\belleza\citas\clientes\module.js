﻿const ModuloCitasClientes = {
  id: 'citas-clientes',
  titulo: 'Clientes',
  icono: 'bi bi-people',

  items: [],
  item: null,
  errors: {},
  searchQuery: '',
  loading: true,
  error: null,
  saving: false,
  kpis: { total: 0, frecuentes: 0, nuevosMes: 0 },

  async init() {
    await this.cargarDatos();
  },

  render(params = {}) {
    return `
      <div x-data="citasClientesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-pink-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-people text-pink-600"></i> Clientes
          </h2>
        </div>

        <div class="grid grid-cols-3 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Frecuentes</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.frecuentes"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Nuevos este mes</p>
            <p class="text-2xl font-bold text-green-600" x-text="kpis.nuevosMes"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-6">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-pink-600 text-white text-sm font-medium rounded-lg hover:bg-pink-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Cliente
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="cargarDatos" placeholder="Buscar clientes por nombre o tel\u00e9fono..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none transition-shadow" />
          </div>
        </div>

        <template x-if="error">
          <div class="p-4 mb-4 bg-red-50 border border-red-200 rounded-lg">
            <div class="flex items-center gap-2 text-red-700 text-sm">
              <i class="bi bi-exclamation-triangle"></i>
              <span x-text="error"></span>
            </div>
          </div>
        </template>

        <template x-if="!loading && !error && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-people text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">No hay clientes a\u00fan</p>
            <p class="text-sm text-gray-400 mb-6">Agrega tu primer cliente para empezar</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-pink-600 text-white text-sm font-medium rounded-lg hover:bg-pink-700 transition-colors shadow-sm" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Agregar primero
            </button>
          </div>
        </template>

        <template x-if="!loading && items.length > 0">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead>
                  <tr class="border-b border-gray-100 bg-gray-50/50">
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Cliente</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Tel\u00e9fono</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Email</th>
                    <th class="text-center px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Visitas</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Total gastado</th>
                    <th class="text-center px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Estado</th>
                    <th class="text-right px-4 py-3 w-20"></th>
                  </tr>
                </thead>
                <tbody>
                  <template x-for="item in items" :key="item.id">
                    <tr class="border-b border-gray-50 hover:bg-gray-50/50 transition-colors cursor-pointer" @click="abrirForm(item)">
                      <td class="px-4 py-3">
                        <div class="flex items-center gap-3">
                          <div class="w-9 h-9 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 font-semibold text-sm shrink-0"
                               x-text="(item.nombre || '?').charAt(0).toUpperCase()"></div>
                          <span class="font-medium text-gray-900" x-text="item.nombre"></span>
                        </div>
                      </td>
                      <td class="px-4 py-3 text-gray-500" x-text="item.telefono || '—'"></td>
                      <td class="px-4 py-3 text-gray-500" x-text="item.email || '—'"></td>
                      <td class="px-4 py-3 text-center text-gray-700" x-text="item.visitas || 0"></td>
                      <td class="px-4 py-3 text-right font-medium text-gray-900" x-text="formatearMoneda(item.totalGastado || 0)"></td>
                      <td class="px-4 py-3 text-center">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                              :class="item.frecuente ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-500'"
                              x-text="item.frecuente ? 'Frecuente' : 'Normal'"></span>
                      </td>
                      <td class="px-4 py-3 text-right">
                        <button class="text-gray-300 hover:text-red-500 transition-colors p-1" @click.stop="eliminar(item)">
                          <i class="bi bi-trash"></i>
                        </button>
                      </td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div class="p-4 space-y-3">
              <template x-for="i in 5" :key="i">
                <div class="flex items-center gap-3">
                  <div class="w-9 h-9 rounded-full bg-gray-200 animate-pulse shrink-0"></div>
                  <div class="flex-1 space-y-1">
                    <div class="h-4 bg-gray-200 rounded animate-pulse w-1/3"></div>
                    <div class="h-3 bg-gray-200 rounded animate-pulse w-1/5"></div>
                  </div>
                  <div class="h-4 bg-gray-200 rounded animate-pulse w-20"></div>
                </div>
              </template>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.item = null;
    this.searchQuery = '';
    this.loading = true;
    this.error = null;
    this.kpis = { total: 0, frecuentes: 0, nuevosMes: 0 };
  },

  formatearMoneda(valor) {
    if (valor == null || isNaN(valor)) return '$0.00';
    return '$' + Number(valor).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  formatearFecha(fecha) {
    if (!fecha) return '';
    try { return new Date(fecha).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); }
    catch { return fecha; }
  },

  _cifrarSensibles(obj) {
    if (!APP_CONFIG?.cifrado?.camposSensibles) return obj;
    for (const campo of APP_CONFIG.cifrado.camposSensibles) {
      if (obj[campo] && typeof obj[campo] === 'string' && !obj[campo].startsWith('U2FsdGVkX1')) {
        obj[campo] = cryptoHelpers.encrypt(obj[campo]);
      }
    }
    return obj;
  },

  _descifrarSensibles(obj) {
    if (!APP_CONFIG?.cifrado?.camposSensibles) return obj;
    for (const campo of APP_CONFIG.cifrado.camposSensibles) {
      if (obj[campo]) obj[campo] = cryptoHelpers.decrypt(obj[campo]);
    }
    return obj;
  },

  async cargarDatos() {
    try {
      this.loading = true;
      this.error = null;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.clientes.orderBy('createdAt').reverse().toArray();
      if (filtro) {
        datos = datos.filter(i =>
          (i.nombre || '').toLowerCase().includes(filtro) ||
          (i.telefono || '').includes(filtro)
        );
      }
      this.items = datos;
      this.calcularKPIs();
    } catch (e) {
      console.error('Error cargando clientes:', e);
      this.error = 'Error al cargar datos';
      UI.toast('Error al cargar datos', 'error');
    } finally {
      this.loading = false;
    }
  },

  calcularKPIs() {
    const total = this.items.length;
    const frecuentes = this.items.filter(i => i.frecuente).length;
    const hoy = new Date();
    const mesInicio = new Date(hoy.getFullYear(), hoy.getMonth(), 1).toISOString();
    const nuevosMes = this.items.filter(i => i.createdAt >= mesInicio).length;
    this.kpis = { total, frecuentes, nuevosMes };
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const descifrado = item ? this._descifrarSensibles({ ...item }) : {};
    const html = `
      <div class="space-y-4">
        <div class="grid grid-cols-2 gap-4">
          <div class="col-span-2">
            <label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>
            <input type="text" x-model="form.nombre"
                   class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                   :class="errors.nombre ? 'border-red-500 focus:ring-red-500 focus:ring-2' : 'border-gray-300 focus:ring-2 focus:ring-pink-500 focus:border-pink-500'" />
            <template x-if="errors.nombre">
              <p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p>
            </template>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Tel\u00e9fono</label>
            <input type="tel" x-model="form.telefono"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-shadow" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" x-model="form.email"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-shadow" />
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Notas</label>
          <textarea x-model="form.notas" rows="2"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-shadow"></textarea>
        </div>
      </div>`;
    await UI.modalForm(
      editando ? 'Editar Cliente' : 'Nuevo Cliente',
      html,
      async (data) => {
        if (editando) await this.actualizar(descifrado.id, data);
        else await this.guardar(data);
        await this.cargarDatos();
      },
      descifrado
    );
  },

  validarForm(datos) {
    this.errors = {};
    if (!datos.nombre || !datos.nombre.trim()) {
      this.errors.nombre = 'El nombre es obligatorio';
    }
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const registro = this._cifrarSensibles({
        id: uuid(),
        nombre: datos.nombre.trim(),
        telefono: datos.telefono?.trim() || '',
        email: datos.email?.trim() || '',
        notas: datos.notas?.trim() || '',
        foto: datos.foto || '',
        frecuente: false,
        visitas: 0,
        totalGastado: 0,
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      await db.clientes.put(registro);
      UI.toast('Cliente guardado correctamente', 'success');
    } catch (e) {
      console.error('Error al guardar:', e);
      UI.toast('Error al guardar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const existente = await db.clientes.get(id);
      if (!existente) {
        UI.toast('Cliente no encontrado', 'error');
        return;
      }
      const actualizado = this._cifrarSensibles({
        ...existente,
        nombre: datos.nombre.trim(),
        telefono: datos.telefono?.trim() || '',
        email: datos.email?.trim() || '',
        notas: datos.notas?.trim() || '',
        updatedAt: new Date().toISOString()
      });
      await db.clientes.put(actualizado);
      UI.toast('Cliente actualizado correctamente', 'success');
    } catch (e) {
      console.error('Error al actualizar:', e);
      UI.toast('Error al actualizar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar a ' + (item.nombre || 'este cliente') + '?');
    if (!ok) return;
    try {
      await db.clientes.delete(item.id);
      UI.toast('Cliente eliminado correctamente', 'success');
      await this.cargarDatos();
    } catch (e) {
      console.error('Error al eliminar:', e);
      UI.toast(e.message, 'error');
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['citas-clientes'] = ModuloCitasClientes;

document.addEventListener('alpine:init', () => {
  Alpine.data('citasClientesData', () => ModuloCitasClientes);
});
