﻿const ModuloInvMovimientos = {
  id: 'inv-movimientos',
  titulo: 'Movimientos',
  icono: 'bi bi-arrow-left-right',

  items: [],
  productos: [],
  filtroTipo: '',
  filtroProducto: '',
  loading: true,
  errors: {},

  async init() {
    await Promise.all([this.cargarMovimientos(), this.cargarProductos()]);
  },

  render() {
    return `
      <div x-data="invMovimientosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-emerald-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-arrow-left-right text-emerald-600"></i> Movimientos
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Movimiento
          </button>
          <select x-model="filtroTipo" @change="filtrar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-emerald-500 outline-none transition-shadow">
            <option value="">Todos los tipos</option>
            <option value="entrada">Entrada</option>
            <option value="salida">Salida</option>
            <option value="ajuste">Ajuste</option>
            <option value="merma">Merma</option>
            <option value="transferencia">Transferencia</option>
          </select>
          <select x-model="filtroProducto" @change="filtrar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-emerald-500 outline-none transition-shadow">
            <option value="">Todos los productos</option>
            <template x-for="p in productos" :key="p.id">
              <option :value="p.id" x-text="p.nombre"></option>
            </template>
          </select>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-arrow-left-right text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">Sin movimientos</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Registrar primero
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Fecha</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Producto</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Tipo</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Cantidad</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Motivo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wider">Usuario</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <template x-for="m in items" :key="m.id">
                    <tr class="hover:bg-gray-50 transition-colors">
                      <td class="px-4 py-3 text-gray-500 text-xs whitespace-nowrap" x-text="formatearFecha(m.createdAt)"></td>
                      <td class="px-4 py-3 font-medium text-gray-900" x-text="nombreProducto(m.productoId)"></td>
                      <td class="px-4 py-3">
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
                              :class="tipoClass(m.tipo)">
                          <i :class="tipoIcon(m.tipo)"></i>
                          <span x-text="m.tipo"></span>
                        </span>
                      </td>
                      <td class="px-4 py-3 text-right font-mono font-bold"
                          :class="m.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'"
                          x-text="(m.tipo === 'entrada' ? '+' : '-') + (m.cantidad || 0)"></td>
                      <td class="px-4 py-3 text-gray-500" x-text="m.motivo || '\u2014'"></td>
                      <td class="px-4 py-3 text-gray-400 text-xs" x-text="m.createdBy || '\u2014'"></td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-4">
                <div class="h-4 w-20 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-5 w-16 bg-gray-200 rounded animate-pulse"></div>
                <div class="h-4 w-12 bg-gray-200 rounded animate-pulse ml-auto"></div>
              </div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = []; this.productos = []; this.filtroTipo = ''; this.filtroProducto = ''; this.loading = true;
  },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch { return f; } },
  nombreProducto(id) { const p = this.productos.find(x => x.id === id); return p ? p.nombre : id?.slice(0, 8) || '\u2014'; },
  tipoClass(t) { const m = { entrada: 'bg-green-100 text-green-700', salida: 'bg-red-100 text-red-700', ajuste: 'bg-blue-100 text-blue-700', merma: 'bg-amber-100 text-amber-700', transferencia: 'bg-purple-100 text-purple-700' }; return m[t] || 'bg-gray-100 text-gray-700'; },
  tipoIcon(t) { const m = { entrada: 'bi bi-box-arrow-in-down', salida: 'bi bi-box-arrow-up', ajuste: 'bi bi-sliders', merma: 'bi bi-trash3', transferencia: 'bi bi-arrow-left-right' }; return m[t] || 'bi bi-circle'; },

  async cargarMovimientos() {
    try {
      this.loading = true;
      this.items = await db.movimientos.orderBy('createdAt').reverse().toArray();
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarProductos() {
    try { this.productos = await db.productos.orderBy('nombre').toArray(); }
    catch (e) { console.error(e); }
  },

  filtrar() {
    Promise.resolve().then(async () => {
      try {
        this.loading = true;
        let datos = await db.movimientos.orderBy('createdAt').reverse().toArray();
        if (this.filtroTipo) datos = datos.filter(m => m.tipo === this.filtroTipo);
        if (this.filtroProducto) datos = datos.filter(m => m.productoId === this.filtroProducto);
        this.items = datos;
      } catch (e) { console.error(e); }
      finally { this.loading = false; }
    });
  },

  async abrirForm() {
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Producto <span class="text-red-500">*</span></label>',
      '<select x-model="form.productoId" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow bg-white"',
      ':class="errors.productoId ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-emerald-500\'">',
      '<option value="">Seleccionar...</option>',
      '<template x-for="p in productos" :key="p.id"><option :value="p.id" x-text="p.nombre + \' (\' + (p.cantidad||0) + \' uds)\'"></option></template>',
      '</select><template x-if="errors.productoId"><p class="mt-1 text-sm text-red-500" x-text="errors.productoId"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Tipo <span class="text-red-500">*</span></label>',
      '<select x-model="form.tipo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-shadow bg-white">',
      '<option value="entrada">Entrada (compra)</option>',
      '<option value="salida">Salida (venta)</option>',
      '<option value="ajuste">Ajuste de inventario</option>',
      '<option value="merma">Merma / Da\u00f1o</option>',
      '<option value="transferencia">Transferencia</option>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Cantidad <span class="text-red-500">*</span></label>',
      '<input type="number" min="1" x-model="form.cantidad" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.cantidad ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-emerald-500\'" />',
      '<template x-if="errors.cantidad"><p class="mt-1 text-sm text-red-500" x-text="errors.cantidad"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Motivo</label>',
      '<textarea x-model="form.motivo" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-shadow" placeholder="Opcional"></textarea></div>',
      '</div>'
    ].join('\n');
    await UI.modalForm('Nuevo Movimiento', html,
      async (data) => {
        this.errors = {};
        if (!data.productoId) { this.errors.productoId = 'Selecciona un producto'; return; }
        if (!data.cantidad || data.cantidad < 1) { this.errors.cantidad = 'Cantidad v\u00e1lida requerida'; return; }
        try {
          const prod = await db.productos.get(data.productoId);
          if (!prod) { UI.toast('Producto no encontrado', 'error'); return; }
          const nuevoStock = data.tipo === 'entrada' ? (prod.cantidad || 0) + parseInt(data.cantidad)
            : Math.max(0, (prod.cantidad || 0) - parseInt(data.cantidad));
          await db.productos.put({ ...prod, cantidad: nuevoStock, updatedAt: new Date().toISOString() });
          await db.movimientos.put({
            id: window.uuid(), productoId: data.productoId, tipo: data.tipo, cantidad: parseInt(data.cantidad),
            motivo: data.motivo?.trim() || '', createdBy: APP_CONFIG?.usuarioActual || 'anon',
            createdAt: new Date().toISOString()
          });
          UI.toast('Movimiento registrado', 'success');
          await this.cargarMovimientos();
        } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
      }, { tipo: 'entrada', cantidad: 1 }
    );
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['inv-movimientos'] = ModuloInvMovimientos;

document.addEventListener('alpine:init', () => {
  Alpine.data('invMovimientosData', () => ModuloInvMovimientos);
});
