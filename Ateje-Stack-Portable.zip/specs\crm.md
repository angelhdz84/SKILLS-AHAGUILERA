# AHA CRM — Spec Técnica

## Identidad
- **App:** AHA CRM
- **Perfil:** Lite
- **Target:** Freelancers, consultores, agentes de seguros, agencias pequeñas
- **Tagline:** CRM minimalista offline con pipeline Kanban
- **Color primario:** #2563eb (blue-600)
- **Descripción:** Gestión de clientes, pipeline de ventas Kanban, cotizaciones, facturación.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  contactos: 'id, nombre, *empresa, *telefono, email, *notas, *createdBy, createdAt, updatedAt',
  deals: 'id, *contactoId, *nombre, *monto, *etapa, *probabilidad, *fechaCierre, *createdBy, createdAt, updatedAt',
  cotizaciones: 'id, *dealId, *items, *total, *pdfGenerado, *estado, *createdBy, createdAt, updatedAt',
  facturas: 'id, *dealId, *contactoId, *folio, *total, *estado, *createdBy, createdAt, updatedAt',
  interacciones: 'id, *contactoId, *tipo, *nota, *createdBy, createdAt',
  _sync_log, _ia_chats, _ia_messages
});
```

Etapas pipeline: prospecto, contactado, propuesta, negociación, cerrado
Estado cotización: borrador, enviada, aceptada, rechazada
Estado factura: pagada, pendiente, vencida

## Entry point
`core/main.js`

## Módulos (5)

### contacto (module alias para contactos)
- CRUD: nombre, empresa, teléfono, email, notas
- Historial de interacciones por contacto (timeline)
- Búsqueda instantánea

### pipeline (Kanban)
- 5 etapas: prospecto, contactado, propuesta, negociación, cerrado
- Cards de deals arrastrables entre etapas (drag & drop nativo)
- Deal: nombre, contacto, monto, probabilidad (%), fecha cierre
- Modal crear/editar deal

### cotizaciones
- Crear desde deal
- Items: servicio, cantidad, precio
- Generar PDF con jsPDF
- Estados: borrador, enviada, aceptada, rechazada

### facturacion
- Generar desde deal cerrado
- Folio automático (F-001, F-002...)
- Estados: pagada, pendiente, vencida
- Export PDF

### reportes
- Tasa de conversión por etapa (funnel)
- Ingresos del mes por cliente
- Gráficos Chart.js
- Export CSV

## Estructura
```
aha-crm/
├── index.html, manifest.json, sw.js, project.config.js, .gitignore, README.md
├── core/ (main, app, db, crypto, theme, ui, env, network, sync, seed, search-palette, file-store, license)
├── modules/
│   ├── contacto/module.html + module.js
│   ├── pipeline/module.html + module.js
│   ├── cotizaciones/module.html + module.js
│   ├── facturacion/module.html + module.js
│   └── reportes/module.html + module.js
├── assets/js/libs/ (alpine, dexie, crypto-js, pako, chart.js, jspdf)
├── assets/css/ (daisyui, tailwind.play, bootstrap-icons, animate.min)
├── assets/icons/ (icon-192, icon-512)
└── data/defaults/ (avatar.svg, placeholder.svg)
```

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema blue (primary: #2563eb)
- Chart.js para gráficos
- jsPDF para PDF cotizaciones/facturas
- ES5 estricto
