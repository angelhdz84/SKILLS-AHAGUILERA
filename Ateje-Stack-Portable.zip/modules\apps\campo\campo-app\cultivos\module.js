const ModuloCampoCultivos = {
  id: 'campo-cultivos',
  titulo: 'Cultivos',
  icono: 'bi bi-flower1',

  items: [],
  item: null,
  formData: {},
  errors: {},
  searchQuery: '',
  loading: true,
  error: null,
  saving: false,
  page: 1,
  pageSize: 25,
  totalPages: 1,
  lotesCache: [],

  async init() {
    this.lotesCache = await db.lotes.toArray();
    await this.cargarDatos();
  },

  render(params = {}) {
    return `
      <div x-data="campoCultivosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-green-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-flower1 text-green-600"></i> Ciclos de Cultivo
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Nuevo ciclo
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="buscar" placeholder="Buscar cultivo..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-shadow" />
          </div>
          <button class="inline-flex items-center gap-1.5 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors" @click="exportarPDF()" x-show="items.length">
            <i class="bi bi-file-earmark-pdf"></i> PDF
          </button>
        </div>

        <template x-if="error">
          <div class="p-4 mb-4 bg-red-50 border border-red-200 rounded-lg">
            <div class="flex items-center gap-2 text-red-700 text-sm">
              <i class="bi bi-exclamation-triangle"></i>
              <span x-text="error"></span>
            </div>
          </div>
        </template>

        <template x-if="!loading && !error && lotesCache.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-grid-3x3-gap text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-4">Primero debes registrar un lote</p>
            <p class="text-sm text-gray-400 mb-4">Los ciclos de cultivo se asocian a un lote</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors shadow-sm"
                    @click="window.appRouter?.navigate('campo-lotes')">
              <i class="bi bi-plus-lg"></i> Ir a Lotes
            </button>
          </div>
        </template>

        <template x-if="!loading && !error && lotesCache.length > 0 && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-flower1 text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-4">No hay ciclos de cultivo registrados</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors shadow-sm" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Iniciar primer ciclo
            </button>
          </div>
        </template>

        <template x-if="!loading && items.length > 0">
          <div>
            <div class="overflow-x-auto rounded-lg border border-gray-200">
              <table class="w-full text-sm">
                <thead>
                  <tr class="bg-gray-50 border-b border-gray-200">
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Lote</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Cultivo</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Siembra</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Cosecha</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Estado</th>
                    <th class="text-right px-4 py-3 font-semibold text-gray-600">Acciones</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <tr x-for="(item, idx) in paginated" :key="item.id"
                      class="hover:bg-gray-50 transition-colors"
                      :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'">
                    <td class="px-4 py-3 text-gray-900 font-medium" x-text="nombreLote(item.loteId)"></td>
                    <td class="px-4 py-3 text-gray-900" x-text="item.cultivo"></td>
                    <td class="px-4 py-3 text-gray-500" x-text="formatearFecha(item.fechaSiembra)"></td>
                    <td class="px-4 py-3 text-gray-500" x-text="formatearFecha(item.fechaCosecha) || '—'"></td>
                    <td class="px-4 py-3">
                      <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                            :class="item.fechaCosecha ? 'bg-gray-100 text-gray-600' : 'bg-green-100 text-green-800'"
                            x-text="item.fechaCosecha ? 'Cosechado' : 'Activo'"></span>
                    </td>
                    <td class="px-4 py-3 text-right">
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors" @click="abrirForm(item)" title="Editar">
                        <i class="bi bi-pencil"></i>
                      </button>
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" @click="eliminar(item)" title="Eliminar">
                        <i class="bi bi-trash"></i>
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div class="flex justify-between items-center mt-4" x-show="totalPages > 1">
              <span class="text-sm text-gray-500">
                P\u00e1gina <span class="font-medium text-gray-700" x-text="page"></span> de <span class="font-medium text-gray-700" x-text="totalPages"></span>
              </span>
              <div class="flex gap-2">
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === 1" @click="page--;">
                  <i class="bi bi-chevron-left"></i>
                </button>
                <button class="inline-flex items-center px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors" :disabled="page === totalPages" @click="page++;">
                  <i class="bi bi-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            <div class="h-12 w-full bg-gray-200 rounded-lg animate-pulse"></div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.item = null;
    this.searchQuery = '';
    this.loading = true;
    this.error = null;
    this.page = 1;
    this.lotesCache = [];
  },

  nombreLote(loteId) {
    const lote = this.lotesCache.find(l => l.id === loteId);
    return lote ? lote.nombre : 'Lote eliminado';
  },

  formatearFecha(fecha) {
    if (!fecha) return '';
    try {
      return new Date(fecha).toLocaleDateString('es-MX', {
        year: 'numeric', month: 'short', day: 'numeric'
      });
    } catch { return fecha; }
  },

  get paginated() {
    const start = (this.page - 1) * this.pageSize;
    return this.items.slice(start, start + this.pageSize);
  },

  _cifrarSensibles(obj) {
    for (const campo of (APP_CONFIG.cifrado.camposSensibles || [])) {
      if (obj[campo] && typeof obj[campo] === 'string' && !obj[campo].startsWith('U2FsdGVkX1')) {
        obj[campo] = cryptoHelpers.encrypt(obj[campo]);
      }
    }
    return obj;
  },

  _descifrarSensibles(obj) {
    if (!APP_CONFIG.cifrado.camposSensibles) return obj;
    for (const campo of APP_CONFIG.cifrado.camposSensibles) {
      if (obj[campo]) obj[campo] = cryptoHelpers.decrypt(obj[campo]);
    }
    return obj;
  },

  async cargarDatos() {
    try {
      this.loading = true;
      this.error = null;
      this.lotesCache = await db.lotes.toArray();
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.ciclos.orderBy('createdAt').reverse().toArray();
      if (filtro) {
        datos = datos.filter(i => {
          const nomLote = this.nombreLote(i.loteId).toLowerCase();
          return (i.cultivo || '').toLowerCase().includes(filtro) || nomLote.includes(filtro);
        });
      }
      this.items = datos;
      this.totalPages = Math.max(1, Math.ceil(this.items.length / this.pageSize));
      if (this.page > this.totalPages) this.page = this.totalPages;
    } catch (e) {
      console.error('Error cargando cultivos:', e);
      this.error = 'Error al cargar cultivos';
      UI.toast('Error al cargar cultivos', 'error');
    } finally {
      this.loading = false;
    }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const descifrado = item ? this._descifrarSensibles({ ...item }) : {};
    const lotesOpts = this.lotesCache.map(l =>
      `<option value="${l.id}" ${descifrado.loteId === l.id ? 'selected' : ''}>${l.nombre}</option>`
    ).join('');
    const hoy = new Date().toISOString().split('T')[0];
    const html = `
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Lote <span class="text-red-500">*</span></label>
          <select x-model="form.loteId"
                  class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                  :class="errors.loteId ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-green-500 focus:border-green-500'"
                  :class="errors.loteId ? 'focus:ring-2' : 'focus:ring-2'">
            <option value="">Seleccionar lote...</option>
            ${lotesOpts}
          </select>
          <template x-if="errors.loteId">
            <p class="mt-1 text-sm text-red-500" x-text="errors.loteId"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Cultivo <span class="text-red-500">*</span></label>
          <input type="text" x-model="form.cultivo" placeholder="Ej: Ma\u00edz, Frijol, Sorgo"
                 class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                 :class="errors.cultivo ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-green-500 focus:border-green-500'"
                 :class="errors.cultivo ? 'focus:ring-2' : 'focus:ring-2'" />
          <template x-if="errors.cultivo">
            <p class="mt-1 text-sm text-red-500" x-text="errors.cultivo"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Fecha de siembra <span class="text-red-500">*</span></label>
          <input type="date" x-model="form.fechaSiembra" max="${hoy}"
                 class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"
                 :class="errors.fechaSiembra ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-green-500 focus:border-green-500'"
                 :class="errors.fechaSiembra ? 'focus:ring-2' : 'focus:ring-2'" />
          <template x-if="errors.fechaSiembra">
            <p class="mt-1 text-sm text-red-500" x-text="errors.fechaSiembra"></p>
          </template>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Fecha de cosecha</label>
          <input type="date" x-model="form.fechaCosecha" max="${hoy}"
                 class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-shadow" />
          <p class="mt-1 text-xs text-gray-400">D\u00e9jalo vac\u00edo si el cultivo sigue activo</p>
        </div>
      </div>`;
    await UI.modalForm(
      editando ? 'Editar Ciclo de Cultivo' : 'Nuevo Ciclo de Cultivo',
      html,
      async (data) => {
        if (editando) await this.actualizar(descifrado.id, data);
        else await this.guardar(data);
        await this.cargarDatos();
      },
      descifrado
    );
  },

  validarForm(datos) {
    this.errors = {};
    if (!datos.loteId) {
      this.errors.loteId = 'Seleccione un lote';
    }
    if (!datos.cultivo || !datos.cultivo.trim()) {
      this.errors.cultivo = 'El nombre del cultivo es obligatorio';
    }
    if (!datos.fechaSiembra) {
      this.errors.fechaSiembra = 'La fecha de siembra es obligatoria';
    }
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const registro = this._cifrarSensibles({
        id: uuid(),
        loteId: datos.loteId,
        cultivo: datos.cultivo.trim(),
        fechaSiembra: datos.fechaSiembra,
        fechaCosecha: datos.fechaCosecha || null,
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      await db.ciclos.put(registro);
      await db.lotes.update(datos.loteId, { cultivoActual: datos.cultivo.trim(), updatedAt: new Date().toISOString() });
      UI.toast('Ciclo guardado correctamente', 'success');
    } catch (e) {
      console.error('Error al guardar ciclo:', e);
      UI.toast('Error al guardar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    this.saving = true;
    try {
      const existente = await db.ciclos.get(id);
      if (!existente) {
        UI.toast('Ciclo no encontrado', 'error');
        return;
      }
      const actualizado = this._cifrarSensibles({
        ...existente,
        loteId: datos.loteId,
        cultivo: datos.cultivo.trim(),
        fechaSiembra: datos.fechaSiembra,
        fechaCosecha: datos.fechaCosecha || null,
        updatedAt: new Date().toISOString()
      });
      await db.ciclos.put(actualizado);
      UI.toast('Ciclo actualizado correctamente', 'success');
    } catch (e) {
      console.error('Error al actualizar ciclo:', e);
      UI.toast('Error al actualizar: ' + e.message, 'error');
    } finally {
      this.saving = false;
    }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar el ciclo de ' + (item.cultivo || '') + '?');
    if (!ok) return;
    try {
      await db.ciclos.delete(item.id);
      UI.toast('Ciclo eliminado correctamente', 'success');
      await this.cargarDatos();
    } catch (e) {
      console.error('Error al eliminar ciclo:', e);
      UI.toast(e.message, 'error');
    }
  },

  async buscar() {
    this.page = 1;
    await this.cargarDatos();
  },

  async limpiarBusqueda() {
    this.searchQuery = '';
    this.page = 1;
    await this.cargarDatos();
  },

  async exportarPDF() {
    if (!this.items.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const { jsPDF } = window.jspdf || {};
      if (!jsPDF) {
        UI.toast('jsPDF no disponible', 'error');
        return;
      }
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text('Ciclos de Cultivo', 14, 20);
      doc.setFontSize(10);
      let y = 30;
      doc.text('Lote', 14, y);
      doc.text('Cultivo', 70, y);
      doc.text('Siembra', 120, y);
      doc.text('Cosecha', 165, y);
      y += 6;
      doc.setDrawColor(200);
      doc.line(14, y, 196, y);
      y += 4;
      for (const item of this.items) {
        if (y > 280) { doc.addPage(); y = 20; }
        doc.text(this.nombreLote(item.loteId), 14, y);
        doc.text(item.cultivo || '', 70, y);
        doc.text(this.formatearFecha(item.fechaSiembra), 120, y);
        doc.text(this.formatearFecha(item.fechaCosecha) || 'Activo', 165, y);
        y += 6;
      }
      doc.save('cultivos-ciclos.pdf');
      UI.toast('PDF exportado', 'success');
    } catch (e) {
      console.error('Error exportando PDF:', e);
      UI.toast('Error al exportar PDF', 'error');
    }
  },

  async exportarCSV() {
    if (!this.items.length) {
      UI.toast('No hay datos para exportar', 'warning');
      return;
    }
    try {
      const XLSX = window.XLSX;
      if (XLSX) {
        const ws = XLSX.utils.json_to_sheet(this.items.map(i => ({
          Lote: this.nombreLote(i.loteId),
          Cultivo: i.cultivo || '',
          Siembra: this.formatearFecha(i.fechaSiembra),
          Cosecha: this.formatearFecha(i.fechaCosecha) || 'Activo'
        })));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Cultivos');
        XLSX.writeFile(wb, 'cultivos-ciclos.xlsx');
        UI.toast('Excel exportado', 'success');
      } else {
        const cabeceras = ['Lote', 'Cultivo', 'Siembra', 'Cosecha'];
        const filas = this.items.map(i => [
          this.nombreLote(i.loteId),
          i.cultivo || '',
          this.formatearFecha(i.fechaSiembra),
          this.formatearFecha(i.fechaCosecha) || 'Activo'
        ]);
        let csv = cabeceras.join(',') + '\n';
        for (const fila of filas) {
          csv += fila.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',') + '\n';
        }
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'cultivos-ciclos.csv';
        a.click();
        URL.revokeObjectURL(url);
        UI.toast('CSV exportado', 'success');
      }
    } catch (e) {
      console.error('Error exportando:', e);
      UI.toast('Error al exportar', 'error');
    }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['campo-cultivos'] = ModuloCampoCultivos;

document.addEventListener('alpine:init', () => {
  Alpine.data('campoCultivosData', () => ModuloCampoCultivos);
});
