﻿const ModuloObraMateriales = {
  id: 'obra-materiales',
  titulo: 'Materiales',
  icono: 'bi bi-box-seam',
  items: [],
  loading: true,
  obraSeleccionada: null,
  obras: [],

  async init() {
    await this.cargarObras();
    await this.cargar();
  },

  async cargarObras() {
    try {
      this.obras = await db.obras.toArray();
    } catch (e) {
      this.obras = [];
    }
  },

  async cargar() {
    this.loading = true;
    try {
      let query = db.materiales.orderBy('createdAt').reverse();
      if (this.obraSeleccionada) {
        query = db.materiales.where('obraId').equals(this.obraSeleccionada);
      }
      this.items = await query.toArray();
    } catch (e) {
      console.error('Error cargando materiales:', e);
      this.items = [];
    } finally {
      this.loading = false;
    }
  },

  render() {
    if (this.loading) return this.renderSkeleton();
    const bajos = this.items.filter(m => Number(m.cantidad) <= Number(m.stockMinimo));
    return \
      <div class="space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <h2 class="text-2xl font-bold flex items-center gap-2">
            <i class="bi bi-box-seam text-amber-500"></i> Materiales
          </h2>
          <div class="flex gap-2">
            <select x-model="obraMaterialesData.obraSeleccionada" @change="obraMaterialesData.cargar()" class="select select-bordered select-sm">
              <option value="">Todas las obras</option>
              <template x-for="obra in obraMaterialesData.obras" :key="obra.id">
                <option :value="obra.id" x-text="obra.nombre"></option>
              </template>
            </select>
            <button @click="obraMaterialesData.abrirForm()" class="btn btn-primary btn-sm gap-1">
              <i class="bi bi-plus-lg"></i> Agregar
            </button>
          </div>
        </div>
        <template x-if="obraMaterialesData.items.filter(m => Number(m.cantidad) <= Number(m.stockMinimo)).length > 0">
          <div class="alert alert-warning shadow-sm">
            <i class="bi bi-exclamation-triangle"></i>
            <span x-text="obraMaterialesData.items.filter(m => Number(m.cantidad) <= Number(m.stockMinimo)).length + ' material(es) con stock bajo'"></span>
          </div>
        </template>
        <div x-show="obraMaterialesData.items.length === 0" class="empty-state">
          <div class="empty-state-icon bg-amber-50"><i class="bi bi-box-seam text-amber-400"></i></div>
          <div class="empty-state-title">Sin materiales</div>
          <div class="empty-state-desc">Registra los materiales de la obra</div>
          <button @click="obraMaterialesData.abrirForm()" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Agregar material</button>
        </div>
        <div x-show="obraMaterialesData.items.length > 0" class="overflow-x-auto">
          <table class="table table-zebra">
            <thead>
              <tr class="text-xs uppercase text-base-content/50">
                <th>Material</th>
                <th class="hidden sm:table-cell">Unidad</th>
                <th class="hidden lg:table-cell">Obra</th>
                <th>Cantidad</th>
                <th class="hidden sm:table-cell">Precio</th>
                <th class="hidden sm:table-cell">Total</th>
                <th class="text-right">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <template x-for="(item, i) in obraMaterialesData.items" :key="item.id">
                <tr :class="'stagger-item ' + (Number(item.cantidad) <= Number(item.stockMinimo) ? 'bg-warning/5' : '')" :style="'animation-delay: ' + (i * 0.04) + 's'">
                  <td>
                    <div class="flex items-center gap-2">
                      <span class="font-medium" x-text="item.nombre"></span>
                      <template x-if="Number(item.cantidad) <= Number(item.stockMinimo)">
                        <i class="bi bi-exclamation-circle text-warning" title="Stock bajo"></i>
                      </template>
                    </div>
                  </td>
                  <td class="hidden sm:table-cell"><span class="badge badge-ghost badge-sm" x-text="item.unidad || 'pza'"></span></td>
                  <td class="hidden lg:table-cell text-sm text-base-content/60" x-text="obraMaterialesData.obras.find(o => o.id === item.obraId)?.nombre || '-'"></td>
                  <td>
                    <span :class="Number(item.cantidad) <= Number(item.stockMinimo) ? 'text-warning font-bold' : ''" x-text="item.cantidad"></span>
                    <template x-if="Number(item.stockMinimo) > 0">
                      <span class="text-xs text-base-content/40" x-text="'/ min ' + item.stockMinimo"></span>
                    </template>
                  </td>
                  <td class="hidden sm:table-cell" x-text="formatCurrency(item.precioUnitario)"></td>
                  <td class="hidden sm:table-cell font-medium" x-text="formatCurrency((Number(item.cantidad) || 0) * (Number(item.precioUnitario) || 0))"></td>
                  <td class="text-right">
                    <div class="flex gap-1 justify-end">
                      <button @click="obraMaterialesData.abrirForm(item)" class="btn btn-ghost btn-xs btn-square" title="Editar"><i class="bi bi-pencil"></i></button>
                      <button @click="obraMaterialesData.eliminar(item)" class="btn btn-ghost btn-xs btn-square text-error" title="Eliminar"><i class="bi bi-trash"></i></button>
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
    \;
  },

  renderSkeleton() {
    return \
      <div class="space-y-4">
        <div class="sk-heading w-40"></div>
        <div class="sk-row"></div>
        \
      </div>
    \;
  },

  obtenerEtapasPorObra(obraId) {
    return this._etapasCache ? this._etapasCache.filter(e => e.obraId === obraId) : [];
  },

  async abrirForm(item) {
    const editando = !!item;
    const obraOptions = this.obras.map(o => \<option value="\" \>\</option>\).join('');
    let etapaOptions = '<option value="">Sin etapa</option>';
    try {
      const etapas = await db.etapas.toArray();
      this._etapasCache = etapas;
      etapaOptions += etapas.map(e => \<option value="\" \>\</option>\).join('');
    } catch (e) {}
    const unidades = ['pza', 'kg', 'ton', 'm', 'm2', 'm3', 'l', 'bolsa', 'rollo', 'paquete', 'varilla', 'hoja'];
    const unidadOptions = unidades.map(u => \<option value="\" \>\</option>\).join('');
    const html = \
      <div class="space-y-4">
        <label class="form-control w-full">
          <span class="label-text">Nombre del material</span>
          <input type="text" x-model="form.nombre" class="input input-bordered" required />
        </label>
        <div class="grid grid-cols-2 gap-4">
          <label class="form-control w-full">
            <span class="label-text">Obra</span>
            <select x-model="form.obraId" class="select select-bordered" required>
              <option value="">Seleccionar</option>
              \
            </select>
          </label>
          <label class="form-control w-full">
            <span class="label-text">Etapa</span>
            <select x-model="form.etapaId" class="select select-bordered">
              \
            </select>
          </label>
        </div>
        <div class="grid grid-cols-3 gap-4">
          <label class="form-control w-full">
            <span class="label-text">Unidad</span>
            <select x-model="form.unidad" class="select select-bordered">
              \
            </select>
          </label>
          <label class="form-control w-full">
            <span class="label-text">Cantidad</span>
            <input type="number" x-model="form.cantidad" class="input input-bordered" min="0" step="0.01" />
          </label>
          <label class="form-control w-full">
            <span class="label-text">Precio unitario</span>
            <input type="number" x-model="form.precioUnitario" class="input input-bordered" min="0" step="0.01" />
          </label>
        </div>
        <label class="form-control w-full">
          <span class="label-text">Stock mínimo (alerta)</span>
          <input type="number" x-model="form.stockMinimo" class="input input-bordered" min="0" />
        </label>
      </div>
    \;
    await UI.modalForm(
      editando ? 'Editar material' : 'Nuevo material',
      html,
      async (data) => {
        const payload = {
          obraId: data.obraId,
          etapaId: data.etapaId || '',
          nombre: data.nombre,
          unidad: data.unidad || 'pza',
          cantidad: Number(data.cantidad) || 0,
          precioUnitario: Number(data.precioUnitario) || 0,
          stockMinimo: Number(data.stockMinimo) || 0
        };
        if (editando) {
          await this.actualizar(item.id, payload);
        } else {
          await this.guardar(payload);
        }
      }
    );
  },

  async guardar(datos) {
    const registro = {
      id: uuid(),
      ...datos,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    await db.materiales.put(registro);
    UI.toast('Material guardado', 'success');
    await this.cargar();
  },

  async actualizar(id, datos) {
    const existente = await db.materiales.get(id);
    if (!existente) { UI.toast('Material no encontrado', 'error'); return; }
    const actualizado = { ...existente, ...datos, id, updatedAt: new Date().toISOString() };
    await db.materiales.put(actualizado);
    UI.toast('Material actualizado', 'success');
    await this.cargar();
  },

  async eliminar(item) {
    const ok = await UI.confirm(\Eliminar material "\"?\);
    if (!ok) return;
    try {
      await db.materiales.delete(item.id);
      UI.toast('Material eliminado', 'success');
      await this.cargar();
    } catch (e) {
      UI.toast(e.message, 'error');
    }
  },

  destroy() {
    this.items = [];
    this.loading = true;
    this.obraSeleccionada = null;
    this._etapasCache = null;
  }
};

function formatCurrency(n) {
  const v = Number(n) || 0;
  return '$' + v.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

window.MODULES = window.MODULES || {};
window.MODULES[ModuloObraMateriales.id] = ModuloObraMateriales;

document.addEventListener('alpine:init', () => {
  Alpine.data('obraMaterialesData', () => ModuloObraMateriales);
});
