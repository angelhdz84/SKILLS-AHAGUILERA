const ModuloAsisPersonal = {
  id: 'asis-personal',
  titulo: 'Personal',
  icono: 'bi bi-people-fill',
  items: [],
  loading: true,
  searchQuery: '',

  async init() {
    console.log('[' + this.id + '] Inicializando');
    await this.cargar();
  },

  render() {
    if (this.loading) {
      return '<div class="p-4 space-y-3">' +
        '<div class="sk-el sk-heading"></div>' +
        '<div class="sk-el sk-row"></div>' +
        '<div class="sk-el sk-row"></div>' +
        '<div class="sk-el sk-row"></div>' +
        '</div>';
    }

    const filtrados = this.searchQuery
      ? this.items.filter(function(e) {
          var q = this.searchQuery.toLowerCase();
          return (e.nombre || '').toLowerCase().includes(q) ||
            (e.puesto || '').toLowerCase().includes(q) ||
            (e.telefono || '').toLowerCase().includes(q);
        }.bind(this))
      : this.items;

    if (filtrados.length === 0) {
      var emptyMsg = this.searchQuery
        ? 'Sin resultados para <strong>"' + this.searchQuery + '"</strong>'
        : 'No hay empleados registrados';
      var emptyBtn = this.searchQuery
        ? '<button class="btn btn-ghost btn-sm" onclick="this.closest(\'[x-data]\').__x.$data.searchQuery=\'\'; Alpine.\$data(document.querySelector(\'[x-data]\')).searchQuery=\'\';"><i class="bi bi-x-lg"></i> Limpiar</button>'
        : '<button class="btn btn-primary btn-sm" onclick="ModuloAsisPersonal.abrirForm()"><i class="bi bi-plus-lg"></i> Agregar empleado</button>';
      return '<div class="p-4">' +
        '<div class="flex items-center justify-between mb-4">' +
        '<h2 class="text-xl font-bold flex items-center gap-2"><i class="bi bi-people-fill text-blue-500"></i> Personal</h2>' +
        '<button class="btn btn-primary btn-sm" onclick="ModuloAsisPersonal.abrirForm()"><i class="bi bi-plus-lg"></i> Agregar</button>' +
        '</div>' +
        '<div class="empty-state">' +
        '<div class="empty-state-icon bg-blue-100"><i class="bi bi-people-fill text-blue-500"></i></div>' +
        '<p class="empty-state-title">' + (this.searchQuery ? 'Sin resultados' : 'Sin empleados') + '</p>' +
        '<p class="empty-state-desc">' + emptyMsg + '</p>' +
        emptyBtn +
        '</div>' +
        '</div>';
    }

    var rows = filtrados.map(function(e, i) {
      var iniciales = (e.nombre || '??').split(' ').map(function(s) { return s[0]; }).join('').substring(0, 2).toUpperCase();
      var estadoBadge = e.activo
        ? '<span class="badge badge-success badge-sm">Activo</span>'
        : '<span class="badge badge-ghost badge-sm">Inactivo</span>';
      return '<tr class="stagger-item" style="animation-delay:' + (i * 0.03) + 's">' +
        '<td>' +
        '<div class="flex items-center gap-3">' +
        '<div class="avatar placeholder">' +
        '<div class="w-10 rounded-full bg-blue-100 text-blue-600 text-sm font-bold">' + iniciales + '</div>' +
        '</div>' +
        '<div><div class="font-medium">' + this._esc(e.nombre) + '</div><div class="text-xs text-base-content/60">' + this._esc(e.puesto || 'Sin puesto') + '</div></div>' +
        '</div>' +
        '</td>' +
        '<td class="hidden md:table-cell">' + this._esc(e.horario || '—') + '</td>' +
        '<td class="hidden sm:table-cell">' + this._esc(e.telefono || '—') + '</td>' +
        '<td>' + estadoBadge + '</td>' +
        '<td>' +
        '<div class="flex gap-1">' +
        '<button class="btn btn-ghost btn-xs btn-square" onclick="ModuloAsisPersonal.abrirForm(\'' + e.id + '\')" title="Editar"><i class="bi bi-pencil"></i></button>' +
        '<button class="btn btn-ghost btn-xs btn-square text-error" onclick="ModuloAsisPersonal.eliminar(\'' + e.id + '\')" title="Eliminar"><i class="bi bi-trash3"></i></button>' +
        '</div>' +
        '</td>' +
        '</tr>';
    }.bind(this)).join('');

    return '<div class="p-4">' +
      '<div class="flex flex-wrap items-center justify-between gap-3 mb-4">' +
      '<h2 class="text-xl font-bold flex items-center gap-2"><i class="bi bi-people-fill text-blue-500"></i> Personal <span class="badge badge-soft badge-sm">' + this.items.length + '</span></h2>' +
      '<div class="flex items-center gap-2">' +
      '<label class="input input-bordered input-sm flex items-center gap-2">' +
      '<i class="bi bi-search text-base-content/40"></i>' +
      '<input type="text" class="grow" placeholder="Buscar empleado..." value="' + this._esc(this.searchQuery) + '" oninput="ModuloAsisPersonal.searchQuery=this.value; Alpine.\$data(this.closest(\'[x-data]\')).items=ModuloAsisPersonal.items;" />' +
      '</label>' +
      '<button class="btn btn-primary btn-sm" onclick="ModuloAsisPersonal.abrirForm()"><i class="bi bi-plus-lg"></i> Agregar</button>' +
      '</div>' +
      '</div>' +
      '<div class="overflow-x-auto rounded-box border border-base-200">' +
      '<table class="table table-sm">' +
      '<thead><tr>' +
      '<th>Empleado</th>' +
      '<th class="hidden md:table-cell">Horario</th>' +
      '<th class="hidden sm:table-cell">Teléfono</th>' +
      '<th>Estado</th>' +
      '<th></th>' +
      '</tr></thead>' +
      '<tbody>' + rows + '</tbody>' +
      '</table>' +
      '</div>' +
      '</div>';
  },

  destroy() {
    this.items = [];
    this.loading = true;
    this.searchQuery = '';
  },

  async cargar() {
    this.loading = true;
    try {
      if (window.db && window.db.empleados) {
        this.items = await db.empleados.orderBy('nombre').toArray();
      } else {
        this.items = [];
      }
    } catch (e) {
      console.error('[' + this.id + '] Error al cargar:', e.message);
      this.items = [];
    }
    this.loading = false;
  },

  async abrirForm(id) {
    var editando = !!id;
    var item = editando ? this.items.find(function(e) { return e.id === id; }) : null;
    var nombre = item ? this._esc(item.nombre) : '';
    var puesto = item ? this._esc(item.puesto || '') : '';
    var horario = item ? this._esc(item.horario || '') : '';
    var telefono = item ? this._esc(item.telefono || '') : '';
    var activo = item ? (item.activo !== false) : true;

    var html =
      '<div class="space-y-4">' +
      '<label class="form-control w-full">' +
      '<span class="label-text">Nombre completo</span>' +
      '<input type="text" x-model="form.nombre" class="input input-bordered" placeholder="ej: Juan Pérez" required />' +
      '</label>' +
      '<label class="form-control w-full">' +
      '<span class="label-text">Puesto</span>' +
      '<input type="text" x-model="form.puesto" class="input input-bordered" placeholder="ej: Cajero" />' +
      '</label>' +
      '<label class="form-control w-full">' +
      '<span class="label-text">Horario</span>' +
      '<input type="text" x-model="form.horario" class="input input-bordered" placeholder="ej: 9:00 - 18:00" />' +
      '</label>' +
      '<label class="form-control w-full">' +
      '<span class="label-text">Teléfono</span>' +
      '<input type="tel" x-model="form.telefono" class="input input-bordered" placeholder="ej: 555-1234" />' +
      '</label>' +
      '<label class="form-control w-full">' +
      '<span class="label-text">Turno</span>' +
      '<select x-model="form.turnoId" class="select select-bordered">' +
      '<option value="">Sin turno asignado</option>' +
      '</select>' +
      '</label>' +
      '<label class="label cursor-pointer justify-start gap-3">' +
      '<input type="checkbox" x-model="form.activo" class="checkbox checkbox-primary" checked />' +
      '<span class="label-text">Empleado activo</span>' +
      '</label>' +
      '</div>';

    await UI.modalForm(
      editando ? 'Editar empleado' : 'Nuevo empleado',
      html,
      async function(data) {
        if (editando) {
          await ModuloAsisPersonal._actualizar(id, data);
        } else {
          await ModuloAsisPersonal._guardar(data);
        }
        await ModuloAsisPersonal.cargar();
      }
    );
  },

  async _guardar(datos) {
    var registro = {
      id: uuid(),
      nombre: datos.nombre.trim(),
      puesto: datos.puesto || '',
      horario: datos.horario || '',
      telefono: datos.telefono || '',
      turnoId: datos.turnoId || '',
      activo: datos.activo !== false,
      createdBy: (window.APP_CONFIG && APP_CONFIG.usuarioActual) || 'admin',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    try {
      await db.empleados.put(registro);
      UI.toast('Empleado guardado', 'success');
    } catch (e) {
      UI.toast('Error al guardar: ' + e.message, 'error');
    }
  },

  async _actualizar(id, datos) {
    try {
      var existente = await db.empleados.get(id);
      if (!existente) {
        UI.toast('Empleado no encontrado', 'error');
        return;
      }
      existente.nombre = datos.nombre.trim();
      existente.puesto = datos.puesto || '';
      existente.horario = datos.horario || '';
      existente.telefono = datos.telefono || '';
      existente.turnoId = datos.turnoId || '';
      existente.activo = datos.activo !== false;
      existente.updatedAt = new Date();
      await db.empleados.put(existente);
      UI.toast('Empleado actualizado', 'success');
    } catch (e) {
      UI.toast('Error al actualizar: ' + e.message, 'error');
    }
  },

  async eliminar(id) {
    var item = this.items.find(function(e) { return e.id === id; });
    if (!item) return;
    var ok = await UI.confirm('¿Eliminar a <strong>' + this._esc(item.nombre) + '</strong>?<br><small class="text-base-content/50">Se eliminarán también sus marcajes y reportes.</small>', 'Eliminar empleado');
    if (!ok) return;
    try {
      await db.empleados.delete(id);
      if (window.db.marcajes) {
        var marcajes = await db.marcajes.where('empleadoId').equals(id).toArray();
        for (var m of marcajes) { await db.marcajes.delete(m.id); }
      }
      if (window.db.reportes) {
        var reportes = await db.reportes.where('empleadoId').equals(id).toArray();
        for (var r of reportes) { await db.reportes.delete(r.id); }
      }
      UI.toast('Empleado eliminado', 'success');
      await this.cargar();
    } catch (e) {
      UI.toast('Error al eliminar: ' + e.message, 'error');
    }
  },

  _esc: function(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
};

window.MODULES = window.MODULES || {};
window.MODULES[ModuloAsisPersonal.id] = ModuloAsisPersonal;

document.addEventListener('alpine:init', function() {
  Alpine.data('asisPersonalData', function() { return ModuloAsisPersonal; });
});
