﻿const ModuloObraDashboard = {
  id: 'obra-dashboard',
  titulo: 'Dashboard',
  icono: 'bi bi-grid-1x2',
  items: [],
  loading: true,
  stats: { obrasActivas: 0, totalObras: 0, presupuestoTotal: 0, presupuestoEjercido: 0, avanceGeneral: 0 },

  async init() {
    await this.cargar();
  },

  async cargar() {
    this.loading = true;
    try {
      const obras = await db.obras.toArray();
      const todasObras = obras || [];
      this.items = todasObras;
      const activas = todasObras.filter(o => o.estado === 'activa' || o.estado === 'en_progreso');
      const presupuestoTotal = todasObras.reduce((s, o) => s + (Number(o.presupuestoTotal) || 0), 0);
      let presupuestoEjercido = 0;
      let sumaAvances = 0;
      let etapasCount = 0;
      for (const obra of todasObras) {
        const gastos = await db.gastos_obra.where('obraId').equals(obra.id).toArray();
        presupuestoEjercido += gastos.reduce((s, g) => s + (Number(g.monto) || 0), 0);
        const etapas = await db.etapas.where('obraId').equals(obra.id).toArray();
        for (const etapa of etapas) {
          sumaAvances += Number(etapa.avance) || 0;
          etapasCount++;
        }
      }
      this.stats = {
        obrasActivas: activas.length,
        totalObras: todasObras.length,
        presupuestoTotal,
        presupuestoEjercido,
        avanceGeneral: etapasCount > 0 ? Math.round(sumaAvances / etapasCount) : 0
      };
    } catch (e) {
      console.error('Error cargando dashboard:', e);
    } finally {
      this.loading = false;
    }
  },

  render() {
    if (this.loading) return this.renderSkeleton();
    return \
      <div class="space-y-6">
        <div>
          <h2 class="text-2xl font-bold mb-1">Panel General</h2>
          <p class="text-base-content/60 text-sm">Resumen de todas las obras en construcción</p>
        </div>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div class="stat bg-base-100 rounded-2xl shadow-sm border border-base-200 p-4">
            <div class="stat-figure text-primary"><i class="bi bi-buildings text-2xl"></i></div>
            <div class="stat-title text-xs font-medium text-base-content/60">Obras Activas</div>
            <div class="stat-value text-3xl font-bold text-primary" x-text="\.obraDashboard.stats.obrasActivas"></div>
          </div>
          <div class="stat bg-base-100 rounded-2xl shadow-sm border border-base-200 p-4">
            <div class="stat-figure text-secondary"><i class="bi bi-archive text-2xl"></i></div>
            <div class="stat-title text-xs font-medium text-base-content/60">Total Obras</div>
            <div class="stat-value text-3xl font-bold" x-text="\.obraDashboard.stats.totalObras"></div>
          </div>
          <div class="stat bg-base-100 rounded-2xl shadow-sm border border-base-200 p-4">
            <div class="stat-figure text-accent"><i class="bi bi-cash-stack text-2xl"></i></div>
            <div class="stat-title text-xs font-medium text-base-content/60">Presupuesto Total</div>
            <div class="stat-value text-3xl font-bold text-accent" x-text="formatCurrency(\.obraDashboard.stats.presupuestoTotal)"></div>
          </div>
          <div class="stat bg-base-100 rounded-2xl shadow-sm border border-base-200 p-4">
            <div class="stat-figure text-warning"><i class="bi bi-graph-up-arrow text-2xl"></i></div>
            <div class="stat-title text-xs font-medium text-base-content/60">Avance General</div>
            <div class="stat-value text-3xl font-bold" x-text="\.obraDashboard.stats.avanceGeneral + '%'"></div>
            <progress class="progress progress-primary w-full mt-2" :value="\.obraDashboard.stats.avanceGeneral" max="100"></progress>
          </div>
        </div>
        <div class="bg-base-100 rounded-2xl shadow-sm border border-base-200 p-5">
          <h3 class="font-semibold text-lg mb-4 flex items-center gap-2"><i class="bi bi-list-check text-primary"></i> Obras Recientes</h3>
          <div class="overflow-x-auto">
            <table class="table table-sm">
              <thead>
                <tr class="text-xs uppercase text-base-content/50">
                  <th>Obra</th>
                  <th>Tipo</th>
                  <th>Estado</th>
                  <th>Presupuesto</th>
                  <th class="hidden md:table-cell">Ejercido</th>
                  <th class="hidden md:table-cell">Avance</th>
                </tr>
              </thead>
              <tbody>
                <template x-for="obra in \.obraDashboard.items" :key="obra.id">
                  <tr class="hover">
                    <td><span class="font-medium" x-text="obra.nombre"></span></td>
                    <td><span class="badge badge-ghost badge-sm" x-text="obra.tipo || '-'"></span></td>
                    <td><span :class="'badge badge-sm ' + (obra.estado === 'activa' || obra.estado === 'en_progreso' ? 'badge-success' : obra.estado === 'completada' ? 'badge-info' : 'badge-ghost')" x-text="obra.estado"></span></td>
                    <td x-text="formatCurrency(obra.presupuestoTotal)"></td>
                    <td class="hidden md:table-cell" x-text="'-'"></td>
                    <td class="hidden md:table-cell"><progress class="progress progress-primary w-20" :value="obra.avance || 0" max="100"></progress></td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
          <div x-show="\.obraDashboard.items.length === 0" class="text-center py-8 text-base-content/40">
            <i class="bi bi-inbox text-4xl block mb-2"></i>
            <p class="text-sm">No hay obras registradas. Crea una desde el módulo de Obras.</p>
          </div>
        </div>
      </div>
    \;
  },

  renderSkeleton() {
    return \
      <div class="space-y-6">
        <div class="sk-heading"></div>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
          \
        </div>
        <div class="sk-card h-64"></div>
      </div>
    \;
  },

  destroy() {
    this.items = [];
    this.loading = true;
    this.stats = { obrasActivas: 0, totalObras: 0, presupuestoTotal: 0, presupuestoEjercido: 0, avanceGeneral: 0 };
  }
};

function formatCurrency(n) {
  const v = Number(n) || 0;
  return '$' + v.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

window.MODULES = window.MODULES || {};
window.MODULES[ModuloObraDashboard.id] = ModuloObraDashboard;

document.addEventListener('alpine:init', () => {
  Alpine.data('obraDashboardData', () => ModuloObraDashboard);
  if (!Alpine.\.obraDashboard) {
    Alpine.store('obraDashboard', {
      get items() { return ModuloObraDashboard.items; },
      get stats() { return ModuloObraDashboard.stats; }
    });
  }
});
