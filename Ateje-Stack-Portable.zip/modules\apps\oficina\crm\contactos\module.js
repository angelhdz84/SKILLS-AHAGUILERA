const ModuloCRMContactos = {
  id: 'crm-contactos',
  titulo: 'Contactos',
  icono: 'bi bi-people',

  items: [],
  searchQuery: '',
  loading: true,

  async init() {
    await this.cargar();
  },

  render() {
    return `
      <div x-data="crmContactosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-blue-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-people text-blue-600"></i> Contactos
          </h2>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Contacto</button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="filtrar" placeholder="Buscar nombre, empresa..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 outline-none transition-shadow" />
          </div>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-people text-6xl mb-4"></i><p class="text-lg text-gray-500">Sin contactos</p><button class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors" @click="abrirForm()"><i class="bi bi-plus-lg"></i> Agregar</button></div>
        </template>

        <template x-if="items.length > 0">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="c in items" :key="c.id">
              <div class="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md hover:-translate-y-0.5 transition-all cursor-pointer" @click="verDetalle(c)">
                <div class="flex items-start gap-3">
                  <div class="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-sm shrink-0" x-text="(c.nombre || '?')[0].toUpperCase()"></div>
                  <div class="min-w-0 flex-1">
                    <h3 class="font-semibold text-gray-900 text-sm truncate" x-text="c.nombre"></h3>
                    <p class="text-xs text-gray-500" x-text="c.empresa || c.email || ''"></p>
                    <p class="text-xs text-gray-400 mt-1"><i class="bi bi-telephone"></i> <span x-text="c.telefono || '\u2014'"></span></p>
                  </div>
                </div>
              </div>
            </template>
          </div>
        </template>

        <template x-if="loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"><template x-for="i in 6" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-10 w-10 bg-gray-200 rounded-full animate-pulse mb-3"></div><div class="h-4 w-32 bg-gray-200 rounded animate-pulse mb-2"></div><div class="h-3 w-24 bg-gray-200 rounded animate-pulse"></div></div></template></div>
        </template>
      </div>
    `;
  },

  destroy() { this.items = []; this.searchQuery = ''; this.loading = true; },

  async cargar() {
    try {
      this.loading = true;
      this.items = await db.contactos.orderBy('nombre').toArray();
    } catch (e) { console.error(e); UI.toast('Error', 'error'); }
    finally { this.loading = false; }
  },

  async cargarCRMContactos() {
    try { this.items = await db.contactos.orderBy('nombre').toArray(); } catch (e) { console.error(e); }
  },

  filtrar() {
    Promise.resolve().then(async () => {
      try {
        this.loading = true;
        let datos = await db.contactos.orderBy('nombre').toArray();
        const q = this.searchQuery.trim().toLowerCase();
        if (q) datos = datos.filter(c => (c.nombre || '').toLowerCase().includes(q) || (c.empresa || '').toLowerCase().includes(q) || (c.telefono || '').includes(q));
        this.items = datos;
      } catch (e) { console.error(e); }
      finally { this.loading = false; }
    });
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label><input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Tel\u00e9fono</label><input type="tel" x-model="form.telefono" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input type="email" x-model="form.email" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Empresa</label><input type="text" x-model="form.empresa" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" /></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Notas</label><textarea x-model="form.notas" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow"></textarea></div></div>';
    await UI.modalForm(editando ? 'Editar' : 'Nuevo Contacto', html,
      async (data) => {
        if (!data.nombre?.trim()) { UI.toast('Nombre requerido', 'error'); return; }
        if (editando) {
          const e = await db.contactos.get(item.id);
          if (!e) { UI.toast('No encontrado', 'error'); return; }
          await db.contactos.put({ ...e, nombre: data.nombre.trim(), telefono: data.telefono || '', email: data.email || '', empresa: data.empresa || '', notas: data.notas || '', updatedAt: new Date().toISOString() });
        } else {
          await db.contactos.put({ id: window.uuid(), nombre: data.nombre.trim(), telefono: data.telefono || '', email: data.email || '', empresa: data.empresa || '', notas: data.notas || '', createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        }
        UI.toast(editando ? 'Actualizado' : 'Guardado', 'success');
        await this.cargar();
      }, item || { nombre: '', telefono: '', email: '', empresa: '', notas: '' }
    );
  },

  async verDetalle(item) {
    const interacciones = await db.interacciones?.where('contactoId').equals(item.id).reverse().sortBy('createdAt') || [];
    const html = [
      '<div class="space-y-3">',
      '<p class="text-xs text-gray-400"><i class="bi bi-telephone"></i> ' + (item.telefono || '\u2014') + ' \u00b7 <i class="bi bi-envelope"></i> ' + (item.email || '\u2014') + '</p>',
      '<p class="text-sm" x-text="item.empresa ? \'Empresa: \' + item.empresa : \'\'"></p>',
      '<div class="border-t border-gray-200 pt-2"><h4 class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">Interacciones</h4>',
      interacciones.length === 0 ? '<p class="text-gray-400 text-sm">Sin interacciones</p>' : interacciones.map(i => '<div class="flex items-start gap-2 py-1.5 border-b border-gray-100 last:border-0"><span class="text-xs text-gray-400 shrink-0 w-16">' + (i.createdAt || '').slice(0, 10) + '</span><span class="text-xs font-medium ' + (i.tipo === 'llamada' ? 'text-blue-600' : i.tipo === 'reunion' ? 'text-purple-600' : 'text-gray-600') + '">' + (i.tipo || '') + '</span><span class="text-sm text-gray-700">' + (i.nota || '') + '</span></div>').join(''),
      '</div></div>'
    ].join('\n');
    const btns = '<button class="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white text-xs font-medium rounded-lg hover:bg-blue-700" onclick="addInteraccion(\'' + item.id + '\')"><i class="bi bi-plus-lg"></i> Interacci\u00f3n</button> <button class="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-100 text-blue-700 text-xs font-medium rounded-lg hover:bg-blue-200" onclick="editContacto(\'' + item.id + '\')"><i class="bi bi-pencil"></i> Editar</button>';
    UI.modalHtml(item.nombre + ' ' + btns, html);
  },

  async registrarInteraccion(contactoId) {
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Tipo</label><select x-model="form.tipo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow bg-white"><option value="llamada">Llamada</option><option value="reunion">Reuni\u00f3n</option><option value="nota">Nota</option></select></div><div><label class="block text-sm font-medium text-gray-700 mb-1">Nota</label><textarea x-model="form.nota" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-shadow"></textarea></div></div>';
    await UI.modalForm('Nueva interacci\u00f3n', html, async (data) => {
      await db.interacciones.put({ id: window.uuid(), contactoId, tipo: data.tipo, nota: data.nota?.trim() || '', createdBy: APP_CONFIG?.usuarioActual || 'anon', createdAt: new Date().toISOString() });
      UI.toast('Registrada', 'success');
    }, { tipo: 'nota', nota: '' });
  }
};

window.addInteraccion = function(id) { const m = window.MODULES['crm-contactos']; if (m) m.registrarInteraccion(id); };
window.editContacto = function(id) { const m = window.MODULES['crm-contactos']; if (m) { const c = m.items.find(x => x.id === id); if (c) m.abrirForm(c); } };

window.MODULES = window.MODULES || {};
window.MODULES['crm-contactos'] = ModuloCRMContactos;

document.addEventListener('alpine:init', () => {
  Alpine.data('crmContactosData', () => ModuloCRMContactos);
});
