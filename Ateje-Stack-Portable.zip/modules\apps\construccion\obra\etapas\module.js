﻿const ModuloObraEtapas = {
  id: 'obra-etapas',
  titulo: 'Etapas',
  icono: 'bi bi-diagram-3',
  items: [],
  loading: true,
  obraSeleccionada: null,
  obras: [],

  async init() {
    await this.cargarObras();
    await this.cargar();
  },

  async cargarObras() {
    try {
      this.obras = await db.obras.toArray();
    } catch (e) {
      this.obras = [];
    }
  },

  async cargar() {
    this.loading = true;
    try {
      let query = db.etapas.orderBy('createdAt').reverse();
      if (this.obraSeleccionada) {
        query = db.etapas.where('obraId').equals(this.obraSeleccionada);
      }
      this.items = await query.toArray();
    } catch (e) {
      console.error('Error cargando etapas:', e);
      this.items = [];
    } finally {
      this.loading = false;
    }
  },

  render() {
    if (this.loading) return this.renderSkeleton();
    return \
      <div class="space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <h2 class="text-2xl font-bold flex items-center gap-2">
            <i class="bi bi-diagram-3 text-orange-500"></i> Etapas
          </h2>
          <div class="flex gap-2">
            <select x-model="obraEtapasData.obraSeleccionada" @change="obraEtapasData.cargar()" class="select select-bordered select-sm">
              <option value="">Todas las obras</option>
              <template x-for="obra in obraEtapasData.obras" :key="obra.id">
                <option :value="obra.id" x-text="obra.nombre"></option>
              </template>
            </select>
            <button @click="obraEtapasData.abrirForm()" class="btn btn-primary btn-sm gap-1">
              <i class="bi bi-plus-lg"></i> Agregar
            </button>
          </div>
        </div>
        <div x-show="obraEtapasData.items.length === 0" class="empty-state">
          <div class="empty-state-icon bg-orange-50"><i class="bi bi-diagram-3 text-orange-400"></i></div>
          <div class="empty-state-title">Sin etapas</div>
          <div class="empty-state-desc">Agrega la primera etapa de obra</div>
          <button @click="obraEtapasData.abrirForm()" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Agregar etapa</button>
        </div>
        <div x-show="obraEtapasData.items.length > 0" class="overflow-x-auto">
          <table class="table table-zebra">
            <thead>
              <tr class="text-xs uppercase text-base-content/50">
                <th>Nombre</th>
                <th class="hidden sm:table-cell">Obra</th>
                <th>Estado</th>
                <th>Avance</th>
                <th class="text-right">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <template x-for="(item, i) in obraEtapasData.items" :key="item.id">
                <tr class="stagger-item" :style="'animation-delay: ' + (i * 0.04) + 's'">
                  <td><span class="font-medium" x-text="item.nombre"></span></td>
                  <td class="hidden sm:table-cell">
                    <span class="badge badge-ghost badge-sm" x-text="obraEtapasData.obras.find(o => o.id === item.obraId)?.nombre || '-'"></span>
                  </td>
                  <td>
                    <span :class="'badge badge-sm ' + (item.estado === 'completada' ? 'badge-success' : item.estado === 'en_progreso' ? 'badge-warning' : 'badge-ghost')" x-text="item.estado || 'pendiente'"></span>
                  </td>
                  <td class="w-40">
                    <div class="flex items-center gap-2">
                      <progress class="progress progress-orange w-full" :value="item.avance || 0" max="100"></progress>
                      <span class="text-xs font-medium w-8 text-right" x-text="(item.avance || 0) + '%'"></span>
                    </div>
                  </td>
                  <td class="text-right">
                    <div class="flex gap-1 justify-end">
                      <button @click="obraEtapasData.abrirForm(item)" class="btn btn-ghost btn-xs btn-square" title="Editar"><i class="bi bi-pencil"></i></button>
                      <button @click="obraEtapasData.eliminar(item)" class="btn btn-ghost btn-xs btn-square text-error" title="Eliminar"><i class="bi bi-trash"></i></button>
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
    \;
  },

  renderSkeleton() {
    return \
      <div class="space-y-4">
        <div class="sk-heading w-40"></div>
        <div class="sk-row"></div>
        \
      </div>
    \;
  },

  async abrirForm(item) {
    const editando = !!item;
    const obraOptions = this.obras.map(o => \<option value="\" \>\</option>\).join('');
    const estados = ['pendiente', 'en_progreso', 'completada'];
    const estadoOptions = estados.map(e => \<option value="\" \>\</option>\).join('');
    const html = \
      <div class="space-y-4">
        <label class="form-control w-full">
          <span class="label-text">Nombre de la etapa</span>
          <input type="text" x-model="form.nombre" class="input input-bordered" required />
        </label>
        <label class="form-control w-full">
          <span class="label-text">Obra</span>
          <select x-model="form.obraId" class="select select-bordered" required>
            <option value="">Seleccionar obra</option>
            \
          </select>
        </label>
        <div class="grid grid-cols-2 gap-4">
          <label class="form-control w-full">
            <span class="label-text">Estado</span>
            <select x-model="form.estado" class="select select-bordered">
              \
            </select>
          </label>
          <label class="form-control w-full">
            <span class="label-text">Avance (%)</span>
            <input type="number" x-model="form.avance" class="input input-bordered" min="0" max="100" />
          </label>
        </div>
      </div>
    \;
    await UI.modalForm(
      editando ? 'Editar etapa' : 'Nueva etapa',
      html,
      async (data) => {
        const payload = {
          obraId: data.obraId,
          nombre: data.nombre,
          estado: data.estado || 'pendiente',
          avance: Number(data.avance) || 0
        };
        if (editando) {
          await this.actualizar(item.id, payload);
        } else {
          await this.guardar(payload);
        }
      }
    );
  },

  async guardar(datos) {
    const registro = {
      id: uuid(),
      ...datos,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    await db.etapas.put(registro);
    UI.toast('Etapa guardada', 'success');
    await this.cargar();
  },

  async actualizar(id, datos) {
    const existente = await db.etapas.get(id);
    if (!existente) { UI.toast('Etapa no encontrada', 'error'); return; }
    const actualizado = { ...existente, ...datos, id, updatedAt: new Date().toISOString() };
    await db.etapas.put(actualizado);
    UI.toast('Etapa actualizada', 'success');
    await this.cargar();
  },

  async eliminar(item) {
    const ok = await UI.confirm(\Eliminar la etapa "\"?\);
    if (!ok) return;
    try {
      await db.etapas.delete(item.id);
      UI.toast('Etapa eliminada', 'success');
      await this.cargar();
    } catch (e) {
      UI.toast(e.message, 'error');
    }
  },

  destroy() {
    this.items = [];
    this.loading = true;
    this.obraSeleccionada = null;
  }
};

window.MODULES = window.MODULES || {};
window.MODULES[ModuloObraEtapas.id] = ModuloObraEtapas;

document.addEventListener('alpine:init', () => {
  Alpine.data('obraEtapasData', () => ModuloObraEtapas);
});
