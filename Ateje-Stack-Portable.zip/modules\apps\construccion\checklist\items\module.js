const ModuloChkItems = {
  id: 'chk-items',
  titulo: 'Equipos',
  icono: 'bi bi-tools',

  items: [],
  ubicaciones: [],
  errors: {},
  searchQuery: '',
  filtroUbicacion: '',
  loading: true,
  saving: false,
  kpis: { total: 0, conFrecuencia: 0, pendientes: 0 },

  async init() {
    await Promise.all([this.cargar(), this.cargarUbicaciones()]);
  },

  render() {
    return `
      <div x-data="chkItemsData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-indigo-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-tools text-indigo-600"></i> Equipos
          </h2>
        </div>

        <div class="grid grid-cols-3 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Con frecuencia</p>
            <p class="text-2xl font-bold text-indigo-600" x-text="kpis.conFrecuencia"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Pendientes</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.pendientes"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Equipo
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="cargar" placeholder="Buscar por nombre o c\u00f3digo..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow" />
          </div>
          <select x-model="filtroUbicacion" @change="cargar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow">
            <option value="">Todas las ubicaciones</option>
            <template x-for="u in ubicaciones" :key="u.id">
              <option :value="u.id" x-text="u.nombre"></option>
            </template>
          </select>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-tools text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">No hay equipos</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Registrar primero
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="overflow-x-auto rounded-lg border border-gray-200">
            <table class="w-full text-sm">
              <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Equipo</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">C\u00f3digo</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Ubicaci\u00f3n</th>
                  <th class="text-center px-4 py-3 font-semibold text-gray-600">Frecuencia</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Acciones</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-100">
                <template x-for="(item, idx) in items" :key="item.id">
                  <tr class="hover:bg-gray-50 transition-colors cursor-pointer"
                      :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'"
                      @click="abrirForm(item)">
                    <td class="px-4 py-3">
                      <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                          <i class="bi bi-gear text-sm"></i>
                        </div>
                        <span class="text-gray-900 font-medium" x-text="item.nombre"></span>
                      </div>
                    </td>
                    <td class="px-4 py-3">
                      <code class="text-xs bg-gray-100 px-2 py-0.5 rounded text-gray-600" x-text="item.codigo || '\u2014'"></code>
                    </td>
                    <td class="px-4 py-3 text-gray-500" x-text="nombreUbicacion(item.ubicacionId)"></td>
                    <td class="px-4 py-3 text-center">
                      <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                            :class="item.frecuencia ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'"
                            x-text="item.frecuencia || 'Sin programar'"></span>
                    </td>
                    <td class="px-4 py-3 text-right">
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors" @click.stop="abrirForm(item)" title="Editar">
                        <i class="bi bi-pencil"></i>
                      </button>
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" @click.stop="eliminar(item)" title="Eliminar">
                        <i class="bi bi-trash"></i>
                      </button>
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i">
              <div class="h-14 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.ubicaciones = [];
    this.searchQuery = '';
    this.filtroUbicacion = '';
    this.loading = true;
    this.kpis = { total: 0, conFrecuencia: 0, pendientes: 0 };
  },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return f; } },
  nombreUbicacion(id) { const u = this.ubicaciones.find(x => x.id === id); return u ? u.nombre : '\u2014'; },

  async cargar() {
    try {
      this.loading = true;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.equipos.orderBy('createdAt').reverse().toArray();
      if (filtro) datos = datos.filter(e => (e.nombre || '').toLowerCase().includes(filtro) || (e.codigo || '').toLowerCase().includes(filtro));
      if (this.filtroUbicacion) datos = datos.filter(e => e.ubicacionId === this.filtroUbicacion);
      this.items = datos;
      this.kpis = {
        total: datos.length,
        conFrecuencia: datos.filter(e => !!e.frecuencia).length,
        pendientes: 0
      };
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarUbicaciones() {
    try { this.ubicaciones = await db.ubicaciones.orderBy('nombre').toArray(); }
    catch (e) { console.error(e); }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div class="grid grid-cols-2 gap-4">',
      '<div class="col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>',
      '<input type="text" x-model="form.nombre" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.nombre ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500\'" />',
      '<template x-if="errors.nombre"><p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">C\u00f3digo</label>',
      '<input type="text" x-model="form.codigo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Ubicaci\u00f3n</label>',
      '<select x-model="form.ubicacionId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition-shadow bg-white">',
      '<option value="">Sin ubicaci\u00f3n</option>',
      '<template x-for="u in ubicaciones" :key="u.id"><option :value="u.id" x-text="u.nombre"></option></template>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Frecuencia</label>',
      '<select x-model="form.frecuencia" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition-shadow bg-white">',
      '<option value="">Sin programar</option>',
      '<option value="Diario">Diario</option>',
      '<option value="Semanal">Semanal</option>',
      '<option value="Quincenal">Quincenal</option>',
      '<option value="Mensual">Mensual</option>',
      '<option value="Bimestral">Bimestral</option>',
      '<option value="Trimestral">Trimestral</option>',
      '<option value="Semestral">Semestral</option>',
      '<option value="Anual">Anual</option>',
      '</select></div>',
      '</div></div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Equipo' : 'Nuevo Equipo', html,
      async (data) => {
        if (editando) await this.actualizar(item.id, data);
        else await this.guardar(data);
        await this.cargar();
      }, item || { nombre: '', codigo: '', ubicacionId: '', frecuencia: '' }
    );
  },

  validarForm(d) {
    this.errors = {};
    if (!d.nombre || !d.nombre.trim()) this.errors.nombre = 'El nombre es obligatorio';
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    try {
      await db.equipos.put({
        id: uuid(), nombre: datos.nombre.trim(), codigo: datos.codigo?.trim() || '',
        ubicacionId: datos.ubicacionId || '', frecuencia: datos.frecuencia || '',
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      });
      UI.toast('Equipo guardado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    try {
      const e = await db.equipos.get(id);
      if (!e) { UI.toast('No encontrado', 'error'); return; }
      await db.equipos.put({ ...e, nombre: datos.nombre.trim(), codigo: datos.codigo?.trim() || '',
        ubicacionId: datos.ubicacionId || '', frecuencia: datos.frecuencia || '',
        updatedAt: new Date().toISOString() });
      UI.toast('Equipo actualizado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar ' + (item.nombre || 'este equipo') + '?');
    if (!ok) return;
    try { await db.equipos.delete(item.id); UI.toast('Eliminado', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['chk-items'] = ModuloChkItems;

document.addEventListener('alpine:init', () => {
  Alpine.data('chkItemsData', () => ModuloChkItems);
});
