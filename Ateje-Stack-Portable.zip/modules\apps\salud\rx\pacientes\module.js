const ModuloRxPacientes = {
  id: 'rx-pacientes',
  titulo: 'Pacientes',
  icono: 'bi bi-people',

  items: [],
  loading: true,
  searchQuery: '',

  async init() {
    await this.cargar();
  },

  render() {
    return `
      <div x-data="rxPacientesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-cyan-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-people text-cyan-600"></i> Pacientes
          </h2>
        </div>
        <div class="flex flex-wrap items-center gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-cyan-600 text-white text-sm font-medium rounded-lg hover:bg-cyan-700 shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Paciente
          </button>
          <div class="relative flex-1 max-w-xs ml-auto">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input type="search" x-model="searchQuery" @input.debounce="buscar" placeholder="Buscar..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-cyan-500" />
          </div>
        </div>
        <template x-if="loading">
          <div class="space-y-3"><template x-for="i in 5" :key="i"><div class="h-16 bg-gray-100 rounded-lg animate-pulse"></div></template></div>
        </template>
        <template x-if="!loading && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-people text-6xl mb-4"></i>
            <p class="text-lg text-gray-500">Sin pacientes</p>
            <button class="mt-4 px-4 py-2 bg-cyan-600 text-white text-sm rounded-lg" @click="abrirForm()">Agregar primero</button>
          </div>
        </template>
        <template x-if="!loading && items.length > 0">
          <div class="overflow-x-auto bg-white rounded-xl border border-gray-200">
            <table class="w-full text-sm">
              <thead><tr class="border-b border-gray-100 bg-gray-50">
                <th class="text-left px-4 py-3 font-semibold text-gray-600">Nombre</th>
                <th class="text-left px-4 py-3 font-semibold text-gray-600">Teléfono</th>
                <th class="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">Alergias</th>
                <th class="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">Creado</th>
                <th class="text-right px-4 py-3 font-semibold text-gray-600">Acciones</th>
              </tr></thead>
              <tbody>
                <template x-for="item in items" :key="item.id">
                  <tr class="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td class="px-4 py-3 font-medium text-gray-900" x-text="item.nombre"></td>
                    <td class="px-4 py-3 text-gray-600" x-text="item.telefono || '—'"></td>
                    <td class="px-4 py-3 text-gray-500 hidden md:table-cell">
                      <span x-show="item.alergias" class="inline-flex items-center gap-1 px-2 py-0.5 bg-red-50 text-red-600 text-xs rounded-full" x-text="item.alergias"></span>
                      <span x-show="!item.alergias" class="text-gray-300">—</span>
                    </td>
                    <td class="px-4 py-3 text-gray-400 text-xs hidden md:table-cell" x-text="item.createdAt ? new Date(item.createdAt).toLocaleDateString() : '—'"></td>
                    <td class="px-4 py-3 text-right">
                      <button class="text-gray-400 hover:text-cyan-600 px-2" @click="abrirForm(item)" title="Editar"><i class="bi bi-pencil"></i></button>
                      <button class="text-gray-400 hover:text-red-600 px-2" @click="eliminar(item)" title="Eliminar"><i class="bi bi-trash"></i></button>
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
        </template>
      </div>`;
  },

  destroy() { this.items = []; this.loading = true; this.searchQuery = ''; },

  async cargar() {
    try {
      this.loading = true;
      this.items = await db.pacientes.orderBy('nombre').toArray();
    } catch (e) {
      console.error(e);
      UI.toast('Error al cargar pacientes', 'error');
    } finally {
      this.loading = false;
    }
  },

  async buscar(q) {
    this.searchQuery = q;
    try {
      this.loading = true;
      if (!q || q.length < 2) {
        this.items = await db.pacientes.orderBy('nombre').toArray();
      } else {
        const term = q.toLowerCase();
        const all = await db.pacientes.toArray();
        this.items = all.filter(p =>
          (p.nombre && p.nombre.toLowerCase().includes(term)) ||
          (p.telefono && p.telefono.includes(term))
        );
      }
    } catch (e) {
      console.error(e);
    } finally {
      this.loading = false;
    }
  },

  async abrirForm(item) {
    const editando = !!item;
    const html = '<div class="space-y-4">' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre *</label><input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-cyan-500" /></div>' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Teléfono</label><input type="text" x-model="form.telefono" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-cyan-500" /></div>' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Dirección</label><textarea x-model="form.direccion" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-cyan-500" rows="2"></textarea></div>' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Fecha de nacimiento</label><input type="date" x-model="form.fechaNacimiento" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-cyan-500" /></div>' +
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Alergias</label><textarea x-model="form.alergias" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-cyan-500" rows="2" placeholder="Especificar alergias conocidas..."></textarea></div>' +
      '</div>';
    await UI.modalForm(editando ? 'Editar Paciente' : 'Nuevo Paciente', html, async (data) => {
      if (!data.nombre?.trim()) { UI.toast('El nombre es requerido', 'error'); return; }
      if (editando) {
        const existente = await db.pacientes.get(item.id);
        if (!existente) return;
        await db.pacientes.put({ ...existente, ...data, updatedAt: new Date().toISOString() });
      } else {
        await db.pacientes.put({ id: window.uuid(), ...data, createdBy: 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      }
      UI.toast(editando ? 'Paciente actualizado' : 'Paciente creado', 'success');
      await this.cargar();
    }, editando ? { nombre: item.nombre, telefono: item.telefono || '', direccion: item.direccion || '', fechaNacimiento: item.fechaNacimiento || '', alergias: item.alergias || '' } : { nombre: '', telefono: '', direccion: '', fechaNacimiento: '', alergias: '' });
  },

  async eliminar(item) {
    const ok = await UI.confirm('¿Eliminar a ' + item.nombre + '?');
    if (!ok) return;
    try {
      const recetas = await db.recetas.where('pacienteId').equals(item.id).count();
      if (recetas > 0) {
        UI.toast('No se puede eliminar: el paciente tiene recetas asociadas', 'error');
        return;
      }
      await db.pacientes.delete(item.id);
      UI.toast('Paciente eliminado', 'success');
      await this.cargar();
    } catch (e) {
      UI.toast(e.message, 'error');
    }
  }
};
window.MODULES = window.MODULES || {};
window.MODULES[ModuloRxPacientes.id] = ModuloRxPacientes;
document.addEventListener('alpine:init', () => { Alpine.data('rxPacientesData', () => ModuloRxPacientes); });
