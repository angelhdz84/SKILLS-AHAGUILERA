# AHA Asistencia — Spec Técnica

## Identidad
- **App:** AHA Asistencia
- **Perfil:** Lite
- **Target:** Pequeñas empresas, talleres, tiendas, restaurantes, consultorios
- **Tagline:** Control de asistencia de empleados offline
- **Color primario:** #7c3aed (violet-600)
- **Descripción:** Registro de entrada/salida sin internet. Reportes de horas para nómina.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  empleados: 'id, nombre, *puesto, *horario, telefono, activo, *createdBy, createdAt, updatedAt',
  turnos: 'id, nombre, *horaEntrada, *horaSalida, createdAt, updatedAt',
  marcajes: 'id, *empleadoId, *tipo, *fecha, *hora, *ubicacion, *metodo, *createdBy, createdAt',
  reportes: 'id, *empleadoId, *periodo, *totalHoras, *retardos, *faltas, *createdBy, createdAt, updatedAt',
  festivos: 'id, *fecha, nombre, createdAt, updatedAt',
  _sync_log, _ia_chats, _ia_messages
});
```

## Entry point
`core/main.js`

## Módulos (4)

### empleados
- CRUD: nombre, puesto, horario, teléfono, activo/inactivo
- Foto opcional (avatar)
- Lista con búsqueda

### marcajes
- Dashboard: empleados hoy, marcados vs pendientes, retardos del día, últimos marcajes
- Grid de empleados con foto → tap para marcar entrada/salida
- Marcado manual con confirmación
- Validación: no permitir doble entrada sin salida

### reportes
- Selector período (día/semana/mes)
- Tabla de horas: empleado, total horas, retardos, faltas
- Vista calendario mensual con colores (verde=completo, amarillo=retardo, rojo=falta)
- Export CSV

### configuracion
- Turnos predefinidos (matutino 8-16, vespertino 14-22)
- Tolerancia de retardo (minutos, default 15)
- Días festivos (CRUD)
- Backup automático

## Estructura
```
aha-asistencia/
├── index.html, manifest.json, sw.js, project.config.js, .gitignore, README.md
├── core/ (main, app, db, crypto, theme, ui, env, network, sync, seed, search-palette, file-store, license)
├── modules/
│   ├── empleados/module.html + module.js
│   ├── marcajes/module.html + module.js
│   ├── reportes/module.html + module.js
│   └── configuracion/module.html + module.js
├── assets/
└── data/
```

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema violet (primary: #7c3aed)
- ES5 estricto
