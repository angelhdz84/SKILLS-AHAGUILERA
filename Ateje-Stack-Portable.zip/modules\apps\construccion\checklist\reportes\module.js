const ModuloChkReportes = {
  id: 'chk-reportes',
  titulo: 'Inspecciones',
  icono: 'bi bi-clipboard-data',

  items: [],
  plantillas: [],
  ubicaciones: [],
  equipos: [],
  errors: {},
  searchQuery: '',
  filtroResultado: '',
  filtroUbicacion: '',
  loading: true,
  saving: false,
  kpis: { total: 0, aprobadas: 0, rechazadas: 0, observadas: 0 },

  async init() {
    await Promise.all([this.cargar(), this.cargarReferencias()]);
  },

  render() {
    return `
      <div x-data="chkReportesData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-amber-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-clipboard-data text-amber-600"></i> Inspecciones
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Aprobadas</p>
            <p class="text-2xl font-bold text-green-600" x-text="kpis.aprobadas"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Observadas</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.observadas"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Rechazadas</p>
            <p class="text-2xl font-bold text-red-600" x-text="kpis.rechazadas"></p>
          </div>
        </div>

        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition-colors shadow-sm" @click="abrirForm()">
            <i class="bi bi-plus-lg"></i> Inspecci\u00f3n
          </button>
          <div class="relative flex-1 min-w-[200px]">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input type="search" x-model="searchQuery" @input.debounce="cargar" placeholder="Buscar inspecciones..."
                   class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition-shadow" />
          </div>
          <select x-model="filtroResultado" @change="cargar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-amber-500 outline-none transition-shadow">
            <option value="">Todos los resultados</option>
            <option value="aprobado">Aprobado</option>
            <option value="observado">Observado</option>
            <option value="rechazado">Rechazado</option>
          </select>
          <select x-model="filtroUbicacion" @change="cargar"
                  class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-amber-500 outline-none transition-shadow">
            <option value="">Todas las ubicaciones</option>
            <template x-for="u in ubicaciones" :key="u.id">
              <option :value="u.id" x-text="u.nombre"></option>
            </template>
          </select>
          <button class="inline-flex items-center gap-1.5 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors" @click="exportarCSV()" x-show="items.length">
            <i class="bi bi-download"></i> CSV
          </button>
        </div>

        <template x-if="items.length === 0 && !loading">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400">
            <i class="bi bi-clipboard-data text-6xl mb-4"></i>
            <p class="text-lg text-gray-500 mb-2">No hay inspecciones</p>
            <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition-colors" @click="abrirForm()">
              <i class="bi bi-plus-lg"></i> Realizar primera
            </button>
          </div>
        </template>

        <template x-if="items.length > 0">
          <div class="overflow-x-auto rounded-lg border border-gray-200">
            <table class="w-full text-sm">
              <thead>
                <tr class="bg-gray-50 border-b border-gray-200">
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Plantilla</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Ubicaci\u00f3n / Equipo</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Resultado</th>
                  <th class="text-left px-4 py-3 font-semibold text-gray-600">Fecha</th>
                  <th class="text-right px-4 py-3 font-semibold text-gray-600">Acciones</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-100">
                <template x-for="(item, idx) in items" :key="item.id">
                  <tr class="hover:bg-gray-50 transition-colors"
                      :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'">
                    <td class="px-4 py-3">
                      <span class="text-gray-900 font-medium" x-text="nombrePlantilla(item.plantillaId)"></span>
                    </td>
                    <td class="px-4 py-3">
                      <span class="text-gray-500 text-xs" x-text="(nombreUbicacion(item.ubicacionId) || '\u2014') + ' / ' + (nombreEquipo(item.equipoId) || '\u2014')"></span>
                    </td>
                    <td class="px-4 py-3">
                      <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium"
                            :class="item.resultado === 'aprobado' ? 'bg-green-100 text-green-700' : item.resultado === 'rechazado' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'">
                        <span class="w-1.5 h-1.5 rounded-full"
                              :class="item.resultado === 'aprobado' ? 'bg-green-500' : item.resultado === 'rechazado' ? 'bg-red-500' : 'bg-amber-500'"></span>
                        <span x-text="capitalize(item.resultado || 'pendiente')"></span>
                      </span>
                    </td>
                    <td class="px-4 py-3 text-gray-500" x-text="formatearFecha(item.createdAt)"></td>
                    <td class="px-4 py-3 text-right">
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors" @click="verDetalle(item)" title="Ver detalle">
                        <i class="bi bi-eye"></i>
                      </button>
                      <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" @click="eliminar(item)" title="Eliminar">
                        <i class="bi bi-trash"></i>
                      </button>
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i">
              <div class="h-14 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.items = [];
    this.plantillas = [];
    this.ubicaciones = [];
    this.equipos = [];
    this.searchQuery = '';
    this.filtroResultado = '';
    this.filtroUbicacion = '';
    this.loading = true;
    this.kpis = { total: 0, aprobadas: 0, rechazadas: 0, observadas: 0 };
  },

  capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; },
  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch { return f; } },
  nombrePlantilla(id) { const p = this.plantillas.find(x => x.id === id); return p ? p.nombre : '\u2014'; },
  nombreUbicacion(id) { const u = this.ubicaciones.find(x => x.id === id); return u ? u.nombre : ''; },
  nombreEquipo(id) { const e = this.equipos.find(x => x.id === id); return e ? e.nombre : ''; },

  async cargar() {
    try {
      this.loading = true;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.inspecciones.orderBy('createdAt').reverse().toArray();
      if (filtro) datos = datos.filter(r => (r.resultado || '').toLowerCase().includes(filtro));
      if (this.filtroResultado) datos = datos.filter(r => r.resultado === this.filtroResultado);
      if (this.filtroUbicacion) datos = datos.filter(r => r.ubicacionId === this.filtroUbicacion);
      this.items = datos;
      this.kpis = {
        total: datos.length,
        aprobadas: datos.filter(r => r.resultado === 'aprobado').length,
        rechazadas: datos.filter(r => r.resultado === 'rechazado').length,
        observadas: datos.filter(r => r.resultado === 'observado').length
      };
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarReferencias() {
    try {
      const [plantillas, ubicaciones, equipos] = await Promise.all([
        db.plantillas.orderBy('nombre').toArray(),
        db.ubicaciones.orderBy('nombre').toArray(),
        db.equipos.orderBy('nombre').toArray()
      ]);
      this.plantillas = plantillas;
      this.ubicaciones = ubicaciones;
      this.equipos = equipos;
    } catch (e) { console.error(e); }
  },

  async abrirForm() {
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Plantilla <span class="text-red-500">*</span></label>',
      '<select x-model="form.plantillaId" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.plantillaId ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500\'" @change="cargarItemsPlantilla">',
      '<option value="">Seleccionar plantilla...</option>',
      '<template x-for="p in plantillas" :key="p.id"><option :value="p.id" x-text="p.nombre"></option></template>',
      '</select><template x-if="errors.plantillaId"><p class="mt-1 text-sm text-red-500" x-text="errors.plantillaId"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Ubicaci\u00f3n</label>',
      '<select x-model="form.ubicacionId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500 transition-shadow bg-white">',
      '<option value="">Sin ubicaci\u00f3n</option>',
      '<template x-for="u in ubicaciones" :key="u.id"><option :value="u.id" x-text="u.nombre"></option></template>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Equipo</label>',
      '<select x-model="form.equipoId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500 transition-shadow bg-white">',
      '<option value="">Sin equipo</option>',
      '<template x-for="e in equipos" :key="e.id"><option :value="e.id" x-text="e.nombre"></option></template>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Resultado <span class="text-red-500">*</span></label>',
      '<select x-model="form.resultado" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.resultado ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500\'">',
      '<option value="">Seleccionar...</option>',
      '<option value="aprobado">Aprobado</option>',
      '<option value="observado">Observado</option>',
      '<option value="rechazado">Rechazado</option>',
      '</select><template x-if="errors.resultado"><p class="mt-1 text-sm text-red-500" x-text="errors.resultado"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Notas / Resultados (JSON)</label>',
      '<textarea x-model="form.resultadosText" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono outline-none focus:ring-2 focus:ring-amber-500 transition-shadow" rows="6" placeholder="[]"></textarea></div>',
      '</div>'
    ].join('\n');
    await UI.modalForm('Nueva Inspecci\u00f3n', html,
      async (data) => {
        await this.guardar(data);
        await this.cargar();
      },
      { plantillaId: '', ubicacionId: '', equipoId: '', resultado: '', resultadosText: '[]' }
    );
  },

  validarForm(d) {
    this.errors = {};
    if (!d.plantillaId) this.errors.plantillaId = 'Selecciona una plantilla';
    if (!d.resultado) this.errors.resultado = 'Selecciona un resultado';
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    try {
      let resultados = [];
      try { resultados = JSON.parse(datos.resultadosText || '[]'); } catch {}
      await db.inspecciones.put({
        id: uuid(),
        plantillaId: datos.plantillaId,
        ubicacionId: datos.ubicacionId || '',
        equipoId: datos.equipoId || '',
        resultados: resultados,
        fotos: datos.fotos || [],
        firma: datos.firma || '',
        resultado: datos.resultado,
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      UI.toast('Inspecci\u00f3n guardada', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  verDetalle(item) {
    const html = [
      '<div class="space-y-4 text-sm">',
      '<div class="grid grid-cols-2 gap-4">',
      '<div><p class="text-xs font-semibold uppercase tracking-wider text-gray-500">Plantilla</p><p class="text-gray-900 font-medium" x-text="form.plantillaNombre"></p></div>',
      '<div><p class="text-xs font-semibold uppercase tracking-wider text-gray-500">Resultado</p><p class="text-gray-900 font-medium" x-text="capitalize(form.resultado || \'pendiente\')"></p></div>',
      '<div><p class="text-xs font-semibold uppercase tracking-wider text-gray-500">Ubicaci\u00f3n</p><p class="text-gray-900" x-text="form.ubicacionNombre || \'\u2014\'"></p></div>',
      '<div><p class="text-xs font-semibold uppercase tracking-wider text-gray-500">Equipo</p><p class="text-gray-900" x-text="form.equipoNombre || \'\u2014\'"></p></div>',
      '</div>',
      '<div><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Resultados</p>',
      '<pre class="bg-gray-50 rounded-lg p-3 text-xs overflow-auto max-h-48" x-text="JSON.stringify(form.resultados, null, 2)"></pre></div>',
      '<div><p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Fecha</p><p x-text="formatearFecha(form.createdAt)"></p></div>',
      '</div>'
    ].join('\n');
    const p = this.plantillas.find(x => x.id === item.plantillaId);
    const u = this.ubicaciones.find(x => x.id === item.ubicacionId);
    const e = this.equipos.find(x => x.id === item.equipoId);
    UI.modalForm('Detalle de Inspecci\u00f3n', html, async () => {},
      { ...item, plantillaNombre: p ? p.nombre : '\u2014', ubicacionNombre: u ? u.nombre : '', equipoNombre: e ? e.nombre : '' }
    );
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar esta inspecci\u00f3n?');
    if (!ok) return;
    try { await db.inspecciones.delete(item.id); UI.toast('Eliminada', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  },

  async exportarCSV() {
    if (!this.items.length) { UI.toast('No hay datos para exportar', 'warning'); return; }
    try {
      const XLSX = window.XLSX;
      const data = this.items.map(r => ({
        Plantilla: this.nombrePlantilla(r.plantillaId),
        Ubicaci\u00f3n: this.nombreUbicacion(r.ubicacionId),
        Equipo: this.nombreEquipo(r.equipoId),
        Resultado: this.capitalize(r.resultado || 'pendiente'),
        Fecha: this.formatearFecha(r.createdAt)
      }));
      if (XLSX) {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Inspecciones');
        XLSX.writeFile(wb, 'inspecciones.xlsx');
      } else {
        const cabeceras = Object.keys(data[0]);
        let csv = cabeceras.join(',') + '\n';
        for (const fila of data) {
          csv += cabeceras.map(k => '"' + String(fila[k] || '').replace(/"/g, '""') + '"').join(',') + '\n';
        }
        const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = 'inspecciones.csv'; a.click();
        URL.revokeObjectURL(url);
      }
      UI.toast('Exportado', 'success');
    } catch (e) { console.error(e); UI.toast('Error al exportar', 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['chk-reportes'] = ModuloChkReportes;

document.addEventListener('alpine:init', () => {
  Alpine.data('chkReportesData', () => ModuloChkReportes);
});
