const ModuloGastosDashboard = {
  id: 'gastos-dashboard',
  titulo: 'Dashboard',
  icono: 'bi bi-speedometer2',

  resumen: { ingresos: 0, egresos: 0, saldo: 0, movsMes: 0 },
  movimientosRecientes: [],
  categorias: [],
  loading: true,
  mesActual: '',
  chartInstance: null,

  async init() {
    const d = new Date();
    this.mesActual = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
    await Promise.all([this.cargarDatos(), this.cargarCategorias()]);
    this.$nextTick(() => {
      const el = this.$el?.querySelector('#chartGastos');
      if (el) setTimeout(() => this.renderChart(el), 100);
    });
  },

  render() {
    return `
      <div x-data="gastosDashboardData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-violet-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-speedometer2 text-violet-600"></i> Dashboard
          </h2>
        </div>

        <template x-if="loading">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <template x-for="i in 4" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-3 w-16 bg-gray-200 rounded animate-pulse mb-2"></div><div class="h-7 w-24 bg-gray-200 rounded animate-pulse"></div></div></template>
          </div>
        </template>

        <template x-if="!loading">
          <div>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Ingresos del mes</p>
                <p class="text-2xl font-bold text-green-600" x-text="formatearMoneda(resumen.ingresos)"></p>
              </div>
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Egresos del mes</p>
                <p class="text-2xl font-bold text-red-600" x-text="formatearMoneda(resumen.egresos)"></p>
              </div>
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Saldo</p>
                <p class="text-2xl font-bold" :class="resumen.saldo >= 0 ? 'text-violet-600' : 'text-red-600'" x-text="formatearMoneda(resumen.saldo)"></p>
              </div>
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Movimientos</p>
                <p class="text-2xl font-bold text-gray-900" x-text="resumen.movsMes"></p>
              </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Ingresos vs Egresos</h3>
                <canvas id="chartGastos" class="max-h-56"></canvas>
              </div>
              <div class="bg-white rounded-xl border border-gray-200 p-4">
                <h3 class="font-semibold text-gray-900 mb-3 text-sm">Últimos movimientos</h3>
                <template x-if="movimientosRecientes.length === 0">
                  <p class="text-gray-400 text-sm py-8 text-center">Sin movimientos este mes</p>
                </template>
                <div class="space-y-2">
                  <template x-for="m in movimientosRecientes.slice(0, 5)" :key="m.id">
                    <div class="flex items-center justify-between py-1.5 border-b border-gray-100 last:border-0">
                      <div class="flex items-center gap-2 min-w-0">
                        <span class="w-2 h-2 rounded-full shrink-0" :class="m.tipo === 'ingreso' ? 'bg-green-500' : 'bg-red-500'"></span>
                        <div class="min-w-0">
                          <p class="text-sm text-gray-900 truncate" x-text="m.nota || m.categoria || 'Sin concepto'"></p>
                          <p class="text-xs text-gray-400" x-text="formatearFecha(m.fecha || m.createdAt)"></p>
                        </div>
                      </div>
                      <span class="text-sm font-mono font-bold shrink-0" :class="m.tipo === 'ingreso' ? 'text-green-600' : 'text-red-600'" x-text="(m.tipo === 'ingreso' ? '+' : '-') + '$' + Number(m.monto || 0).toLocaleString('es-MX')"></span>
                    </div>
                  </template>
                </div>
              </div>
            </div>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.resumen = { ingresos: 0, egresos: 0, saldo: 0, movsMes: 0 };
    this.movimientosRecientes = []; this.categorias = []; this.loading = true;
    if (this.chartInstance) { this.chartInstance.destroy(); this.chartInstance = null; }
  },

  formatearMoneda(v) { if (v == null || isNaN(v)) return '$0.00'; return '$' + Number(v).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); },
  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return f; } },

  async cargarDatos() {
    try {
      this.loading = true;
      const movs = await db.movimientos.toArray();
      const filtrados = movs.filter(m => (m.fecha || m.createdAt || '').startsWith(this.mesActual));
      let ing = 0, eg = 0;
      for (const m of filtrados) {
        if (m.tipo === 'ingreso') ing += Number(m.monto || 0);
        else eg += Number(m.monto || 0);
      }
      this.resumen = { ingresos: ing, egresos: eg, saldo: ing - eg, movsMes: filtrados.length };
      this.movimientosRecientes = filtrados.sort((a, b) => new Date(b.fecha || b.createdAt) - new Date(a.fecha || a.createdAt));
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarCategorias() {
    try { this.categorias = await db.categorias.toArray(); } catch (e) { console.error(e); }
  },

  renderChart(el) {
    if (this.chartInstance) { this.chartInstance.destroy(); }
    try {
      this.chartInstance = new Chart(el, {
        type: 'doughnut',
        data: {
          labels: ['Ingresos', 'Egresos'],
          datasets: [{ data: [this.resumen.ingresos || 1, this.resumen.egresos || 1], backgroundColor: ['#16a34a', '#dc2626'], borderWidth: 0 }]
        },
        options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'bottom', labels: { font: { size: 11 }, boxWidth: 12, padding: 12 } } } }
      });
    } catch (e) { console.error('Chart:', e); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['gastos-dashboard'] = ModuloGastosDashboard;

document.addEventListener('alpine:init', () => {
  Alpine.data('gastosDashboardData', () => ModuloGastosDashboard);
});
