# AHA Flota — Spec Técnica

## Identidad
- **App:** AHA Flota
- **Perfil:** Lite
- **Target:** Transportistas, dueños de flotillas, empresas de logística
- **Tagline:** Control de vehículos y flotilla offline
- **Color primario:** #f59e0b (amber-500)
- **Descripción:** Registro de combustible, mantenimiento programado, kilometraje, incidentes.

## DB Schema (Dexie)

```javascript
db.version(2).stores({
  vehiculos: 'id, *placas, *numeroEconomico, marca, modelo, *anio, *tipo, *estado, *createdBy, createdAt, updatedAt',
  cargas_combustible: 'id, *vehiculoId, litros, importe, *kilometraje, *tipo, createdAt',
  mantenimientos: 'id, *vehiculoId, *tipo, costo, *kilometraje, *taller, *proximoKm, *createdBy, createdAt',
  incidentes: 'id, *vehiculoId, *tipo, costo, descripcion, *createdBy, createdAt',
  _sync_log, _ia_chats, _ia_messages
});
```

Tipos vehículo: moto, auto, camioneta, camión
Estado vehículo: activo, en taller, dado de baja
Tipo combustible: gasolina, diésel
Tipo mantenimiento: aceite, llantas, frenos, afinación, general
Tipo incidente: multa, accidente, avería

## Módulos (5)

### vehiculos
- CRUD: marca, modelo, año, placas, número económico, tipo, estado
- Foto vehículo (opcional)
- Búsqueda por placas o número económico

### combustible
- Registro cargas: fecha, litros, importe, kilometraje, tipo
- Cálculo automático rendimiento km/litro
- Historial por vehículo con gráfico Chart.js

### mantenimiento
- Registro servicios: tipo, taller, costo, kilometraje
- Programación: próximo servicio por km o fecha
- Alerta visual próxmo mantenimiento

### incidentes
- Registro: tipo, fecha, costo, descripción

### reportes
- Dashboard: total vehículos, gasto combustible mes, próximos mantenimientos
- Costo por km por vehículo (Chart.js)
- Export CSV

## Estilo
- DaisyUI 4 + Tailwind Play CDN + Bootstrap Icons + Animate.css
- Tema amber (primary: #f59e0b)
- Chart.js
- ES5 estricto
