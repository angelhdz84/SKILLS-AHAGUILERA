const ModuloComandaPedidos = {
  id: 'com-pedidos', titulo: 'Comandas', icono: 'bi bi-receipt',
  items: [], mesas: [], platillos: [], categorias: [], loading: true, formCtx: null,

  async init() {
    const [p, m, pl, c] = await Promise.all([
      db.comandas?.orderBy('createdAt').reverse().toArray() || [],
      db.mesas?.toArray() || [],
      db.platillos?.toArray() || [],
      db.categorias?.orderBy('orden').toArray() || []
    ]);
    this.items = p; this.mesas = m; this.platillos = pl; this.categorias = c; this.loading = false;
  },

  render() {
    return `
      <div x-data="comPedidosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-red-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2"><i class="bi bi-receipt text-red-600"></i> Comandas</h2>
        </div>
        <div class="flex flex-wrap gap-2 mb-4">
          <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 shadow-sm" @click="nuevaComanda()"><i class="bi bi-plus-lg"></i> Nueva comanda</button>
        </div>
        <template x-if="!loading && items.length === 0">
          <div class="flex flex-col items-center justify-center py-16 text-gray-400"><i class="bi bi-receipt text-6xl mb-4"></i><p class="text-lg text-gray-500">Sin comandas</p></div>
        </template>
        <template x-if="items.length > 0">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <template x-for="c in items.filter(x => x.estado === 'abierta')" :key="c.id">
              <div class="bg-white rounded-xl border-2 border-red-200 p-4 hover:shadow-md transition-shadow">
                <div class="flex items-center justify-between mb-2">
                  <span class="font-bold text-red-600" x-text="nomMesa(c.mesaId)"></span>
                  <span class="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-medium">Abierta</span>
                </div>
                <div class="text-sm text-gray-700 mb-2"><span x-text="(c.items || []).length + ' items'"></span></div>
                <div class="text-lg font-bold text-gray-900">$<span x-text="Number(c.total || 0).toLocaleString('es-MX')"></span></div>
                <div class="flex gap-1 mt-3 pt-3 border-t border-gray-100">
                  <button class="flex-1 text-xs bg-red-600 text-white py-1.5 rounded-lg hover:bg-red-700 font-medium" @click="agregarItems(c)">+ Items</button>
                  <button class="flex-1 text-xs bg-green-600 text-white py-1.5 rounded-lg hover:bg-green-700 font-medium" @click="cerrarComanda(c)">Cerrar</button>
                </div>
              </div>
            </template>
          </div>
        </template>
        <template x-if="loading"><div class="space-y-3"><template x-for="i in 3" :key="i"><div class="bg-white rounded-xl border border-gray-200 p-4"><div class="h-4 w-32 bg-gray-200 rounded animate-pulse"></div></div></template></div></template>
      </div>
    `;
  },

  destroy() { this.items = []; this.mesas = []; this.platillos = []; this.categorias = []; this.loading = true; },
  nomMesa(id) { const m = this.mesas.find(x => x.id === id); return m ? m.nombre : '\u2014'; },
  nomCategoria(id) { const c = this.categorias.find(x => x.id === id); return c ? c.nombre : '\u2014'; },

  async nuevaComanda() {
    const ops = this.mesas.filter(m => m.estado === 'disponible' || m.estado === 'ocupada').map(m => '<option value="' + m.id + '">' + m.nombre + ' (' + m.estado + ')</option>').join('');
    const html = '<div class="space-y-4"><div><label class="block text-sm font-medium text-gray-700 mb-1">Mesa</label><select x-model="form.mesaId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500 bg-white"><option value="">Seleccionar...</option>' + ops + '</select></div><div class="mt-3"><h4 class="text-sm font-medium text-gray-700 mb-2">Items</h4><template x-for="(l, i) in form.items" :key="i"><div class="flex items-center gap-2 mb-2"><select x-model="l.platilloId" class="flex-1 px-2 py-1.5 border border-gray-300 rounded text-sm focus:ring-red-500 bg-white"><option value="">Platillo</option>' + this.platillos.filter(p => p.disponible !== false).map(p => '<option value="' + p.id + '">' + p.nombre + ' ($' + Number(p.precio).toLocaleString() + ')</option>').join('') + '</select><input type="number" min="1" x-model="l.cantidad" class="w-16 px-2 py-1.5 border border-gray-300 rounded text-sm" placeholder="1" /><button class="text-red-400 hover:text-red-600" @click="form.items.splice(i, 1)"><i class="bi bi-x"></i></button></div></template><button class="text-sm text-red-600 hover:text-red-700 font-medium" @click="form.items.push({platilloId: '', cantidad: 1})"><i class="bi bi-plus-circle"></i> Agregar item</button></div></div>';
    await UI.modalForm('Nueva Comanda', html, async (data) => {
      if (!data.mesaId) { UI.toast('Selecciona una mesa', 'error'); return; }
      const itemsValidos = (data.items || []).filter(l => l.platilloId);
      if (itemsValidos.length === 0) { UI.toast('Agrega al menos un platillo', 'error'); return; }
      let total = 0;
      for (const l of itemsValidos) { const p = this.platillos.find(x => x.id === l.platilloId); total += (p?.precio || 0) * (l.cantidad || 1); }
      await db.comandas.put({ id: window.uuid(), mesaId: data.mesaId, estado: 'abierta', items: JSON.stringify(itemsValidos) || '[]', total, createdBy: 'anon', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      const mesa = await db.mesas.get(data.mesaId);
      if (mesa && mesa.estado === 'disponible') await db.mesas.put({ ...mesa, estado: 'ocupada', updatedAt: new Date().toISOString() });
      UI.toast('Comanda creada', 'success');
      const [coms] = await Promise.all([db.comandas.orderBy('createdAt').reverse().toArray()]);
      this.items = coms; const ms = await db.mesas.toArray(); this.mesas = ms;
    }, { mesaId: '', items: [{ platilloId: '', cantidad: 1 }] });
  },

  async agregarItems(comanda) {
    const ops = this.platillos.filter(p => p.disponible !== false).map(p => '<option value="' + p.id + '">' + p.nombre + ' ($' + Number(p.precio).toLocaleString() + ')</option>').join('');
    const html = '<div class="space-y-2"><template x-for="(l, i) in form.items" :key="i"><div class="flex items-center gap-2"><select x-model="l.platilloId" class="flex-1 px-2 py-1.5 border border-gray-300 rounded text-sm focus:ring-red-500 bg-white"><option value="">Platillo</option>' + ops + '</select><input type="number" min="1" x-model="l.cantidad" class="w-16 px-2 py-1.5 border border-gray-300 rounded text-sm" /><button class="text-red-400 hover:text-red-600" @click="form.items.splice(i, 1)"><i class="bi bi-x"></i></button></div></template><button class="text-sm text-red-600 hover:text-red-700 font-medium" @click="form.items.push({platilloId: '', cantidad: 1})"><i class="bi bi-plus-circle"></i> Agregar</button></div>';
    await UI.modalForm('Agregar items a ' + this.nomMesa(comanda.mesaId), html, async (data) => {
      const existentes = typeof comanda.items === 'string' ? JSON.parse(comanda.items || '[]') : (comanda.items || []);
      const nuevos = (data.items || []).filter(l => l.platilloId);
      const items = [...existentes, ...nuevos];
      let total = 0;
      for (const l of items) { const p = this.platillos.find(x => x.id === l.platilloId); total += (p?.precio || 0) * (l.cantidad || 1); }
      await db.comandas.put({ ...comanda, items: JSON.stringify(items), total, updatedAt: new Date().toISOString() });
      UI.toast('Items agregados', 'success');
      const [coms] = await Promise.all([db.comandas.orderBy('createdAt').reverse().toArray()]); this.items = coms;
    }, { items: [{ platilloId: '', cantidad: 1 }] });
  },

  async cerrarComanda(comanda) {
    await UI.modalForm('Cerrar comanda', '<p class="text-sm text-gray-600">Total: $' + Number(comanda.total || 0).toLocaleString('es-MX') + '</p>', async () => {
      const e = await db.comandas.get(comanda.id);
      if (!e) return;
      await db.comandas.put({ ...e, estado: 'cerrada', updatedAt: new Date().toISOString() });
      const mesa = await db.mesas.get(e.mesaId);
      if (mesa) await db.mesas.put({ ...mesa, estado: 'disponible', updatedAt: new Date().toISOString() });
      UI.toast('Comanda cerrada', 'success');
      const [coms, ms] = await Promise.all([db.comandas.orderBy('createdAt').reverse().toArray(), db.mesas.toArray()]);
      this.items = coms; this.mesas = ms;
    });
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['com-pedidos'] = ModuloComandaPedidos;
document.addEventListener('alpine:init', () => { Alpine.data('comPedidosData', () => ModuloComandaPedidos); });
