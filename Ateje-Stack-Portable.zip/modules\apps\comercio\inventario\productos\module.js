﻿const ModuloInvProductos = {
  id: 'inv-productos',
  titulo: 'Productos',
  icono: 'bi bi-box-seam',

  tab: 'productos',
  items: [],
  categorias: [],
  errors: {},
  searchQuery: '',
  filtroCategoria: '',
  loading: true,
  saving: false,
  kpis: { total: 0, bajoStock: 0, sinStock: 0, valorTotal: 0 },

  async init() {
    await Promise.all([this.cargarProductos(), this.cargarCategorias()]);
  },

  render() {
    return 
      <div x-data="invProductosData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-emerald-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-box-seam text-emerald-600"></i> Productos
          </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Stock bajo</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.bajoStock"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Sin stock</p>
            <p class="text-2xl font-bold text-red-600" x-text="kpis.sinStock"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Valor</p>
            <p class="text-2xl font-bold text-emerald-600" x-text="formatearMoneda(kpis.valorTotal)"></p>
          </div>
        </div>

        <div class="flex gap-1 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'productos' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'productos'"><i class="bi bi-box-seam"></i> Productos</button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'categorias' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'categorias'"><i class="bi bi-tags"></i> Categor\u00edas</button>
        </div>

        <template x-if="tab === 'productos'">
          <div>
            <div class="flex flex-wrap gap-2 mb-4">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors shadow-sm" @click="abrirForm()">
                <i class="bi bi-plus-lg"></i> Producto
              </button>
              <div class="relative flex-1 min-w-[200px]">
                <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                <input type="search" x-model="searchQuery" @input.debounce="cargarProductos" placeholder="Buscar por nombre o SKU..."
                       class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-shadow" />
              </div>
              <select x-model="filtroCategoria" @change="cargarProductos"
                      class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-emerald-500 outline-none transition-shadow">
                <option value="">Todas</option>
                <template x-for="c in categorias" :key="c.id">
                  <option :value="c.id" x-text="c.nombre"></option>
                </template>
              </select>
            </div>

            <template x-if="items.length === 0 && !loading">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                <i class="bi bi-box-seam text-6xl mb-4"></i>
                <p class="text-lg text-gray-500 mb-2">No hay productos</p>
                <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors" @click="abrirForm()">
                  <i class="bi bi-plus-lg"></i> Agregar primero
                </button>
              </div>
            </template>

            <template x-if="items.length > 0">
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                <template x-for="p in items" :key="p.id">
                  <div class="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 cursor-pointer" @click="abrirForm(p)">
                    <div class="h-36 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                      <template x-if="p.imagen"><img :src="p.imagen" class="w-full h-full object-cover" /></template>
                      <template x-if="!p.imagen"><i class="bi bi-image text-4xl text-gray-300"></i></template>
                    </div>
                    <div class="p-4">
                      <div class="flex items-start justify-between gap-2 mb-1">
                        <h3 class="font-semibold text-gray-900 text-sm leading-tight" x-text="p.nombre"></h3>
                        <span class="text-sm font-bold text-emerald-600" x-text="formatearMoneda(p.precio)"></span>
                      </div>
                      <div class="flex items-center gap-2 mb-2">
                        <span class="text-xs text-gray-400" x-text="nombreCategoria(p.categoriaId)"></span>
                        <span class="text-gray-300">\u00b7</span>
                        <span class="text-xs text-gray-400" x-text="p.sku || 'Sin SKU'"></span>
                      </div>
                      <div class="flex items-center gap-2">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
                              :class="stockClass(p.cantidad)"
                              x-text="stockLabel(p.cantidad)"></span>
                        <span class="text-xs text-gray-400" x-text="(p.cantidad || 0) + ' uds'"></span>
                      </div>
                    </div>
                  </div>
                </template>
              </div>
            </template>
          </div>
        </template>

        <template x-if="tab === 'categorias'">
          <div>
            <div class="flex flex-wrap gap-2 mb-4">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors shadow-sm" @click="abrirFormCategoria()">
                <i class="bi bi-plus-lg"></i> Categor\u00eda
              </button>
            </div>
            <template x-if="categorias.length === 0">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                <i class="bi bi-tags text-6xl mb-4"></i>
                <p class="text-lg text-gray-500 mb-2">Sin categor\u00edas</p>
              </div>
            </template>
            <template x-if="categorias.length > 0">
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <template x-for="c in categorias" :key="c.id">
                  <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between hover:shadow-md transition-shadow">
                    <div class="flex items-center gap-3">
                      <div class="w-4 h-4 rounded-full" :style="'background:' + (c.color || '#10b981')"></div>
                      <span class="font-medium text-gray-900" x-text="c.nombre"></span>
                      <span class="text-xs text-gray-400" x-text="'(' + items.filter(p => p.categoriaId === c.id).length + ')'"></span>
                    </div>
                    <button class="text-gray-300 hover:text-red-500 transition-colors p-1" @click.stop="eliminarCategoria(c)">
                      <i class="bi bi-trash"></i>
                    </button>
                  </div>
                </template>
              </div>
            </template>
          </div>
        </template>

        <template x-if="loading">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            <template x-for="i in 8" :key="i">
              <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div class="h-36 bg-gray-200 animate-pulse"></div>
                <div class="p-4 space-y-3">
                  <div class="h-4 bg-gray-200 rounded animate-pulse w-3/4"></div>
                  <div class="h-3 bg-gray-200 rounded animate-pulse w-1/2"></div>
                  <div class="h-5 bg-gray-200 rounded animate-pulse w-1/4"></div>
                </div>
              </div>
            </template>
          </div>
        </template>
      </div>
    ;
  },

  destroy() {
    this.tab = 'productos';
    this.items = [];
    this.categorias = [];
    this.searchQuery = '';
    this.filtroCategoria = '';
    this.loading = true;
    this.kpis = { total: 0, bajoStock: 0, sinStock: 0, valorTotal: 0 };
  },

  formatearMoneda(v) { if (v == null || isNaN(v)) return '.00'; return '$' + Number(v).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); },
  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return f; } },

  nombreCategoria(id) { const c = this.categorias.find(x => x.id === id); return c ? c.nombre : '\u2014'; },
  stockClass(s) { if (!s || s <= 0) return 'bg-red-100 text-red-700'; if (s <= 5) return 'bg-amber-100 text-amber-700'; return 'bg-green-100 text-green-700'; },
  stockLabel(s) { if (!s || s <= 0) return 'Agotado'; if (s <= 5) return 'Stock bajo'; return 'Disponible'; },

  async cargarProductos() {
    try {
      this.loading = true;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.productos.orderBy('createdAt').reverse().toArray();
      if (filtro) datos = datos.filter(p => (p.nombre || '').toLowerCase().includes(filtro) || (p.sku || '').toLowerCase().includes(filtro));
      if (this.filtroCategoria) datos = datos.filter(p => p.categoriaId === this.filtroCategoria);
      this.items = datos;
      let bajo = 0, sin = 0, val = 0;
      for (const p of datos) {
        const cant = p.cantidad || 0;
        if (cant <= 0) sin++; else if (cant <= (p.umbralMinimo || 5)) bajo++;
        val += cant * (p.precio || 0);
      }
      this.kpis = { total: datos.length, bajoStock: bajo, sinStock: sin, valorTotal: val };
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarCategorias() {
    try { this.categorias = await db.categorias.orderBy('nombre').toArray(); }
    catch (e) { console.error(e); }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const html = [
      '<div class="space-y-4">',
      '<div class="grid grid-cols-2 gap-4">',
      '<div class="col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>',
      '<input type="text" x-model="form.nombre" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.nombre ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500\'" />',
      '<template x-if="errors.nombre"><p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Precio <span class="text-red-500">*</span></label>',
      '<input type="number" step="0.01" min="0" x-model="form.precio" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.precio ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500\'" />',
      '<template x-if="errors.precio"><p class="mt-1 text-sm text-red-500" x-text="errors.precio"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Cantidad</label>',
      '<input type="number" min="0" x-model="form.cantidad" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Categor\u00eda</label>',
      '<select x-model="form.categoriaId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-shadow bg-white">',
      '<option value="">Sin categor\u00eda</option>',
      '<template x-for="c in categorias" :key="c.id"><option :value="c.id" x-text="c.nombre"></option></template>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">SKU</label>',
      '<input type="text" x-model="form.sku" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-shadow" /></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Umbral m\u00ednimo</label>',
      '<input type="number" min="0" x-model="form.umbralMinimo" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-shadow" /></div>',
      '</div></div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Producto' : 'Nuevo Producto', html,
      async (data) => {
        if (editando) await this.actualizar(item.id, data);
        else await this.guardar(data);
        await this.cargarProductos();
      }, item || { cantidad: 0, umbralMinimo: 5 }
    );
  },

  validarForm(d) {
    this.errors = {};
    if (!d.nombre || !d.nombre.trim()) this.errors.nombre = 'El nombre es obligatorio';
    if (d.precio == null || d.precio === '' || Number(d.precio) < 0) this.errors.precio = 'Precio v\u00e1lido requerido';
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    try {
      await db.productos.put({
        id: uuid(), nombre: datos.nombre.trim(), sku: datos.sku?.trim() || '',
        categoriaId: datos.categoriaId || '', precio: parseFloat(datos.precio) || 0,
        cantidad: parseInt(datos.cantidad) || 0, imagen: datos.imagen || '',
        umbralMinimo: parseInt(datos.umbralMinimo) || 5,
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      });
      UI.toast('Producto guardado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    try {
      const e = await db.productos.get(id);
      if (!e) { UI.toast('No encontrado', 'error'); return; }
      await db.productos.put({ ...e, nombre: datos.nombre.trim(), sku: datos.sku?.trim() || '',
        categoriaId: datos.categoriaId || '', precio: parseFloat(datos.precio) || 0,
        cantidad: parseInt(datos.cantidad) || 0, umbralMinimo: parseInt(datos.umbralMinimo) || 5,
        updatedAt: new Date().toISOString() });
      UI.toast('Producto actualizado', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar ' + (item.nombre || 'este producto') + '?');
    if (!ok) return;
    try { await db.productos.delete(item.id); UI.toast('Eliminado', 'success'); await this.cargarProductos(); }
    catch (e) { UI.toast(e.message, 'error'); }
  },

  async abrirFormCategoria(item = null) {
    const html = '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label><input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-shadow" /><label class="block text-sm font-medium text-gray-700 mt-3 mb-1">Color</label><input type="color" x-model="form.color" class="w-full h-9 px-1 border border-gray-300 rounded-lg cursor-pointer" /></div>';
    await UI.modalForm(item ? 'Editar Categor\u00eda' : 'Nueva Categor\u00eda', html,
      async (data) => {
        if (item) {
          const e = await db.categorias.get(item.id);
          if (e) { e.nombre = data.nombre.trim(); e.color = data.color || '#10b981'; e.updatedAt = new Date().toISOString(); await db.categorias.put(e); }
        } else {
          await db.categorias.put({ id: uuid(), nombre: data.nombre.trim(), color: data.color || '#10b981', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        }
        UI.toast('Categor\u00eda guardada', 'success');
        await this.cargarCategorias();
      }, item || { color: '#10b981' }
    );
  },

  async eliminarCategoria(item) {
    const ok = await UI.confirm('Eliminar ' + (item.nombre || 'esta categor\u00eda') + '? Los productos vinculados se quedar\u00e1n sin categor\u00eda.');
    if (!ok) return;
    try { await db.categorias.delete(item.id); UI.toast('Eliminada', 'success'); await this.cargarCategorias(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['inv-productos'] = ModuloInvProductos;

document.addEventListener('alpine:init', () => {
  Alpine.data('invProductosData', () => ModuloInvProductos);
});
