const ModuloChkPlantillas = {
  id: 'chk-plantillas',
  titulo: 'Plantillas',
  icono: 'bi bi-file-earmark-check',

  tab: 'plantillas',
  items: [],
  categorias: [],
  errors: {},
  searchQuery: '',
  filtroCategoria: '',
  loading: true,
  saving: false,
  kpis: { total: 0, conItems: 0, hoy: 0 },

  async init() {
    await Promise.all([this.cargar(), this.cargarCategorias()]);
  },

  render() {
    return `
      <div x-data="chkPlantillasData()" x-init="init()" class="transition-all duration-300">
        <div class="flex items-center gap-2 mb-6">
          <div class="w-1 h-8 bg-purple-600 rounded-full"></div>
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i class="bi bi-file-earmark-check text-purple-600"></i> Plantillas
          </h2>
        </div>

        <div class="grid grid-cols-3 gap-4 mb-6">
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Total</p>
            <p class="text-2xl font-bold text-gray-900" x-text="kpis.total"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Con items</p>
            <p class="text-2xl font-bold text-purple-600" x-text="kpis.conItems"></p>
          </div>
          <div class="bg-white rounded-xl border border-gray-200 p-4">
            <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1">Creadas hoy</p>
            <p class="text-2xl font-bold text-amber-600" x-text="kpis.hoy"></p>
          </div>
        </div>

        <div class="flex gap-1 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'plantillas' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'plantillas'"><i class="bi bi-file-earmark-check"></i> Plantillas</button>
          <button class="px-4 py-1.5 text-sm font-medium rounded-md transition-colors"
                  :class="tab === 'categorias' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                  @click="tab = 'categorias'"><i class="bi bi-tags"></i> Categor\u00edas</button>
        </div>

        <template x-if="tab === 'plantillas'">
          <div>
            <div class="flex flex-wrap gap-2 mb-4">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-purple-600 text-white text-sm font-medium rounded-lg hover:bg-purple-700 transition-colors shadow-sm" @click="abrirForm()">
                <i class="bi bi-plus-lg"></i> Plantilla
              </button>
              <div class="relative flex-1 min-w-[200px]">
                <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                <input type="search" x-model="searchQuery" @input.debounce="cargar" placeholder="Buscar plantillas..."
                       class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 placeholder-gray-400 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition-shadow" />
              </div>
              <select x-model="filtroCategoria" @change="cargar"
                      class="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white focus:ring-2 focus:ring-purple-500 outline-none transition-shadow">
                <option value="">Todas</option>
                <template x-for="c in categorias" :key="c.id">
                  <option :value="c.id" x-text="c.nombre"></option>
                </template>
              </select>
            </div>

            <template x-if="items.length === 0 && !loading">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                <i class="bi bi-file-earmark-check text-6xl mb-4"></i>
                <p class="text-lg text-gray-500 mb-2">No hay plantillas</p>
                <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-purple-600 text-white text-sm font-medium rounded-lg hover:bg-purple-700 transition-colors" @click="abrirForm()">
                  <i class="bi bi-plus-lg"></i> Crear primera
                </button>
              </div>
            </template>

            <template x-if="items.length > 0">
              <div class="overflow-x-auto rounded-lg border border-gray-200">
                <table class="w-full text-sm">
                  <thead>
                    <tr class="bg-gray-50 border-b border-gray-200">
                      <th class="text-left px-4 py-3 font-semibold text-gray-600">Nombre</th>
                      <th class="text-left px-4 py-3 font-semibold text-gray-600">Categor\u00eda</th>
                      <th class="text-center px-4 py-3 font-semibold text-gray-600">Items</th>
                      <th class="text-left px-4 py-3 font-semibold text-gray-600">Creado</th>
                      <th class="text-right px-4 py-3 font-semibold text-gray-600">Acciones</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-gray-100">
                    <template x-for="(p, idx) in items" :key="p.id">
                      <tr class="hover:bg-gray-50 transition-colors cursor-pointer"
                          :class="idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'"
                          @click="abrirForm(p)">
                        <td class="px-4 py-3">
                          <span class="text-gray-900 font-medium" x-text="p.nombre"></span>
                        </td>
                        <td class="px-4 py-3">
                          <span x-text="nombreCategoria(p.categoriaId)" class="text-gray-500"></span>
                        </td>
                        <td class="px-4 py-3 text-center">
                          <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                                :class="(p.items && p.items.length > 0) ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'"
                                x-text="(p.items && p.items.length) || 0"></span>
                        </td>
                        <td class="px-4 py-3 text-gray-500" x-text="formatearFecha(p.createdAt)"></td>
                        <td class="px-4 py-3 text-right">
                          <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors" @click.stop="abrirForm(p)" title="Editar">
                            <i class="bi bi-pencil"></i>
                          </button>
                          <button class="inline-flex items-center p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" @click.stop="eliminar(p)" title="Eliminar">
                            <i class="bi bi-trash"></i>
                          </button>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </template>
          </div>
        </template>

        <template x-if="tab === 'categorias'">
          <div>
            <div class="flex flex-wrap gap-2 mb-4">
              <button class="inline-flex items-center gap-1.5 px-4 py-2 bg-purple-600 text-white text-sm font-medium rounded-lg hover:bg-purple-700 transition-colors shadow-sm" @click="abrirFormCategoria()">
                <i class="bi bi-plus-lg"></i> Categor\u00eda
              </button>
            </div>
            <template x-if="categorias.length === 0">
              <div class="flex flex-col items-center justify-center py-16 text-gray-400">
                <i class="bi bi-tags text-6xl mb-4"></i>
                <p class="text-lg text-gray-500 mb-2">Sin categor\u00edas</p>
              </div>
            </template>
            <template x-if="categorias.length > 0">
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <template x-for="c in categorias" :key="c.id">
                  <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between hover:shadow-md transition-shadow">
                    <div class="flex items-center gap-3">
                      <div class="w-4 h-4 rounded-full" :style="'background:' + (c.color || '#9333ea')"></div>
                      <span class="font-medium text-gray-900" x-text="c.nombre"></span>
                      <span class="text-xs text-gray-400" x-text="'(' + items.filter(p => p.categoriaId === c.id).length + ')'"></span>
                    </div>
                    <button class="text-gray-300 hover:text-red-500 transition-colors p-1" @click.stop="eliminarCategoria(c)">
                      <i class="bi bi-trash"></i>
                    </button>
                  </div>
                </template>
              </div>
            </template>
          </div>
        </template>

        <template x-if="loading">
          <div class="space-y-3">
            <template x-for="i in 5" :key="i">
              <div class="h-14 w-full bg-gray-200 rounded-lg animate-pulse"></div>
            </template>
          </div>
        </template>
      </div>
    `;
  },

  destroy() {
    this.tab = 'plantillas';
    this.items = [];
    this.categorias = [];
    this.searchQuery = '';
    this.filtroCategoria = '';
    this.loading = true;
    this.kpis = { total: 0, conItems: 0, hoy: 0 };
  },

  formatearFecha(f) { if (!f) return ''; try { return new Date(f).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return f; } },
  nombreCategoria(id) { const c = this.categorias.find(x => x.id === id); return c ? c.nombre : '\u2014'; },

  async cargar() {
    try {
      this.loading = true;
      const filtro = this.searchQuery.trim().toLowerCase();
      let datos = await db.plantillas.orderBy('createdAt').reverse().toArray();
      if (filtro) datos = datos.filter(p => (p.nombre || '').toLowerCase().includes(filtro));
      if (this.filtroCategoria) datos = datos.filter(p => p.categoriaId === this.filtroCategoria);
      this.items = datos;
      const hoy = new Date().toISOString().slice(0, 10);
      this.kpis = {
        total: datos.length,
        conItems: datos.filter(p => p.items && p.items.length > 0).length,
        hoy: datos.filter(p => p.createdAt && p.createdAt.slice(0, 10) === hoy).length
      };
    } catch (e) { console.error(e); UI.toast('Error al cargar', 'error'); }
    finally { this.loading = false; }
  },

  async cargarCategorias() {
    try { this.categorias = await db.categorias_plantillas.orderBy('nombre').toArray(); }
    catch (e) { console.error(e); }
  },

  async abrirForm(item = null) {
    const editando = !!item;
    const itemsHtml = item && item.items ? JSON.stringify(item.items, null, 2) : '[]';
    const html = [
      '<div class="space-y-4">',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label>',
      '<input type="text" x-model="form.nombre" class="w-full px-3 py-2 border rounded-lg text-sm outline-none transition-shadow"',
      ':class="errors.nombre ? \'border-red-500 focus:ring-red-500 focus:ring-2\' : \'border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-purple-500\'" />',
      '<template x-if="errors.nombre"><p class="mt-1 text-sm text-red-500" x-text="errors.nombre"></p></template></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Categor\u00eda</label>',
      '<select x-model="form.categoriaId" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-purple-500 transition-shadow bg-white">',
      '<option value="">Sin categor\u00eda</option>',
      '<template x-for="c in categorias" :key="c.id"><option :value="c.id" x-text="c.nombre"></option></template>',
      '</select></div>',
      '<div><label class="block text-sm font-medium text-gray-700 mb-1">Items (JSON)</label>',
      '<textarea x-model="form.itemsText" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono outline-none focus:ring-2 focus:ring-purple-500 transition-shadow" rows="8" placeholder=\'[{"tipo": "sino", "pregunta": "..."}, {"tipo": "texto", "pregunta": "..."}]\'></textarea>',
      '<p class="text-xs text-gray-400 mt-1">Tipos: sino, numero, texto, foto, firma</p></div>',
      '</div>'
    ].join('\n');
    await UI.modalForm(editando ? 'Editar Plantilla' : 'Nueva Plantilla', html,
      async (data) => {
        if (editando) await this.actualizar(item.id, data);
        else await this.guardar(data);
        await this.cargar();
      },
      item ? { ...item, itemsText: itemsHtml } : { nombre: '', categoriaId: '', itemsText: '[]' }
    );
  },

  validarForm(d) {
    this.errors = {};
    if (!d.nombre || !d.nombre.trim()) this.errors.nombre = 'El nombre es obligatorio';
    try { const parsed = JSON.parse(d.itemsText || '[]'); if (!Array.isArray(parsed)) throw new Error(); }
    catch { this.errors.itemsText = 'JSON inv\u00e1lido'; }
    return Object.keys(this.errors).length === 0;
  },

  async guardar(datos) {
    if (!this.validarForm(datos)) return;
    try {
      await db.plantillas.put({
        id: uuid(), nombre: datos.nombre.trim(), categoriaId: datos.categoriaId || '',
        items: JSON.parse(datos.itemsText || '[]'),
        createdBy: APP_CONFIG?.usuarioActual || 'anon',
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      });
      UI.toast('Plantilla guardada', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async actualizar(id, datos) {
    if (!this.validarForm(datos)) return;
    try {
      const e = await db.plantillas.get(id);
      if (!e) { UI.toast('No encontrada', 'error'); return; }
      await db.plantillas.put({ ...e, nombre: datos.nombre.trim(), categoriaId: datos.categoriaId || '',
        items: JSON.parse(datos.itemsText || '[]'), updatedAt: new Date().toISOString() });
      UI.toast('Plantilla actualizada', 'success');
    } catch (e) { UI.toast('Error: ' + e.message, 'error'); }
  },

  async eliminar(item) {
    const ok = await UI.confirm('Eliminar ' + (item.nombre || 'esta plantilla') + '?');
    if (!ok) return;
    try { await db.plantillas.delete(item.id); UI.toast('Eliminada', 'success'); await this.cargar(); }
    catch (e) { UI.toast(e.message, 'error'); }
  },

  async abrirFormCategoria(item = null) {
    const html = '<div><label class="block text-sm font-medium text-gray-700 mb-1">Nombre <span class="text-red-500">*</span></label><input type="text" x-model="form.nombre" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-purple-500 transition-shadow" /><label class="block text-sm font-medium text-gray-700 mt-3 mb-1">Color</label><input type="color" x-model="form.color" class="w-full h-9 px-1 border border-gray-300 rounded-lg cursor-pointer" /></div>';
    await UI.modalForm(item ? 'Editar Categor\u00eda' : 'Nueva Categor\u00eda', html,
      async (data) => {
        if (item) {
          const e = await db.categorias_plantillas.get(item.id);
          if (e) { e.nombre = data.nombre.trim(); e.color = data.color || '#9333ea'; e.updatedAt = new Date().toISOString(); await db.categorias_plantillas.put(e); }
        } else {
          await db.categorias_plantillas.put({ id: uuid(), nombre: data.nombre.trim(), color: data.color || '#9333ea', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        }
        UI.toast('Categor\u00eda guardada', 'success');
        await this.cargarCategorias();
      }, item || { color: '#9333ea' }
    );
  },

  async eliminarCategoria(item) {
    const ok = await UI.confirm('Eliminar ' + (item.nombre || 'esta categor\u00eda') + '?');
    if (!ok) return;
    try { await db.categorias_plantillas.delete(item.id); UI.toast('Eliminada', 'success'); await this.cargarCategorias(); }
    catch (e) { UI.toast(e.message, 'error'); }
  }
};

window.MODULES = window.MODULES || {};
window.MODULES['chk-plantillas'] = ModuloChkPlantillas;

document.addEventListener('alpine:init', () => {
  Alpine.data('chkPlantillasData', () => ModuloChkPlantillas);
});
